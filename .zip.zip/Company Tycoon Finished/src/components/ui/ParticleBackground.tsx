'use client';

import { useEffect, useRef, useState } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  opacity: number;
  life: number;
  maxLife: number;
  color: string;
}

interface ParticleBackgroundProps {
  theme?: 'default' | 'success' | 'error' | 'warning' | 'coding';
  intensity?: 'low' | 'medium' | 'high';
  enabled?: boolean;
}

export function ParticleBackground({
  theme = 'default',
  intensity = 'low',
  enabled = true
}: ParticleBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const particlesRef = useRef<Particle[]>([]);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  const themes = {
    default: {
      colors: ['#3b82f6', '#8b5cf6', '#06b6d4', '#10b981'],
      particleCount: { low: 15, medium: 25, high: 40 }
    },
    success: {
      colors: ['#10b981', '#34d399', '#6ee7b7', '#a7f3d0'],
      particleCount: { low: 20, medium: 35, high: 50 }
    },
    error: {
      colors: ['#ef4444', '#f87171', '#fca5a5', '#fecaca'],
      particleCount: { low: 25, medium: 40, high: 60 }
    },
    warning: {
      colors: ['#f59e0b', '#fbbf24', '#fcd34d', '#fde68a'],
      particleCount: { low: 20, medium: 30, high: 45 }
    },
    coding: {
      colors: ['#22c55e', '#16a34a', '#15803d', '#166534'],
      particleCount: { low: 30, medium: 50, high: 80 }
    }
  };

  const currentTheme = themes[theme];
  const particleCount = currentTheme.particleCount[intensity];

  useEffect(() => {
    if (!enabled) return;

    const updateDimensions = () => {
      if (canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        setDimensions({ width: rect.width, height: rect.height });
      }
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);

    return () => {
      window.removeEventListener('resize', updateDimensions);
    };
  }, [enabled]);

  useEffect(() => {
    if (!enabled || dimensions.width === 0 || dimensions.height === 0) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = dimensions.width;
    canvas.height = dimensions.height;

    // Initialize particles
    const particles: Particle[] = [];
    for (let i = 0; i < particleCount; i++) {
      particles.push(createParticle());
    }
    particlesRef.current = particles;

    function createParticle(): Particle {
      const colors = currentTheme.colors;
      return {
        x: Math.random() * dimensions.width,
        y: Math.random() * dimensions.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 2 + 0.5,
        opacity: Math.random() * 0.3 + 0.1,
        life: 0,
        maxLife: Math.random() * 600 + 300,
        color: colors[Math.floor(Math.random() * colors.length)]
      };
    }

    function updateParticle(particle: Particle) {
      particle.x += particle.vx;
      particle.y += particle.vy;
      particle.life++;

      // Bounce off edges
      if (particle.x < 0 || particle.x > dimensions.width) {
        particle.vx *= -1;
      }
      if (particle.y < 0 || particle.y > dimensions.height) {
        particle.vy *= -1;
      }

      // Keep particles in bounds
      particle.x = Math.max(0, Math.min(dimensions.width, particle.x));
      particle.y = Math.max(0, Math.min(dimensions.height, particle.y));

      // Fade based on life
      const lifeRatio = particle.life / particle.maxLife;
      particle.opacity = (1 - lifeRatio) * 0.4;

      // Reset particle when it dies
      if (particle.life >= particle.maxLife) {
        Object.assign(particle, createParticle());
      }
    }

    function drawParticle(particle: Particle) {
      if (!ctx) return;

      ctx.save();
      ctx.globalAlpha = particle.opacity;
      ctx.fillStyle = particle.color;
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
      ctx.fill();

      // Add subtle glow
      ctx.shadowColor = particle.color;
      ctx.shadowBlur = particle.size * 2;
      ctx.fill();

      ctx.restore();
    }

    function drawConnections() {
      if (!ctx) return;

      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 100) {
            const opacity = (1 - distance / 100) * 0.1;
            ctx.save();
            ctx.globalAlpha = opacity;
            ctx.strokeStyle = currentTheme.colors[0];
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
            ctx.restore();
          }
        }
      }
    }

    function animate() {
      if (!ctx) return;

      ctx.clearRect(0, 0, dimensions.width, dimensions.height);

      // Update and draw particles
      particles.forEach(particle => {
        updateParticle(particle);
        drawParticle(particle);
      });

      // Draw connections for coding theme
      if (theme === 'coding' && intensity !== 'low') {
        drawConnections();
      }

      animationRef.current = requestAnimationFrame(animate);
    }

    animate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [dimensions, theme, intensity, enabled, currentTheme, particleCount]);

  if (!enabled) return null;

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0 opacity-30"
      style={{
        width: '100%',
        height: '100%',
        background: 'transparent'
      }}
    />
  );
}

// Floating animation component for UI elements
interface FloatingElementProps {
  children: React.ReactNode;
  intensity?: 'subtle' | 'medium' | 'strong';
  direction?: 'vertical' | 'horizontal' | 'circular';
  className?: string;
}

export function FloatingElement({
  children,
  intensity = 'subtle',
  direction = 'vertical',
  className = ''
}: FloatingElementProps) {
  const getAnimationClass = () => {
    const base = 'animate-pulse';

    switch (direction) {
      case 'vertical':
        switch (intensity) {
          case 'subtle': return 'animate-bounce-subtle';
          case 'medium': return 'animate-bounce-medium';
          case 'strong': return 'animate-bounce';
          default: return 'animate-bounce-subtle';
        }
      case 'horizontal':
        return 'animate-sway';
      case 'circular':
        return 'animate-orbit';
      default:
        return 'animate-bounce-subtle';
    }
  };

  return (
    <div className={`${getAnimationClass()} ${className}`}>
      {children}
    </div>
  );
}

// Success burst animation
interface SuccessBurstProps {
  trigger: boolean;
  onComplete?: () => void;
}

export function SuccessBurst({ trigger, onComplete }: SuccessBurstProps) {
  const [particles, setParticles] = useState<Array<{
    id: number;
    x: number;
    y: number;
    vx: number;
    vy: number;
    color: string;
    size: number;
  }>>([]);

  useEffect(() => {
    if (!trigger) return;

    // Create burst particles
    const newParticles = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: 50, // Center
      y: 50,
      vx: (Math.random() - 0.5) * 20,
      vy: (Math.random() - 0.5) * 20,
      color: ['#10b981', '#34d399', '#6ee7b7', '#fbbf24'][Math.floor(Math.random() * 4)],
      size: Math.random() * 8 + 4
    }));

    setParticles(newParticles);

    // Clear particles after animation
    const timeout = setTimeout(() => {
      setParticles([]);
      onComplete?.();
    }, 1000);

    return () => clearTimeout(timeout);
  }, [trigger, onComplete]);

  if (particles.length === 0) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="absolute rounded-full animate-ping"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            backgroundColor: particle.color,
            transform: `translate(${particle.vx * 10}px, ${particle.vy * 10}px)`,
            animationDuration: '1s',
            animationFillMode: 'forwards'
          }}
        />
      ))}
    </div>
  );
}
