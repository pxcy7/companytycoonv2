import { create } from 'zustand';
import { type GameState, type Game, type GameStats, GameSize, type SalesData, SalesPoint } from '@/types/game';

// Initial data
const initialTopics = [
  { id: 'action', name: 'Action', isUnlocked: true, researchCost: 0, audienceMultiplier: 1.0 },
  { id: 'adventure', name: 'Adventure', isUnlocked: false, researchCost: 1000, audienceMultiplier: 0.8 },
  { id: 'strategy', name: 'Strategy', isUnlocked: false, researchCost: 1500, audienceMultiplier: 0.7 },
  { id: 'rpg', name: 'RPG', isUnlocked: false, researchCost: 2000, audienceMultiplier: 1.2 },
  { id: 'simulation', name: 'Simulation', isUnlocked: false, researchCost: 2500, audienceMultiplier: 0.6 },
  { id: 'sports', name: 'Sports', isUnlocked: false, researchCost: 1800, audienceMultiplier: 0.9 },
];

const initialGenres = [
  { id: 'arcade', name: 'Arcade', isUnlocked: true, researchCost: 0, designImportance: 0.2, gameplayImportance: 0.5, audioImportance: 0.2, technicalImportance: 0.1 },
  { id: 'shooter', name: 'Shooter', isUnlocked: false, researchCost: 1200, designImportance: 0.15, gameplayImportance: 0.4, audioImportance: 0.25, technicalImportance: 0.2 },
  { id: 'puzzle', name: 'Puzzle', isUnlocked: false, researchCost: 800, designImportance: 0.4, gameplayImportance: 0.4, audioImportance: 0.1, technicalImportance: 0.1 },
  { id: 'racing', name: 'Racing', isUnlocked: false, researchCost: 1500, designImportance: 0.2, gameplayImportance: 0.3, audioImportance: 0.2, technicalImportance: 0.3 },
];

const initialPlatforms = [
  { id: 'pc', name: 'PC', isUnlocked: true, researchCost: 0, marketShare: 40, audienceSize: 1000000, developmentCost: 0, royaltyRate: 0, isCustom: false },
  { id: 'console1', name: 'GameStation', isUnlocked: false, researchCost: 5000, marketShare: 25, audienceSize: 800000, developmentCost: 2000, royaltyRate: 20, isCustom: false },
  { id: 'console2', name: 'X-Play', isUnlocked: false, researchCost: 6000, marketShare: 20, audienceSize: 600000, developmentCost: 2500, royaltyRate: 25, isCustom: false },
  { id: 'mobile', name: 'Mobile', isUnlocked: false, researchCost: 3000, marketShare: 35, audienceSize: 2000000, developmentCost: 500, royaltyRate: 30, isCustom: false },
];

const initialEngines = [
  { id: 'basic', name: 'Basic Engine', isUnlocked: true, isCustom: false, cost: 0, designBonus: 0, gameplayBonus: 0, audioBonus: 0, technicalBonus: 0, supportedPlatforms: ['pc'], developmentTimeMultiplier: 1.0 },
  { id: 'unity', name: 'Unity Pro', isUnlocked: false, isCustom: false, cost: 5000, designBonus: 10, gameplayBonus: 15, audioBonus: 10, technicalBonus: 20, supportedPlatforms: ['pc', 'console1', 'console2', 'mobile'], developmentTimeMultiplier: 0.8 },
  { id: 'unreal', name: 'Unreal Engine', isUnlocked: false, isCustom: false, cost: 8000, designBonus: 20, gameplayBonus: 10, audioBonus: 15, technicalBonus: 25, supportedPlatforms: ['pc', 'console1', 'console2'], developmentTimeMultiplier: 0.9 },
];

const initialCompany = {
  name: 'Indie Dreams Studio',
  money: 10000,
  reputation: 10,
  researchPoints: 0,
  employees: [],
  office: {
    name: 'Garage',
    capacity: 3,
    cost: 500,
    bonuses: { design: 0, gameplay: 0, audio: 0, technical: 0 }
  }
};

interface GameStore extends GameState {
  // Actions
  createGame: (gameData: Partial<Game>) => void;
  updateGame: (gameId: string, updates: Partial<Game>) => void;
  releaseGame: (gameId: string) => void;
  updateSales: () => void;
  calculateGameQuality: (stats: GameStats, genre: string, engine: string) => number;
  spendMoney: (amount: number) => boolean;
  addMoney: (amount: number) => void;
  addResearchPoints: (points: number) => void;
  unlockResearch: (type: 'topic' | 'genre' | 'platform' | 'engine', id: string) => boolean;
  advanceWeek: () => void;
  pauseGame: () => void;
  resumeGame: () => void;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'isRead'>) => void;
  markNotificationRead: (id: string) => void;
}

export const useGameStore = create<GameStore>((set, get) => ({
  // Initial state
  company: initialCompany,
  research: {
    topics: initialTopics,
    genres: initialGenres,
    platforms: initialPlatforms,
    engines: initialEngines,
    activeResearch: null,
  },
  games: [],
  currentGame: null,
  gameWeek: 1,
  isGamePaused: false,
  notifications: [],

  // Actions
  createGame: (gameData) => {
    const newGame: Game = {
      id: Math.random().toString(36).substr(2, 9),
      name: gameData.name || 'Untitled Game',
      topic: gameData.topic || 'action',
      genre: gameData.genre || 'arcade',
      size: gameData.size || 'small',
      stats: gameData.stats || { design: 0, gameplay: 0, audio: 0, technical: 0 },
      engine: gameData.engine || 'basic',
      platforms: gameData.platforms || ['pc'],
      developmentCost: gameData.developmentCost || 1000,
      marketingBudget: gameData.marketingBudget || 0,
      salePrice: gameData.salePrice || 19.99,
      qualityScore: 0,
      releaseDate: new Date(),
      salesData: {
        totalSales: 0,
        currentWeeklySales: 0,
        salesHistory: [],
        revenue: 0,
        salesLength: 0,
        currentWeek: 0,
        isActive: false,
      },
      isReleased: false,
      isInDevelopment: true,
    };

    set((state) => ({
      games: [...state.games, newGame],
      currentGame: newGame,
    }));
  },

  updateGame: (gameId, updates) => {
    set((state) => ({
      games: state.games.map((game) =>
        game.id === gameId ? { ...game, ...updates } : game
      ),
      currentGame: state.currentGame?.id === gameId
        ? { ...state.currentGame, ...updates }
        : state.currentGame,
    }));
  },

  releaseGame: (gameId) => {
    const state = get();
    const game = state.games.find(g => g.id === gameId);
    if (!game) return;

    const quality = state.calculateGameQuality(game.stats, game.genre, game.engine);
    const salesLength = Math.max(4, Math.floor(quality / 10)); // 4-10 weeks based on quality

    const updatedGame: Partial<Game> = {
      isReleased: true,
      isInDevelopment: false,
      qualityScore: quality,
      releaseDate: new Date(),
      salesData: {
        ...game.salesData,
        salesLength,
        isActive: true,
      }
    };

    state.updateGame(gameId, updatedGame);
    state.addNotification({
      type: 'success',
      title: 'Game Released!',
      message: `${game.name} has been released with a quality score of ${quality}!`,
    });
  },

  calculateGameQuality: (stats, genre, engine) => {
    const state = get();
    const genreData = state.research.genres.find(g => g.id === genre);
    const engineData = state.research.engines.find(e => e.id === engine);

    if (!genreData || !engineData) return 0;

    // Calculate weighted score based on genre importance
    const weightedScore =
      (stats.design + engineData.designBonus) * genreData.designImportance +
      (stats.gameplay + engineData.gameplayBonus) * genreData.gameplayImportance +
      (stats.audio + engineData.audioBonus) * genreData.audioImportance +
      (stats.technical + engineData.technicalBonus) * genreData.technicalImportance;

    // Scale to 0-100
    return Math.min(100, Math.max(0, weightedScore));
  },

  updateSales: () => {
    set((state) => {
      const updatedGames = state.games.map((game) => {
        if (!game.salesData.isActive || game.salesData.currentWeek >= game.salesData.salesLength) {
          return game;
        }

        const week = game.salesData.currentWeek + 1;
        const baseMultiplier = Math.max(0.1, 1 - (week - 1) * 0.15); // Sales decay over time
        const qualityMultiplier = game.qualityScore / 100;
        const platformMultiplier = game.platforms.reduce((acc, platformId) => {
          const platform = state.research.platforms.find(p => p.id === platformId);
          return acc + (platform ? platform.marketShare / 100 : 0);
        }, 0);

        const weeklySales = Math.floor(
          1000 * qualityMultiplier * baseMultiplier * platformMultiplier * (Math.random() * 0.5 + 0.75)
        );

        const revenue = weeklySales * game.salePrice;

        const newSalesData: SalesData = {
          ...game.salesData,
          currentWeek: week,
          currentWeeklySales: weeklySales,
          totalSales: game.salesData.totalSales + weeklySales,
          revenue: game.salesData.revenue + revenue,
          salesHistory: [
            ...game.salesData.salesHistory,
            { week, sales: weeklySales, revenue }
          ],
          isActive: week < game.salesData.salesLength,
        };

        return { ...game, salesData: newSalesData };
      });

      // Calculate total revenue to add to company
      const weeklyRevenue = updatedGames.reduce((total, game) => {
        const lastSale = game.salesData.salesHistory[game.salesData.salesHistory.length - 1];
        return total + (lastSale ? lastSale.revenue : 0);
      }, 0);

      return {
        games: updatedGames,
        company: {
          ...state.company,
          money: state.company.money + weeklyRevenue,
        },
      };
    });
  },

  spendMoney: (amount) => {
    const state = get();
    if (state.company.money >= amount) {
      set((state) => ({
        company: { ...state.company, money: state.company.money - amount },
      }));
      return true;
    }
    return false;
  },

  addMoney: (amount) => {
    set((state) => ({
      company: { ...state.company, money: state.company.money + amount },
    }));
  },

  addResearchPoints: (points) => {
    set((state) => ({
      company: { ...state.company, researchPoints: state.company.researchPoints + points },
    }));
  },

  unlockResearch: (type, id) => {
    const state = get();
    const research = state.research[`${type}s` as keyof typeof state.research] as any[];
    const item = research.find((item: any) => item.id === id);

    if (!item || item.isUnlocked || state.company.money < item.researchCost) {
      return false;
    }

    if (state.spendMoney(item.researchCost)) {
      set((state) => ({
        research: {
          ...state.research,
          [`${type}s`]: research.map((item: any) =>
            item.id === id ? { ...item, isUnlocked: true } : item
          ),
        },
      }));

      state.addNotification({
        type: 'success',
        title: 'Research Complete!',
        message: `${item.name} has been unlocked!`,
      });

      return true;
    }

    return false;
  },

  advanceWeek: () => {
    const state = get();
    state.updateSales();
    set((state) => ({
      gameWeek: state.gameWeek + 1,
    }));
  },

  pauseGame: () => {
    set({ isGamePaused: true });
  },

  resumeGame: () => {
    set({ isGamePaused: false });
  },

  addNotification: (notification) => {
    const newNotification = {
      ...notification,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date(),
      isRead: false,
    };

    set((state) => ({
      notifications: [newNotification, ...state.notifications].slice(0, 50), // Keep last 50
    }));
  },

  markNotificationRead: (id) => {
    set((state) => ({
      notifications: state.notifications.map((notification) =>
        notification.id === id ? { ...notification, isRead: true } : notification
      ),
    }));
  },
}));
