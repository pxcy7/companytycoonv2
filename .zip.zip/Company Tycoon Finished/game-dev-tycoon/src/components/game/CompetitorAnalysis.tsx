'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  TrendingUpIcon,
  TrendingDownIcon,
  TargetIcon,
  EyeIcon,
  DollarSignIcon,
  GamepadIcon,
  UsersIcon,
  BarChart3Icon,
  AlertTriangleIcon,
  StarIcon,
  CrownIcon,
  ShieldIcon,
  SwordIcon,
  BuildingIcon,
  CalendarIcon
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';

interface Competitor {
  id: string;
  name: string;
  founded: number; // Year founded
  reputation: number; // 0-100
  marketShare: number; // 0-100%
  totalRevenue: number;
  employeeCount: number;
  gamesReleased: number;
  specialty: string[];
  strengths: string[];
  weaknesses: string[];
  recentGames: CompetitorGame[];
  strategy: CompetitorStrategy;
  personality: CompetitorPersonality;
  currentFocus: string;
  logo: string;
  color: string;
  threat_level: 'low' | 'medium' | 'high' | 'extreme';
}

interface CompetitorGame {
  id: string;
  name: string;
  genre: string;
  platform: string[];
  releaseDate: Date;
  sales: number;
  rating: number;
  developmentCost: number;
  marketingBudget: number;
}

interface CompetitorStrategy {
  focus: 'quality' | 'quantity' | 'innovation' | 'marketing' | 'budget';
  aggressiveness: number; // 0-100
  marketingSpend: number; // Percentage of revenue
  rdSpend: number; // Percentage of revenue
  expansion_rate: number; // How fast they grow
}

interface CompetitorPersonality {
  risk_taking: number; // 0-100
  innovation: number; // 0-100
  competition: number; // How much they directly compete with player
  cooperation: number; // Likelihood of partnerships
}

interface MarketEvent {
  id: string;
  type: 'acquisition' | 'merger' | 'bankruptcy' | 'ipo' | 'scandal' | 'breakthrough';
  companyId: string;
  title: string;
  description: string;
  impact: string;
  date: Date;
  market_effect: number; // -100 to 100
}

const COMPETITORS: Competitor[] = [
  {
    id: 'megacorp_games',
    name: 'MegaCorp Games',
    founded: 1985,
    reputation: 85,
    marketShare: 25,
    totalRevenue: 50000000,
    employeeCount: 2500,
    gamesReleased: 150,
    specialty: ['AAA', 'Action', 'Sports'],
    strengths: ['Massive budgets', 'Marketing power', 'Brand recognition'],
    weaknesses: ['Slow innovation', 'Risk averse', 'Corporate bureaucracy'],
    recentGames: [],
    strategy: {
      focus: 'marketing',
      aggressiveness: 80,
      marketingSpend: 35,
      rdSpend: 15,
      expansion_rate: 20
    },
    personality: {
      risk_taking: 30,
      innovation: 40,
      competition: 85,
      cooperation: 25
    },
    currentFocus: 'Dominating AAA market',
    logo: '🏢',
    color: '#dc2626',
    threat_level: 'extreme'
  },
  {
    id: 'indie_collective',
    name: 'Indie Collective',
    founded: 2010,
    reputation: 75,
    marketShare: 15,
    totalRevenue: 8000000,
    employeeCount: 150,
    gamesReleased: 80,
    specialty: ['Indie', 'Puzzle', 'Art'],
    strengths: ['Creative freedom', 'Innovation', 'Community support'],
    weaknesses: ['Limited budgets', 'Small marketing reach', 'Inconsistent quality'],
    recentGames: [],
    strategy: {
      focus: 'innovation',
      aggressiveness: 45,
      marketingSpend: 15,
      rdSpend: 30,
      expansion_rate: 40
    },
    personality: {
      risk_taking: 85,
      innovation: 95,
      competition: 40,
      cooperation: 80
    },
    currentFocus: 'Pushing creative boundaries',
    logo: '🎨',
    color: '#7c3aed',
    threat_level: 'medium'
  },
  {
    id: 'retro_studios',
    name: 'Retro Studios',
    founded: 1995,
    reputation: 70,
    marketShare: 12,
    totalRevenue: 12000000,
    employeeCount: 400,
    gamesReleased: 60,
    specialty: ['Retro', 'Platformer', 'Adventure'],
    strengths: ['Nostalgic appeal', 'Consistent quality', 'Loyal fanbase'],
    weaknesses: ['Limited innovation', 'Narrow market', 'Aging demographic'],
    recentGames: [],
    strategy: {
      focus: 'quality',
      aggressiveness: 35,
      marketingSpend: 20,
      rdSpend: 25,
      expansion_rate: 15
    },
    personality: {
      risk_taking: 40,
      innovation: 30,
      competition: 50,
      cooperation: 60
    },
    currentFocus: 'Perfecting classic gameplay',
    logo: '🕹️',
    color: '#059669',
    threat_level: 'low'
  },
  {
    id: 'future_tech',
    name: 'Future Tech Interactive',
    founded: 2015,
    reputation: 80,
    marketShare: 18,
    totalRevenue: 25000000,
    employeeCount: 800,
    gamesReleased: 35,
    specialty: ['VR', 'AI', 'Simulation'],
    strengths: ['Cutting-edge technology', 'Research expertise', 'Future vision'],
    weaknesses: ['Unproven market', 'High costs', 'Technical complexity'],
    recentGames: [],
    strategy: {
      focus: 'innovation',
      aggressiveness: 70,
      marketingSpend: 25,
      rdSpend: 40,
      expansion_rate: 60
    },
    personality: {
      risk_taking: 90,
      innovation: 100,
      competition: 70,
      cooperation: 45
    },
    currentFocus: 'Pioneering next-gen gaming',
    logo: '🚀',
    color: '#0ea5e9',
    threat_level: 'high'
  },
  {
    id: 'mobile_masters',
    name: 'Mobile Masters',
    founded: 2012,
    reputation: 65,
    marketShare: 22,
    totalRevenue: 35000000,
    employeeCount: 600,
    gamesReleased: 200,
    specialty: ['Mobile', 'Casual', 'F2P'],
    strengths: ['Mobile expertise', 'Monetization', 'Global reach'],
    weaknesses: ['Platform dependency', 'Quality perception', 'Market saturation'],
    recentGames: [],
    strategy: {
      focus: 'quantity',
      aggressiveness: 90,
      marketingSpend: 40,
      rdSpend: 10,
      expansion_rate: 80
    },
    personality: {
      risk_taking: 60,
      innovation: 50,
      competition: 95,
      cooperation: 20
    },
    currentFocus: 'Mobile market domination',
    logo: '📱',
    color: '#f59e0b',
    threat_level: 'high'
  }
];

const MARKET_EVENTS: MarketEvent[] = [
  {
    id: 'megacorp_acquisition',
    type: 'acquisition',
    companyId: 'megacorp_games',
    title: 'MegaCorp Acquires Smaller Studio',
    description: 'MegaCorp Games has acquired Pixel Dreams Studio for $50M, expanding their indie portfolio.',
    impact: 'Increased market dominance in indie space',
    date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    market_effect: -15
  },
  {
    id: 'future_tech_breakthrough',
    type: 'breakthrough',
    companyId: 'future_tech',
    title: 'Revolutionary AI Technology',
    description: 'Future Tech Interactive unveils groundbreaking AI that creates dynamic game worlds in real-time.',
    impact: 'Industry paradigm shift towards AI-driven content',
    date: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
    market_effect: -25
  },
  {
    id: 'mobile_scandal',
    type: 'scandal',
    companyId: 'mobile_masters',
    title: 'Privacy Concerns Emerge',
    description: 'Mobile Masters faces backlash over aggressive data collection practices in their latest games.',
    impact: 'Temporary reputation damage and user exodus',
    date: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000),
    market_effect: 10
  }
];

interface CompetitorAnalysisProps {
  currentWeek: number;
  currentYear: number;
  playerCompany: any;
  playerGames: any[];
}

export function CompetitorAnalysis({
  currentWeek,
  currentYear,
  playerCompany,
  playerGames
}: CompetitorAnalysisProps) {
  const [competitors, setCompetitors] = useState<Competitor[]>(COMPETITORS);
  const [marketEvents, setMarketEvents] = useState<MarketEvent[]>(MARKET_EVENTS);
  const [selectedCompetitor, setSelectedCompetitor] = useState<string>('');
  const [selectedTab, setSelectedTab] = useState('overview');
  const [selectedTimeframe, setSelectedTimeframe] = useState('3months');

  // Update competitor data based on game progression
  useEffect(() => {
    updateCompetitorProgress();
  }, [currentWeek]);

  const updateCompetitorProgress = () => {
    setCompetitors(prev => prev.map(competitor => {
      // Simulate competitor growth and activity
      const growthRate = competitor.strategy.expansion_rate / 100;
      const weeklyGrowth = growthRate / 52;

      return {
        ...competitor,
        totalRevenue: Math.floor(competitor.totalRevenue * (1 + weeklyGrowth)),
        employeeCount: Math.floor(competitor.employeeCount * (1 + weeklyGrowth * 0.5)),
        reputation: Math.min(100, competitor.reputation + (Math.random() - 0.5) * 2),
        marketShare: Math.max(5, Math.min(50, competitor.marketShare + (Math.random() - 0.5) * 1))
      };
    }));
  };

  const getThreatLevelColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-400 bg-green-900/20 border-green-500/30';
      case 'medium': return 'text-yellow-400 bg-yellow-900/20 border-yellow-500/30';
      case 'high': return 'text-orange-400 bg-orange-900/20 border-orange-500/30';
      case 'extreme': return 'text-red-400 bg-red-900/20 border-red-500/30';
      default: return 'text-zinc-400 bg-zinc-900/20 border-zinc-500/30';
    }
  };

  const getEventTypeIcon = (type: string) => {
    switch (type) {
      case 'acquisition': return BuildingIcon;
      case 'merger': return UsersIcon;
      case 'bankruptcy': return TrendingDownIcon;
      case 'ipo': return TrendingUpIcon;
      case 'scandal': return AlertTriangleIcon;
      case 'breakthrough': return StarIcon;
      default: return CalendarIcon;
    }
  };

  const selectedCompetitorData = competitors.find(c => c.id === selectedCompetitor);

  // Market share data for pie chart
  const marketShareData = [
    { name: 'Your Company', value: playerCompany.marketShare || 5, color: '#10b981' },
    ...competitors.map(c => ({
      name: c.name,
      value: c.marketShare,
      color: c.color
    })),
    {
      name: 'Others',
      value: Math.max(0, 100 - (playerCompany.marketShare || 5) - competitors.reduce((sum, c) => sum + c.marketShare, 0)),
      color: '#6b7280'
    }
  ];

  // Sample competitive analysis data
  const competitiveMetrics = [
    { week: currentWeek - 12, player: 15, megacorp: 85, indie: 45, future: 60, mobile: 75 },
    { week: currentWeek - 8, player: 25, megacorp: 88, indie: 50, future: 65, mobile: 78 },
    { week: currentWeek - 4, player: 35, megacorp: 85, indie: 48, future: 70, mobile: 72 },
    { week: currentWeek, player: playerCompany.reputation || 10, megacorp: 85, indie: 52, future: 75, mobile: 68 }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <TargetIcon className="h-6 w-6 text-red-400" />
            Competitor Analysis
          </h2>
          <p className="text-zinc-400 mt-1">Monitor rival companies and market dynamics</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1month">1 Month</SelectItem>
              <SelectItem value="3months">3 Months</SelectItem>
              <SelectItem value="1year">1 Year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Market Overview</TabsTrigger>
          <TabsTrigger value="competitors">Competitor Profiles</TabsTrigger>
          <TabsTrigger value="events">Market Events</TabsTrigger>
          <TabsTrigger value="intelligence">Competitive Intelligence</TabsTrigger>
        </TabsList>

        {/* Market Overview */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Market Share */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3Icon className="h-5 w-5 text-blue-400" />
                  Market Share Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={marketShareData}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}%`}
                    >
                      {marketShareData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Reputation Comparison */}
            <Card>
              <CardHeader>
                <CardTitle>Reputation Trends</CardTitle>
                <CardDescription>Reputation over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={competitiveMetrics}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="week" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '6px'
                      }}
                    />
                    <Line type="monotone" dataKey="player" stroke="#10b981" strokeWidth={3} name="Your Company" />
                    <Line type="monotone" dataKey="megacorp" stroke="#dc2626" strokeWidth={2} name="MegaCorp" />
                    <Line type="monotone" dataKey="indie" stroke="#7c3aed" strokeWidth={2} name="Indie Collective" />
                    <Line type="monotone" dataKey="future" stroke="#0ea5e9" strokeWidth={2} name="Future Tech" />
                    <Line type="monotone" dataKey="mobile" stroke="#f59e0b" strokeWidth={2} name="Mobile Masters" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Threat Assessment */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangleIcon className="h-5 w-5 text-yellow-400" />
                Threat Assessment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                {competitors.map((competitor) => (
                  <motion.div
                    key={competitor.id}
                    whileHover={{ scale: 1.05 }}
                    className={`p-4 rounded-lg border cursor-pointer transition-all ${getThreatLevelColor(competitor.threat_level)}`}
                    onClick={() => {
                      setSelectedCompetitor(competitor.id);
                      setSelectedTab('competitors');
                    }}
                  >
                    <div className="text-center">
                      <div className="text-3xl mb-2">{competitor.logo}</div>
                      <h4 className="font-semibold text-sm">{competitor.name}</h4>
                      <Badge className={`mt-2 ${getThreatLevelColor(competitor.threat_level)}`}>
                        {competitor.threat_level.toUpperCase()}
                      </Badge>
                      <div className="mt-2 text-xs">
                        <div>Market Share: {competitor.marketShare}%</div>
                        <div>Reputation: {competitor.reputation}</div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Competitor Profiles */}
        <TabsContent value="competitors" className="space-y-6">
          {/* Competitor Selection */}
          <div className="flex flex-wrap gap-2">
            {competitors.map((competitor) => (
              <Button
                key={competitor.id}
                variant={selectedCompetitor === competitor.id ? "default" : "outline"}
                onClick={() => setSelectedCompetitor(competitor.id)}
                className="flex items-center gap-2"
              >
                <span>{competitor.logo}</span>
                {competitor.name}
              </Button>
            ))}
          </div>

          {/* Selected Competitor Details */}
          {selectedCompetitorData && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Company Profile */}
              <Card className="lg:col-span-1">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <span className="text-3xl">{selectedCompetitorData.logo}</span>
                    <div>
                      <div>{selectedCompetitorData.name}</div>
                      <Badge className={getThreatLevelColor(selectedCompetitorData.threat_level)}>
                        {selectedCompetitorData.threat_level.toUpperCase()} THREAT
                      </Badge>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-zinc-400">Founded:</span>
                      <div className="font-semibold">{selectedCompetitorData.founded}</div>
                    </div>
                    <div>
                      <span className="text-zinc-400">Employees:</span>
                      <div className="font-semibold">{selectedCompetitorData.employeeCount.toLocaleString()}</div>
                    </div>
                    <div>
                      <span className="text-zinc-400">Games:</span>
                      <div className="font-semibold">{selectedCompetitorData.gamesReleased}</div>
                    </div>
                    <div>
                      <span className="text-zinc-400">Revenue:</span>
                      <div className="font-semibold">${(selectedCompetitorData.totalRevenue / 1000000).toFixed(1)}M</div>
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h4 className="font-semibold text-sm mb-2">Specialties</h4>
                    <div className="flex flex-wrap gap-1">
                      {selectedCompetitorData.specialty.map((spec) => (
                        <Badge key={spec} variant="outline" className="text-xs">
                          {spec}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-sm mb-2">Current Focus</h4>
                    <p className="text-sm text-zinc-300">{selectedCompetitorData.currentFocus}</p>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Market Position</h4>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Market Share:</span>
                        <span>{selectedCompetitorData.marketShare}%</span>
                      </div>
                      <Progress value={selectedCompetitorData.marketShare} className="h-1" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Reputation:</span>
                        <span>{selectedCompetitorData.reputation}/100</span>
                      </div>
                      <Progress value={selectedCompetitorData.reputation} className="h-1" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Strategy & Analysis */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Strategic Analysis</CardTitle>
                  <CardDescription>Detailed breakdown of competitive positioning</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Strengths & Weaknesses */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-green-400 flex items-center gap-2 mb-3">
                        <ShieldIcon className="h-4 w-4" />
                        Strengths
                      </h4>
                      <ul className="space-y-2">
                        {selectedCompetitorData.strengths.map((strength, index) => (
                          <li key={index} className="text-sm text-zinc-300 flex items-start gap-2">
                            <span className="text-green-400 mt-1">•</span>
                            {strength}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-red-400 flex items-center gap-2 mb-3">
                        <SwordIcon className="h-4 w-4" />
                        Weaknesses
                      </h4>
                      <ul className="space-y-2">
                        {selectedCompetitorData.weaknesses.map((weakness, index) => (
                          <li key={index} className="text-sm text-zinc-300 flex items-start gap-2">
                            <span className="text-red-400 mt-1">•</span>
                            {weakness}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <Separator />

                  {/* Strategy Metrics */}
                  <div>
                    <h4 className="font-semibold mb-4">Strategic Focus & Metrics</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-zinc-800/50 rounded">
                        <div className="text-sm text-zinc-400">Primary Focus</div>
                        <div className="font-semibold capitalize">{selectedCompetitorData.strategy.focus}</div>
                      </div>
                      <div className="text-center p-3 bg-zinc-800/50 rounded">
                        <div className="text-sm text-zinc-400">Aggressiveness</div>
                        <div className="font-semibold">{selectedCompetitorData.strategy.aggressiveness}%</div>
                      </div>
                      <div className="text-center p-3 bg-zinc-800/50 rounded">
                        <div className="text-sm text-zinc-400">Marketing Spend</div>
                        <div className="font-semibold">{selectedCompetitorData.strategy.marketingSpend}%</div>
                      </div>
                      <div className="text-center p-3 bg-zinc-800/50 rounded">
                        <div className="text-sm text-zinc-400">R&D Investment</div>
                        <div className="font-semibold">{selectedCompetitorData.strategy.rdSpend}%</div>
                      </div>
                    </div>
                  </div>

                  {/* Personality Traits */}
                  <div>
                    <h4 className="font-semibold mb-4">Company Personality</h4>
                    <div className="space-y-3">
                      {[
                        { label: 'Risk Taking', value: selectedCompetitorData.personality.risk_taking },
                        { label: 'Innovation', value: selectedCompetitorData.personality.innovation },
                        { label: 'Competition', value: selectedCompetitorData.personality.competition },
                        { label: 'Cooperation', value: selectedCompetitorData.personality.cooperation }
                      ].map((trait) => (
                        <div key={trait.label} className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span>{trait.label}:</span>
                            <span>{trait.value}/100</span>
                          </div>
                          <Progress value={trait.value} className="h-2" />
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        {/* Market Events */}
        <TabsContent value="events" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarIcon className="h-5 w-5 text-purple-400" />
                Recent Market Events
              </CardTitle>
              <CardDescription>Industry news and competitor activities</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px] pr-4">
                <div className="space-y-4">
                  <AnimatePresence>
                    {marketEvents.map((event, index) => {
                      const Icon = getEventTypeIcon(event.type);
                      const company = competitors.find(c => c.id === event.companyId);

                      return (
                        <motion.div
                          key={event.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.1 }}
                          className="border border-zinc-700 rounded-lg p-4"
                        >
                          <div className="flex items-start gap-4">
                            <div className="p-2 bg-zinc-800 rounded-lg">
                              <Icon className="h-5 w-5 text-blue-400" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-start justify-between">
                                <div>
                                  <h4 className="font-semibold">{event.title}</h4>
                                  {company && (
                                    <div className="flex items-center gap-2 mt-1">
                                      <span>{company.logo}</span>
                                      <span className="text-sm text-zinc-400">{company.name}</span>
                                    </div>
                                  )}
                                </div>
                                <div className="text-right">
                                  <Badge variant="outline" className={`
                                    ${event.type === 'acquisition' ? 'border-red-400 text-red-400' :
                                      event.type === 'breakthrough' ? 'border-green-400 text-green-400' :
                                      event.type === 'scandal' ? 'border-yellow-400 text-yellow-400' :
                                      'border-blue-400 text-blue-400'}
                                  `}>
                                    {event.type}
                                  </Badge>
                                  <div className="text-xs text-zinc-500 mt-1">
                                    {event.date.toLocaleDateString()}
                                  </div>
                                </div>
                              </div>
                              <p className="text-sm text-zinc-300 mt-2">{event.description}</p>
                              <div className="mt-3 p-2 bg-zinc-800/50 rounded border border-zinc-700">
                                <div className="text-xs text-zinc-400 mb-1">Market Impact:</div>
                                <div className="text-sm">{event.impact}</div>
                                {event.market_effect !== 0 && (
                                  <div className={`text-xs mt-1 ${
                                    event.market_effect > 0 ? 'text-green-400' : 'text-red-400'
                                  }`}>
                                    {event.market_effect > 0 ? '+' : ''}{event.market_effect}% competitive pressure
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Competitive Intelligence */}
        <TabsContent value="intelligence" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <EyeIcon className="h-5 w-5 text-orange-400" />
                Competitive Intelligence
              </CardTitle>
              <CardDescription>Strategic insights and recommendations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Market Positioning */}
              <div>
                <h4 className="font-semibold mb-4">Your Market Position</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-green-900/20 border border-green-600/30 rounded">
                    <h5 className="font-semibold text-green-400">Opportunities</h5>
                    <ul className="text-sm mt-2 space-y-1">
                      <li>• VR market still emerging</li>
                      <li>• Indie innovation space</li>
                      <li>• Mobile quality gap</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-red-900/20 border border-red-600/30 rounded">
                    <h5 className="font-semibold text-red-400">Threats</h5>
                    <ul className="text-sm mt-2 space-y-1">
                      <li>• MegaCorp market dominance</li>
                      <li>• Mobile Masters aggression</li>
                      <li>• Future Tech innovation</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-blue-900/20 border border-blue-600/30 rounded">
                    <h5 className="font-semibold text-blue-400">Recommendations</h5>
                    <ul className="text-sm mt-2 space-y-1">
                      <li>• Focus on quality over quantity</li>
                      <li>• Invest in unique features</li>
                      <li>• Build strategic partnerships</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Competitive Metrics */}
              <div>
                <h4 className="font-semibold mb-4">Performance vs Competitors</h4>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={[
                    { name: 'Your Company', reputation: playerCompany.reputation || 10, marketShare: playerCompany.marketShare || 5 },
                    ...competitors.map(c => ({ name: c.name.split(' ')[0], reputation: c.reputation, marketShare: c.marketShare }))
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="name" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '6px'
                      }}
                    />
                    <Bar dataKey="reputation" fill="#10b981" name="Reputation" />
                    <Bar dataKey="marketShare" fill="#3b82f6" name="Market Share" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
