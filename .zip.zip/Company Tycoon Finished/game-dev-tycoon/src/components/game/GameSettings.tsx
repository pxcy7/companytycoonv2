'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import {
  SettingsIcon,
  Volume2Icon,
  VolumeXIcon,
  MonitorIcon,
  GamepadIcon,
  SaveIcon,
  RotateCcwIcon,
  InfoIcon,
  PaletteIcon,
  ClockIcon,
  BellIcon,
  ShieldIcon,
  DownloadIcon
} from 'lucide-react';
import { useGameStore } from '@/store/gameStore';
import { toast } from 'sonner';

interface GameSettings {
  audio: {
    masterVolume: number;
    musicVolume: number;
    sfxVolume: number;
    uiSoundEnabled: boolean;
    muteWhenInactive: boolean;
  };
  graphics: {
    theme: 'dark' | 'light' | 'auto';
    colorScheme: 'default' | 'blue' | 'green' | 'purple' | 'red';
    animationsEnabled: boolean;
    reducedMotion: boolean;
    fps: 30 | 60 | 120;
    particleEffects: boolean;
  };
  gameplay: {
    autoSave: boolean;
    autoSaveInterval: number; // minutes
    pauseOnFocusLoss: boolean;
    gameSpeed: 0.5 | 1 | 1.5 | 2 | 3;
    tutorialEnabled: boolean;
    confirmations: boolean;
    detailedTooltips: boolean;
  };
  notifications: {
    showNotifications: boolean;
    gameEvents: boolean;
    marketing: boolean;
    employees: boolean;
    research: boolean;
    sales: boolean;
    soundNotifications: boolean;
  };
  privacy: {
    analytics: boolean;
    crashReporting: boolean;
    usageData: boolean;
  };
  advanced: {
    developerMode: boolean;
    debugMode: boolean;
    performanceMonitor: boolean;
    experimentalFeatures: boolean;
  };
}

const DEFAULT_SETTINGS: GameSettings = {
  audio: {
    masterVolume: 80,
    musicVolume: 60,
    sfxVolume: 70,
    uiSoundEnabled: true,
    muteWhenInactive: true
  },
  graphics: {
    theme: 'dark',
    colorScheme: 'default',
    animationsEnabled: true,
    reducedMotion: false,
    fps: 60,
    particleEffects: true
  },
  gameplay: {
    autoSave: true,
    autoSaveInterval: 5,
    pauseOnFocusLoss: true,
    gameSpeed: 1,
    tutorialEnabled: true,
    confirmations: true,
    detailedTooltips: true
  },
  notifications: {
    showNotifications: true,
    gameEvents: true,
    marketing: true,
    employees: true,
    research: true,
    sales: true,
    soundNotifications: false
  },
  privacy: {
    analytics: false,
    crashReporting: true,
    usageData: false
  },
  advanced: {
    developerMode: false,
    debugMode: false,
    performanceMonitor: false,
    experimentalFeatures: false
  }
};

export function GameSettings() {
  const [settings, setSettings] = useState<GameSettings>(DEFAULT_SETTINGS);
  const [activeTab, setActiveTab] = useState('audio');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const { addNotification } = useGameStore();

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedSettings = localStorage.getItem('gameDevTycoon_settings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setSettings({ ...DEFAULT_SETTINGS, ...parsed });
      } catch (error) {
        console.error('Failed to load settings:', error);
        toast.error('Failed to load settings, using defaults');
      }
    }
  }, []);

  const updateSetting = (category: keyof GameSettings, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value
      }
    }));
    setHasUnsavedChanges(true);
  };

  const saveSettings = () => {
    try {
      localStorage.setItem('gameDevTycoon_settings', JSON.stringify(settings));
      setHasUnsavedChanges(false);
      toast.success('Settings saved successfully!');
      addNotification({
        type: 'success',
        title: 'Settings Saved',
        message: 'Your preferences have been updated.'
      });
    } catch (error) {
      toast.error('Failed to save settings');
      console.error('Settings save error:', error);
    }
  };

  const resetSettings = () => {
    setSettings(DEFAULT_SETTINGS);
    setHasUnsavedChanges(true);
    toast.info('Settings reset to defaults');
  };

  const exportSettings = () => {
    const dataStr = JSON.stringify(settings, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'game-dev-tycoon-settings.json';
    link.click();
    URL.revokeObjectURL(url);
    toast.success('Settings exported successfully!');
  };

  const importSettings = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedSettings = JSON.parse(e.target?.result as string);
        setSettings({ ...DEFAULT_SETTINGS, ...importedSettings });
        setHasUnsavedChanges(true);
        toast.success('Settings imported successfully!');
      } catch (error) {
        toast.error('Invalid settings file');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <SettingsIcon className="h-6 w-6 text-zinc-400" />
            Game Settings
          </h2>
          <p className="text-zinc-400 mt-1">Customize your game experience</p>
        </div>
        <div className="flex items-center gap-2">
          {hasUnsavedChanges && (
            <Badge variant="outline" className="text-yellow-400 border-yellow-400">
              Unsaved Changes
            </Badge>
          )}
          <Button onClick={saveSettings} disabled={!hasUnsavedChanges}>
            <SaveIcon className="h-4 w-4 mr-2" />
            Save Settings
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="audio">Audio</TabsTrigger>
          <TabsTrigger value="graphics">Graphics</TabsTrigger>
          <TabsTrigger value="gameplay">Gameplay</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="privacy">Privacy</TabsTrigger>
          <TabsTrigger value="advanced">Advanced</TabsTrigger>
        </TabsList>

        {/* Audio Settings */}
        <TabsContent value="audio" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Volume2Icon className="h-5 w-5" />
                Audio Settings
              </CardTitle>
              <CardDescription>Configure volume levels and audio preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label>Master Volume: {settings.audio.masterVolume}%</Label>
                  <Slider
                    value={[settings.audio.masterVolume]}
                    onValueChange={([value]) => updateSetting('audio', 'masterVolume', value)}
                    max={100}
                    step={1}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Music Volume: {settings.audio.musicVolume}%</Label>
                  <Slider
                    value={[settings.audio.musicVolume]}
                    onValueChange={([value]) => updateSetting('audio', 'musicVolume', value)}
                    max={100}
                    step={1}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Sound Effects: {settings.audio.sfxVolume}%</Label>
                  <Slider
                    value={[settings.audio.sfxVolume]}
                    onValueChange={([value]) => updateSetting('audio', 'sfxVolume', value)}
                    max={100}
                    step={1}
                    className="mt-2"
                  />
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>UI Sound Effects</Label>
                  <Switch
                    checked={settings.audio.uiSoundEnabled}
                    onCheckedChange={(checked) => updateSetting('audio', 'uiSoundEnabled', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>Mute When Inactive</Label>
                  <Switch
                    checked={settings.audio.muteWhenInactive}
                    onCheckedChange={(checked) => updateSetting('audio', 'muteWhenInactive', checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Graphics Settings */}
        <TabsContent value="graphics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MonitorIcon className="h-5 w-5" />
                Graphics & Display
              </CardTitle>
              <CardDescription>Customize visual appearance and performance</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label>Theme</Label>
                    <Select
                      value={settings.graphics.theme}
                      onValueChange={(value) => updateSetting('graphics', 'theme', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dark">Dark</SelectItem>
                        <SelectItem value="light">Light</SelectItem>
                        <SelectItem value="auto">Auto (System)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Color Scheme</Label>
                    <Select
                      value={settings.graphics.colorScheme}
                      onValueChange={(value) => updateSetting('graphics', 'colorScheme', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="default">Default (Zinc)</SelectItem>
                        <SelectItem value="blue">Blue</SelectItem>
                        <SelectItem value="green">Green</SelectItem>
                        <SelectItem value="purple">Purple</SelectItem>
                        <SelectItem value="red">Red</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Frame Rate</Label>
                    <Select
                      value={settings.graphics.fps.toString()}
                      onValueChange={(value) => updateSetting('graphics', 'fps', Number.parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30">30 FPS</SelectItem>
                        <SelectItem value="60">60 FPS</SelectItem>
                        <SelectItem value="120">120 FPS</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Animations</Label>
                    <Switch
                      checked={settings.graphics.animationsEnabled}
                      onCheckedChange={(checked) => updateSetting('graphics', 'animationsEnabled', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Reduced Motion</Label>
                    <Switch
                      checked={settings.graphics.reducedMotion}
                      onCheckedChange={(checked) => updateSetting('graphics', 'reducedMotion', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Particle Effects</Label>
                    <Switch
                      checked={settings.graphics.particleEffects}
                      onCheckedChange={(checked) => updateSetting('graphics', 'particleEffects', checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Gameplay Settings */}
        <TabsContent value="gameplay" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GamepadIcon className="h-5 w-5" />
                Gameplay Settings
              </CardTitle>
              <CardDescription>Configure game behavior and difficulty</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label>Game Speed: {settings.gameplay.gameSpeed}x</Label>
                    <Select
                      value={settings.gameplay.gameSpeed.toString()}
                      onValueChange={(value) => updateSetting('gameplay', 'gameSpeed', Number.parseFloat(value))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0.5">0.5x (Slow)</SelectItem>
                        <SelectItem value="1">1x (Normal)</SelectItem>
                        <SelectItem value="1.5">1.5x (Fast)</SelectItem>
                        <SelectItem value="2">2x (Faster)</SelectItem>
                        <SelectItem value="3">3x (Fastest)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Auto-Save Interval: {settings.gameplay.autoSaveInterval} minutes</Label>
                    <Slider
                      value={[settings.gameplay.autoSaveInterval]}
                      onValueChange={([value]) => updateSetting('gameplay', 'autoSaveInterval', value)}
                      max={30}
                      min={1}
                      step={1}
                      className="mt-2"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Auto-Save</Label>
                    <Switch
                      checked={settings.gameplay.autoSave}
                      onCheckedChange={(checked) => updateSetting('gameplay', 'autoSave', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Pause on Focus Loss</Label>
                    <Switch
                      checked={settings.gameplay.pauseOnFocusLoss}
                      onCheckedChange={(checked) => updateSetting('gameplay', 'pauseOnFocusLoss', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Tutorial Enabled</Label>
                    <Switch
                      checked={settings.gameplay.tutorialEnabled}
                      onCheckedChange={(checked) => updateSetting('gameplay', 'tutorialEnabled', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Confirmation Dialogs</Label>
                    <Switch
                      checked={settings.gameplay.confirmations}
                      onCheckedChange={(checked) => updateSetting('gameplay', 'confirmations', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Detailed Tooltips</Label>
                    <Switch
                      checked={settings.gameplay.detailedTooltips}
                      onCheckedChange={(checked) => updateSetting('gameplay', 'detailedTooltips', checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Settings */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BellIcon className="h-5 w-5" />
                Notification Settings
              </CardTitle>
              <CardDescription>Control which events trigger notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Show Notifications</Label>
                    <Switch
                      checked={settings.notifications.showNotifications}
                      onCheckedChange={(checked) => updateSetting('notifications', 'showNotifications', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Game Events</Label>
                    <Switch
                      checked={settings.notifications.gameEvents}
                      onCheckedChange={(checked) => updateSetting('notifications', 'gameEvents', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Marketing Updates</Label>
                    <Switch
                      checked={settings.notifications.marketing}
                      onCheckedChange={(checked) => updateSetting('notifications', 'marketing', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Employee Updates</Label>
                    <Switch
                      checked={settings.notifications.employees}
                      onCheckedChange={(checked) => updateSetting('notifications', 'employees', checked)}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Research Complete</Label>
                    <Switch
                      checked={settings.notifications.research}
                      onCheckedChange={(checked) => updateSetting('notifications', 'research', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Sales Milestones</Label>
                    <Switch
                      checked={settings.notifications.sales}
                      onCheckedChange={(checked) => updateSetting('notifications', 'sales', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Sound Notifications</Label>
                    <Switch
                      checked={settings.notifications.soundNotifications}
                      onCheckedChange={(checked) => updateSetting('notifications', 'soundNotifications', checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Privacy Settings */}
        <TabsContent value="privacy" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldIcon className="h-5 w-5" />
                Privacy Settings
              </CardTitle>
              <CardDescription>Control data collection and reporting</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Analytics</Label>
                    <p className="text-xs text-zinc-500">Help improve the game by sharing anonymous usage data</p>
                  </div>
                  <Switch
                    checked={settings.privacy.analytics}
                    onCheckedChange={(checked) => updateSetting('privacy', 'analytics', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Crash Reporting</Label>
                    <p className="text-xs text-zinc-500">Automatically report crashes to help fix bugs</p>
                  </div>
                  <Switch
                    checked={settings.privacy.crashReporting}
                    onCheckedChange={(checked) => updateSetting('privacy', 'crashReporting', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Usage Data</Label>
                    <p className="text-xs text-zinc-500">Share feature usage statistics</p>
                  </div>
                  <Switch
                    checked={settings.privacy.usageData}
                    onCheckedChange={(checked) => updateSetting('privacy', 'usageData', checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Advanced Settings */}
        <TabsContent value="advanced" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <InfoIcon className="h-5 w-5" />
                Advanced Settings
              </CardTitle>
              <CardDescription>Developer options and experimental features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Developer Mode</Label>
                    <p className="text-xs text-zinc-500">Enable developer tools and console</p>
                  </div>
                  <Switch
                    checked={settings.advanced.developerMode}
                    onCheckedChange={(checked) => updateSetting('advanced', 'developerMode', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Debug Mode</Label>
                    <p className="text-xs text-zinc-500">Show detailed debug information</p>
                  </div>
                  <Switch
                    checked={settings.advanced.debugMode}
                    onCheckedChange={(checked) => updateSetting('advanced', 'debugMode', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Performance Monitor</Label>
                    <p className="text-xs text-zinc-500">Display FPS and memory usage</p>
                  </div>
                  <Switch
                    checked={settings.advanced.performanceMonitor}
                    onCheckedChange={(checked) => updateSetting('advanced', 'performanceMonitor', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Experimental Features</Label>
                    <p className="text-xs text-zinc-500">Enable beta features (may be unstable)</p>
                  </div>
                  <Switch
                    checked={settings.advanced.experimentalFeatures}
                    onCheckedChange={(checked) => updateSetting('advanced', 'experimentalFeatures', checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Settings Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Settings Management</CardTitle>
          <CardDescription>Import, export, or reset your settings</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button onClick={exportSettings} variant="outline">
              <DownloadIcon className="h-4 w-4 mr-2" />
              Export Settings
            </Button>

            <div>
              <input
                type="file"
                accept=".json"
                onChange={importSettings}
                className="hidden"
                id="import-settings"
              />
              <Button asChild variant="outline">
                <label htmlFor="import-settings" className="cursor-pointer">
                  Import Settings
                </label>
              </Button>
            </div>

            <Button onClick={resetSettings} variant="destructive">
              <RotateCcwIcon className="h-4 w-4 mr-2" />
              Reset to Defaults
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
