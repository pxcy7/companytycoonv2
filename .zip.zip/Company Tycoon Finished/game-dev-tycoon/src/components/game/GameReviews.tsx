'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  StarIcon,
  TrendingUpIcon,
  TrendingDownIcon,
  NewspaperIcon,
  UsersIcon,
  ThumbsUpIcon,
  ThumbsDownIcon,
  QuoteIcon,
  AwardIcon,
  BarChart3Icon,
  CalendarIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface GameReview {
  id: string;
  gameId: string;
  reviewer: string;
  publication: string;
  score: number; // 0-100
  reviewText: string;
  pros: string[];
  cons: string[];
  timestamp: Date;
  publication_type: 'professional' | 'user' | 'influencer';
  credibility: number; // 0-100
  influence: number; // How much this review affects sales
}

interface ReviewPublication {
  id: string;
  name: string;
  type: 'professional' | 'user' | 'influencer';
  credibility: number;
  audience_size: number;
  genre_expertise: string[];
  review_style: 'harsh' | 'balanced' | 'lenient';
  icon: string;
}

const REVIEW_PUBLICATIONS: ReviewPublication[] = [
  {
    id: 'gamespot',
    name: 'GameSpot',
    type: 'professional',
    credibility: 95,
    audience_size: 5000000,
    genre_expertise: ['action', 'adventure', 'rpg'],
    review_style: 'balanced',
    icon: '🎮'
  },
  {
    id: 'ign',
    name: 'IGN',
    type: 'professional',
    credibility: 90,
    audience_size: 8000000,
    genre_expertise: ['action', 'shooter', 'racing'],
    review_style: 'lenient',
    icon: '🔥'
  },
  {
    id: 'metacritic',
    name: 'Metacritic',
    type: 'professional',
    credibility: 98,
    audience_size: 3000000,
    genre_expertise: ['all'],
    review_style: 'harsh',
    icon: '📊'
  },
  {
    id: 'steam_users',
    name: 'Steam Users',
    type: 'user',
    credibility: 75,
    audience_size: 20000000,
    genre_expertise: ['all'],
    review_style: 'harsh',
    icon: '👥'
  },
  {
    id: 'youtube_gaming',
    name: 'YouTube Gaming',
    type: 'influencer',
    credibility: 80,
    audience_size: 15000000,
    genre_expertise: ['action', 'indie'],
    review_style: 'balanced',
    icon: '📺'
  },
  {
    id: 'twitch_streamers',
    name: 'Twitch Streamers',
    type: 'influencer',
    credibility: 70,
    audience_size: 12000000,
    genre_expertise: ['multiplayer', 'action'],
    review_style: 'lenient',
    icon: '📡'
  }
];

const REVIEW_QUOTES = {
  positive: [
    "A masterpiece that redefines the genre",
    "An instant classic that will be remembered for years",
    "Exceptional gameplay with stunning visuals",
    "A game that exceeds all expectations",
    "Brilliant design choices throughout",
    "An immersive experience from start to finish",
    "Sets a new standard for the industry"
  ],
  mixed: [
    "Great potential but falls short in execution",
    "Solid gameplay with some notable flaws",
    "Good ideas that could use better implementation",
    "Enjoyable despite its shortcomings",
    "A decent entry in the series",
    "Has its moments but feels incomplete",
    "Fun but forgettable experience"
  ],
  negative: [
    "A disappointing entry that misses the mark",
    "Technical issues overshadow the gameplay",
    "Lacks the polish expected from this developer",
    "Feels rushed and unfinished",
    "Fails to live up to the hype",
    "A step backwards for the franchise",
    "Difficult to recommend at full price"
  ]
};

interface GameReviewsProps {
  gameId?: string;
  games: any[];
  currentWeek: number;
}

export function GameReviews({ gameId, games, currentWeek }: GameReviewsProps) {
  const [selectedGame, setSelectedGame] = useState<string>(gameId || '');
  const [reviews, setReviews] = useState<GameReview[]>([]);
  const [reviewStats, setReviewStats] = useState({
    averageScore: 0,
    totalReviews: 0,
    userScore: 0,
    criticScore: 0,
    influencerScore: 0
  });

  const releasedGames = games.filter(g => g.isReleased);
  const currentGame = selectedGame ? releasedGames.find(g => g.id === selectedGame) : null;

  // Generate reviews when game is selected
  useEffect(() => {
    if (currentGame) {
      generateReviews(currentGame);
    }
  }, [currentGame]);

  const generateReviews = (game: any) => {
    const gameReviews: GameReview[] = [];
    const reviewCount = Math.floor(Math.random() * 8) + 5; // 5-12 reviews

    for (let i = 0; i < reviewCount; i++) {
      const publication = REVIEW_PUBLICATIONS[Math.floor(Math.random() * REVIEW_PUBLICATIONS.length)];
      const review = generateSingleReview(game, publication);
      gameReviews.push(review);
    }

    setReviews(gameReviews);
    calculateReviewStats(gameReviews);
  };

  const generateSingleReview = (game: any, publication: ReviewPublication): GameReview => {
    // Base score influenced by game quality
    let baseScore = game.qualityScore;

    // Adjust based on publication style
    switch (publication.review_style) {
      case 'harsh':
        baseScore -= 15;
        break;
      case 'lenient':
        baseScore += 10;
        break;
      case 'balanced':
        // No adjustment
        break;
    }

    // Genre expertise bonus/penalty
    const hasExpertise = publication.genre_expertise.includes('all') ||
                        publication.genre_expertise.includes(game.genre);
    if (hasExpertise) {
      baseScore += 5;
    } else {
      baseScore -= 3;
    }

    // Random variance
    baseScore += (Math.random() - 0.5) * 20;
    const finalScore = Math.max(0, Math.min(100, Math.round(baseScore)));

    // Generate review text based on score
    let reviewCategory: keyof typeof REVIEW_QUOTES;
    if (finalScore >= 75) reviewCategory = 'positive';
    else if (finalScore >= 50) reviewCategory = 'mixed';
    else reviewCategory = 'negative';

    const reviewText = REVIEW_QUOTES[reviewCategory][
      Math.floor(Math.random() * REVIEW_QUOTES[reviewCategory].length)
    ];

    // Generate pros and cons
    const allPros = [
      'Excellent gameplay mechanics',
      'Beautiful visual design',
      'Immersive audio experience',
      'Strong narrative elements',
      'Innovative features',
      'Great performance optimization',
      'Intuitive user interface',
      'Engaging multiplayer modes',
      'High replay value',
      'Responsive controls'
    ];

    const allCons = [
      'Occasional bugs and glitches',
      'Limited content variety',
      'Repetitive gameplay loops',
      'Poor optimization on some platforms',
      'Weak story elements',
      'Unbalanced difficulty curve',
      'Lackluster audio design',
      'Outdated graphics',
      'Short campaign length',
      'Confusing user interface'
    ];

    const prosCount = finalScore >= 75 ? 3 : finalScore >= 50 ? 2 : 1;
    const consCount = finalScore >= 75 ? 1 : finalScore >= 50 ? 2 : 3;

    const pros = allPros.sort(() => 0.5 - Math.random()).slice(0, prosCount);
    const cons = allCons.sort(() => 0.5 - Math.random()).slice(0, consCount);

    return {
      id: Math.random().toString(36).substr(2, 9),
      gameId: game.id,
      reviewer: `${publication.name} Review Team`,
      publication: publication.name,
      score: finalScore,
      reviewText,
      pros,
      cons,
      timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000), // Random time in last week
      publication_type: publication.type,
      credibility: publication.credibility,
      influence: publication.audience_size / 1000000 * (publication.credibility / 100)
    };
  };

  const calculateReviewStats = (gameReviews: GameReview[]) => {
    if (gameReviews.length === 0) {
      setReviewStats({
        averageScore: 0,
        totalReviews: 0,
        userScore: 0,
        criticScore: 0,
        influencerScore: 0
      });
      return;
    }

    const totalScore = gameReviews.reduce((sum, review) => sum + review.score, 0);
    const averageScore = Math.round(totalScore / gameReviews.length);

    const criticReviews = gameReviews.filter(r => r.publication_type === 'professional');
    const userReviews = gameReviews.filter(r => r.publication_type === 'user');
    const influencerReviews = gameReviews.filter(r => r.publication_type === 'influencer');

    const criticScore = criticReviews.length > 0
      ? Math.round(criticReviews.reduce((sum, r) => sum + r.score, 0) / criticReviews.length)
      : 0;

    const userScore = userReviews.length > 0
      ? Math.round(userReviews.reduce((sum, r) => sum + r.score, 0) / userReviews.length)
      : 0;

    const influencerScore = influencerReviews.length > 0
      ? Math.round(influencerReviews.reduce((sum, r) => sum + r.score, 0) / influencerReviews.length)
      : 0;

    setReviewStats({
      averageScore,
      totalReviews: gameReviews.length,
      userScore,
      criticScore,
      influencerScore
    });
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-400';
    if (score >= 75) return 'text-blue-400';
    if (score >= 60) return 'text-yellow-400';
    if (score >= 40) return 'text-orange-400';
    return 'text-red-400';
  };

  const getScoreBadgeColor = (score: number) => {
    if (score >= 90) return 'bg-green-600';
    if (score >= 75) return 'bg-blue-600';
    if (score >= 60) return 'bg-yellow-600';
    if (score >= 40) return 'bg-orange-600';
    return 'bg-red-600';
  };

  const formatReviewDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  if (releasedGames.length === 0) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <NewspaperIcon className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-zinc-400 mb-2">No Games to Review</h3>
          <p className="text-zinc-500">Release your first game to see reviews and ratings</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <NewspaperIcon className="h-6 w-6 text-purple-400" />
            Game Reviews & Ratings
          </h2>
          <p className="text-zinc-400 mt-1">Track critical reception and public opinion</p>
        </div>
      </div>

      {/* Game Selection */}
      <div className="flex flex-wrap gap-2">
        {releasedGames.map((game) => (
          <button
            key={game.id}
            onClick={() => setSelectedGame(game.id)}
            className={`px-4 py-2 rounded-lg border transition-colors ${
              selectedGame === game.id
                ? 'border-purple-500 bg-purple-500/20 text-white'
                : 'border-zinc-600 text-zinc-300 hover:border-zinc-500'
            }`}
          >
            {game.name}
          </button>
        ))}
      </div>

      {/* Review Content */}
      {currentGame && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Review Scores Overview */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3Icon className="h-5 w-5 text-purple-400" />
                Review Scores
              </CardTitle>
              <CardDescription>{currentGame.name}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Overall Score */}
              <div className="text-center">
                <div className={`text-4xl font-bold ${getScoreColor(reviewStats.averageScore)}`}>
                  {reviewStats.averageScore}
                </div>
                <div className="text-sm text-zinc-400">Overall Score</div>
                <div className="flex justify-center mt-2">
                  {[...Array(5)].map((_, i) => (
                    <StarIcon
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(reviewStats.averageScore / 20)
                          ? 'text-yellow-400 fill-current'
                          : 'text-zinc-600'
                      }`}
                    />
                  ))}
                </div>
                <div className="text-xs text-zinc-500 mt-1">
                  Based on {reviewStats.totalReviews} reviews
                </div>
              </div>

              <Separator />

              {/* Score Breakdown */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Critic Score</span>
                  <Badge className={getScoreBadgeColor(reviewStats.criticScore)}>
                    {reviewStats.criticScore}
                  </Badge>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm">User Score</span>
                  <Badge className={getScoreBadgeColor(reviewStats.userScore)}>
                    {reviewStats.userScore}
                  </Badge>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm">Influencer Score</span>
                  <Badge className={getScoreBadgeColor(reviewStats.influencerScore)}>
                    {reviewStats.influencerScore}
                  </Badge>
                </div>
              </div>

              <Separator />

              {/* Score Distribution */}
              <div className="space-y-2">
                <h4 className="text-sm font-semibold">Score Distribution</h4>
                {[90, 75, 60, 40, 0].map((threshold, index) => {
                  const label = index === 0 ? '90-100' :
                               index === 1 ? '75-89' :
                               index === 2 ? '60-74' :
                               index === 3 ? '40-59' : '0-39';

                  const count = reviews.filter(r => {
                    if (index === 0) return r.score >= 90;
                    if (index === 1) return r.score >= 75 && r.score < 90;
                    if (index === 2) return r.score >= 60 && r.score < 75;
                    if (index === 3) return r.score >= 40 && r.score < 60;
                    return r.score < 40;
                  }).length;

                  const percentage = reviewStats.totalReviews > 0 ? (count / reviewStats.totalReviews) * 100 : 0;

                  return (
                    <div key={threshold} className="flex items-center gap-2 text-xs">
                      <span className="w-12">{label}</span>
                      <Progress value={percentage} className="flex-1 h-2" />
                      <span className="w-8 text-right">{count}</span>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Reviews List */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Professional Reviews</CardTitle>
              <CardDescription>What the critics are saying</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px] pr-4">
                <div className="space-y-6">
                  <AnimatePresence>
                    {reviews
                      .sort((a, b) => b.credibility - a.credibility)
                      .map((review, index) => (
                      <motion.div
                        key={review.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                        className="border border-zinc-700 rounded-lg p-4 space-y-3"
                      >
                        {/* Review Header */}
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className="text-2xl">
                              {REVIEW_PUBLICATIONS.find(p => p.name === review.publication)?.icon || '📰'}
                            </div>
                            <div>
                              <h4 className="font-semibold">{review.publication}</h4>
                              <p className="text-sm text-zinc-400">
                                by {review.reviewer}
                              </p>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline" className={`text-xs ${
                                  review.publication_type === 'professional' ? 'border-blue-400 text-blue-400' :
                                  review.publication_type === 'influencer' ? 'border-purple-400 text-purple-400' :
                                  'border-green-400 text-green-400'
                                }`}>
                                  {review.publication_type}
                                </Badge>
                                <span className="text-xs text-zinc-500">
                                  {formatReviewDate(review.timestamp)}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className={`text-2xl font-bold ${getScoreColor(review.score)}`}>
                              {review.score}
                            </div>
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <StarIcon
                                  key={i}
                                  className={`h-4 w-4 ${
                                    i < Math.floor(review.score / 20)
                                      ? 'text-yellow-400 fill-current'
                                      : 'text-zinc-600'
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Review Quote */}
                        <div className="bg-zinc-800/50 p-3 rounded-lg border-l-4 border-purple-500">
                          <QuoteIcon className="h-4 w-4 text-purple-400 mb-2" />
                          <p className="text-sm italic text-zinc-300">"{review.reviewText}"</p>
                        </div>

                        {/* Pros and Cons */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <h5 className="text-sm font-semibold text-green-400 flex items-center gap-1 mb-2">
                              <ThumbsUpIcon className="h-4 w-4" />
                              Pros
                            </h5>
                            <ul className="text-xs space-y-1">
                              {review.pros.map((pro, i) => (
                                <li key={i} className="text-zinc-300">• {pro}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h5 className="text-sm font-semibold text-red-400 flex items-center gap-1 mb-2">
                              <ThumbsDownIcon className="h-4 w-4" />
                              Cons
                            </h5>
                            <ul className="text-xs space-y-1">
                              {review.cons.map((con, i) => (
                                <li key={i} className="text-zinc-300">• {con}</li>
                              ))}
                            </ul>
                          </div>
                        </div>

                        {/* Review Impact */}
                        <div className="flex justify-between items-center text-xs text-zinc-500 pt-2 border-t border-zinc-700">
                          <span>Credibility: {review.credibility}%</span>
                          <span>Impact: {review.influence.toFixed(1)}</span>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
