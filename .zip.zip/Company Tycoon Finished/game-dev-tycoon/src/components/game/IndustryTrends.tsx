'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import {
  TrendingUpIcon,
  TrendingDownIcon,
  ZapIcon,
  EyeIcon,
  CloudIcon,
  SmartphoneIcon,
  MonitorIcon,
  GamepadIcon,
  WifiIcon,
  StarIcon,
  AlertCircleIcon,
  CalendarIcon,
  DollarSignIcon,
  TargetIcon,
  BarChart3Icon
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';

interface Technology {
  id: string;
  name: string;
  category: TechCategory;
  description: string;
  icon: any;
  adoptionRate: number; // 0-100
  marketPotential: number; // 0-100
  technicalComplexity: number; // 0-100
  investmentRequired: number; // Base cost to research/adopt
  timeToMarket: number; // Weeks to implement
  emergenceYear: number;
  peakYear: number;
  declineYear?: number;
  currentTrend: 'emerging' | 'growing' | 'mainstream' | 'declining' | 'dead';
  factors: TrendFactor[];
  opportunities: Opportunity[];
  threats: Threat[];
}

type TechCategory = 'platform' | 'graphics' | 'interaction' | 'distribution' | 'development' | 'monetization';

interface TrendFactor {
  id: string;
  name: string;
  impact: number; // -100 to +100
  description: string;
  type: 'technological' | 'economic' | 'social' | 'regulatory' | 'competitive';
}

interface Opportunity {
  id: string;
  title: string;
  description: string;
  marketSize: number;
  difficulty: 'low' | 'medium' | 'high';
  timeframe: 'short' | 'medium' | 'long';
  requiredInvestment: number;
}

interface Threat {
  id: string;
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  probability: number; // 0-100
  impact: string;
}

interface MarketTrend {
  week: number;
  vr: number;
  ar: number;
  cloud: number;
  mobile: number;
  streaming: number;
  ai: number;
}

interface IndustryTrendsProps {
  currentWeek: number;
  currentYear: number;
  companyMoney: number;
  onInvestInTech: (techId: string, amount: number) => void;
}

const TECHNOLOGIES: Technology[] = [
  {
    id: 'vr_gaming',
    name: 'Virtual Reality Gaming',
    category: 'platform',
    description: 'Immersive gaming experiences using VR headsets and motion controls',
    icon: EyeIcon,
    adoptionRate: 15,
    marketPotential: 85,
    technicalComplexity: 80,
    investmentRequired: 150000,
    timeToMarket: 24,
    emergenceYear: 2016,
    peakYear: 2025,
    currentTrend: 'growing',
    factors: [
      {
        id: 'hardware_cost',
        name: 'Decreasing Hardware Costs',
        impact: 45,
        description: 'VR headsets becoming more affordable',
        type: 'technological'
      },
      {
        id: 'content_library',
        name: 'Growing Content Library',
        impact: 35,
        description: 'More VR games and experiences available',
        type: 'social'
      },
      {
        id: 'motion_sickness',
        name: 'Motion Sickness Concerns',
        impact: -25,
        description: 'Some users experience discomfort',
        type: 'technological'
      }
    ],
    opportunities: [
      {
        id: 'vr_fitness',
        title: 'VR Fitness Games',
        description: 'Exercise-focused VR experiences',
        marketSize: 2000000,
        difficulty: 'medium',
        timeframe: 'short',
        requiredInvestment: 75000
      },
      {
        id: 'vr_education',
        title: 'Educational VR',
        description: 'Learning experiences in virtual environments',
        marketSize: 5000000,
        difficulty: 'high',
        timeframe: 'medium',
        requiredInvestment: 120000
      }
    ],
    threats: [
      {
        id: 'tech_limitations',
        title: 'Technical Limitations',
        description: 'Current VR tech still has resolution and comfort issues',
        severity: 'medium',
        probability: 70,
        impact: 'Slower adoption than expected'
      }
    ]
  },
  {
    id: 'ar_mobile',
    name: 'Augmented Reality Mobile',
    category: 'platform',
    description: 'AR experiences on smartphones and tablets',
    icon: SmartphoneIcon,
    adoptionRate: 35,
    marketPotential: 90,
    technicalComplexity: 60,
    investmentRequired: 80000,
    timeToMarket: 16,
    emergenceYear: 2017,
    peakYear: 2024,
    currentTrend: 'mainstream',
    factors: [
      {
        id: 'smartphone_power',
        name: 'Powerful Smartphones',
        impact: 50,
        description: 'Modern phones can handle AR processing',
        type: 'technological'
      },
      {
        id: 'ar_frameworks',
        name: 'Development Frameworks',
        impact: 40,
        description: 'ARKit, ARCore making development easier',
        type: 'technological'
      }
    ],
    opportunities: [
      {
        id: 'location_ar',
        title: 'Location-Based AR',
        description: 'AR games tied to real-world locations',
        marketSize: 3000000,
        difficulty: 'medium',
        timeframe: 'short',
        requiredInvestment: 50000
      }
    ],
    threats: [
      {
        id: 'privacy_concerns',
        title: 'Privacy Issues',
        description: 'Concerns about AR apps collecting location data',
        severity: 'medium',
        probability: 60,
        impact: 'Regulatory restrictions'
      }
    ]
  },
  {
    id: 'cloud_gaming',
    name: 'Cloud Gaming',
    category: 'distribution',
    description: 'Streaming games from remote servers',
    icon: CloudIcon,
    adoptionRate: 25,
    marketPotential: 95,
    technicalComplexity: 85,
    investmentRequired: 200000,
    timeToMarket: 20,
    emergenceYear: 2019,
    peakYear: 2027,
    currentTrend: 'growing',
    factors: [
      {
        id: 'internet_speed',
        name: '5G and Fiber Internet',
        impact: 60,
        description: 'Faster internet enabling seamless streaming',
        type: 'technological'
      },
      {
        id: 'latency_issues',
        name: 'Input Latency',
        impact: -35,
        description: 'Delay between input and response',
        type: 'technological'
      }
    ],
    opportunities: [
      {
        id: 'instant_gaming',
        title: 'Instant Access Gaming',
        description: 'Play AAA games without downloads',
        marketSize: 8000000,
        difficulty: 'high',
        timeframe: 'medium',
        requiredInvestment: 150000
      }
    ],
    threats: [
      {
        id: 'infrastructure_cost',
        title: 'High Infrastructure Costs',
        description: 'Expensive server farms and bandwidth',
        severity: 'high',
        probability: 80,
        impact: 'High operational costs'
      }
    ]
  },
  {
    id: 'ai_generation',
    name: 'AI-Generated Content',
    category: 'development',
    description: 'Using AI to create game assets and content',
    icon: ZapIcon,
    adoptionRate: 20,
    marketPotential: 88,
    technicalComplexity: 75,
    investmentRequired: 100000,
    timeToMarket: 12,
    emergenceYear: 2022,
    peakYear: 2026,
    currentTrend: 'emerging',
    factors: [
      {
        id: 'ai_advancement',
        name: 'Rapid AI Development',
        impact: 70,
        description: 'AI tools becoming more sophisticated',
        type: 'technological'
      },
      {
        id: 'copyright_concerns',
        name: 'Copyright Issues',
        impact: -30,
        description: 'Legal questions about AI-generated content',
        type: 'regulatory'
      }
    ],
    opportunities: [
      {
        id: 'procedural_worlds',
        title: 'Procedural World Generation',
        description: 'AI-created game worlds and levels',
        marketSize: 4000000,
        difficulty: 'high',
        timeframe: 'medium',
        requiredInvestment: 80000
      }
    ],
    threats: [
      {
        id: 'creative_resistance',
        title: 'Artist Resistance',
        description: 'Creative professionals opposing AI tools',
        severity: 'medium',
        probability: 50,
        impact: 'Talent acquisition challenges'
      }
    ]
  },
  {
    id: 'blockchain_gaming',
    name: 'Blockchain Gaming',
    category: 'monetization',
    description: 'Games with cryptocurrency and NFT integration',
    icon: WifiIcon,
    adoptionRate: 8,
    marketPotential: 60,
    technicalComplexity: 90,
    investmentRequired: 180000,
    timeToMarket: 28,
    emergenceYear: 2021,
    peakYear: 2023,
    declineYear: 2024,
    currentTrend: 'declining',
    factors: [
      {
        id: 'crypto_volatility',
        name: 'Cryptocurrency Volatility',
        impact: -50,
        description: 'Unstable token values affecting gameplay',
        type: 'economic'
      },
      {
        id: 'environmental_concerns',
        name: 'Environmental Impact',
        impact: -40,
        description: 'Energy consumption concerns',
        type: 'social'
      }
    ],
    opportunities: [
      {
        id: 'digital_ownership',
        title: 'True Digital Ownership',
        description: 'Players owning game assets',
        marketSize: 1500000,
        difficulty: 'high',
        timeframe: 'long',
        requiredInvestment: 120000
      }
    ],
    threats: [
      {
        id: 'regulatory_crackdown',
        title: 'Government Regulation',
        description: 'Increasing regulation of crypto and NFTs',
        severity: 'high',
        probability: 75,
        impact: 'Market restrictions'
      }
    ]
  },
  {
    id: 'cross_platform',
    name: 'Cross-Platform Gaming',
    category: 'platform',
    description: 'Games playable across all devices seamlessly',
    icon: MonitorIcon,
    adoptionRate: 55,
    marketPotential: 85,
    technicalComplexity: 65,
    investmentRequired: 90000,
    timeToMarket: 18,
    emergenceYear: 2018,
    peakYear: 2023,
    currentTrend: 'mainstream',
    factors: [
      {
        id: 'platform_cooperation',
        name: 'Platform Holders Cooperation',
        impact: 45,
        description: 'Sony, Microsoft, Nintendo working together',
        type: 'competitive'
      },
      {
        id: 'unified_accounts',
        name: 'Universal Gaming Accounts',
        impact: 35,
        description: 'Single accounts across platforms',
        type: 'technological'
      }
    ],
    opportunities: [
      {
        id: 'unified_ecosystem',
        title: 'Gaming Ecosystem',
        description: 'Single game, all platforms',
        marketSize: 10000000,
        difficulty: 'medium',
        timeframe: 'short',
        requiredInvestment: 60000
      }
    ],
    threats: [
      {
        id: 'platform_wars',
        title: 'Platform Wars Revival',
        description: 'Companies restricting cross-platform play',
        severity: 'medium',
        probability: 30,
        impact: 'Fragmented player base'
      }
    ]
  }
];

export function IndustryTrends({
  currentWeek,
  currentYear,
  companyMoney,
  onInvestInTech
}: IndustryTrendsProps) {
  const [selectedTech, setSelectedTech] = useState<string>('');
  const [activeTab, setActiveTab] = useState('overview');
  const [trendData, setTrendData] = useState<MarketTrend[]>([]);

  // Generate trend data based on current week
  useEffect(() => {
    const generateTrendData = () => {
      const data: MarketTrend[] = [];
      for (let i = Math.max(0, currentWeek - 52); i <= currentWeek; i++) {
        const baseYear = 1980 + Math.floor(i / 52);

        data.push({
          week: i,
          vr: Math.max(0, Math.min(100, (baseYear - 2015) * 8 + Math.random() * 10)),
          ar: Math.max(0, Math.min(100, (baseYear - 2016) * 12 + Math.random() * 15)),
          cloud: Math.max(0, Math.min(100, (baseYear - 2018) * 15 + Math.random() * 10)),
          mobile: Math.max(0, Math.min(100, (baseYear - 2007) * 6 + Math.random() * 8)),
          streaming: Math.max(0, Math.min(100, (baseYear - 2019) * 20 + Math.random() * 12)),
          ai: Math.max(0, Math.min(100, (baseYear - 2021) * 25 + Math.random() * 15))
        });
      }
      setTrendData(data);
    };

    generateTrendData();
  }, [currentWeek]);

  const availableTechs = TECHNOLOGIES.filter(tech =>
    currentYear >= tech.emergenceYear &&
    (!tech.declineYear || currentYear <= tech.declineYear + 5)
  );

  const selectedTechData = TECHNOLOGIES.find(t => t.id === selectedTech);

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'emerging': return 'text-green-400 bg-green-900/20 border-green-500/30';
      case 'growing': return 'text-blue-400 bg-blue-900/20 border-blue-500/30';
      case 'mainstream': return 'text-purple-400 bg-purple-900/20 border-purple-500/30';
      case 'declining': return 'text-orange-400 bg-orange-900/20 border-orange-500/30';
      case 'dead': return 'text-red-400 bg-red-900/20 border-red-500/30';
      default: return 'text-zinc-400 bg-zinc-900/20 border-zinc-500/30';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'low': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'high': return 'text-red-400';
      default: return 'text-zinc-400';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'high': return 'text-orange-400';
      case 'critical': return 'text-red-400';
      default: return 'text-zinc-400';
    }
  };

  // Radar chart data for technology comparison
  const radarData = availableTechs.map(tech => ({
    technology: tech.name.split(' ')[0],
    adoption: tech.adoptionRate,
    potential: tech.marketPotential,
    complexity: tech.technicalComplexity
  }));

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <TrendingUpIcon className="h-6 w-6 text-green-400" />
            Industry Trends & Technologies
          </h2>
          <p className="text-zinc-400 mt-1">Track emerging technologies and market opportunities</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-zinc-400">Investment Budget</div>
          <div className="text-xl font-bold text-green-400">${companyMoney.toLocaleString()}</div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Market Overview</TabsTrigger>
          <TabsTrigger value="technologies">Technologies</TabsTrigger>
          <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
          <TabsTrigger value="analysis">Trend Analysis</TabsTrigger>
        </TabsList>

        {/* Market Overview */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Trend Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Technology Adoption Trends</CardTitle>
                <CardDescription>Market penetration over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="week" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '6px'
                      }}
                    />
                    <Line type="monotone" dataKey="vr" stroke="#ef4444" strokeWidth={2} name="VR Gaming" />
                    <Line type="monotone" dataKey="ar" stroke="#3b82f6" strokeWidth={2} name="AR Mobile" />
                    <Line type="monotone" dataKey="cloud" stroke="#10b981" strokeWidth={2} name="Cloud Gaming" />
                    <Line type="monotone" dataKey="ai" stroke="#8b5cf6" strokeWidth={2} name="AI Content" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Technology Radar */}
            <Card>
              <CardHeader>
                <CardTitle>Technology Comparison</CardTitle>
                <CardDescription>Adoption vs Potential vs Complexity</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="#374151" />
                    <PolarAngleAxis dataKey="technology" tick={{ fontSize: 12 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 10 }} />
                    <Radar
                      name="Adoption"
                      dataKey="adoption"
                      stroke="#3b82f6"
                      fill="#3b82f6"
                      fillOpacity={0.2}
                    />
                    <Radar
                      name="Potential"
                      dataKey="potential"
                      stroke="#10b981"
                      fill="#10b981"
                      fillOpacity={0.2}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Emerging Technologies</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-400">
                  {availableTechs.filter(t => t.currentTrend === 'emerging').length}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Growing Markets</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-400">
                  {availableTechs.filter(t => t.currentTrend === 'growing').length}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Mainstream Tech</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-400">
                  {availableTechs.filter(t => t.currentTrend === 'mainstream').length}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Investment Needed</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-400">
                  ${Math.round(availableTechs.reduce((sum, t) => sum + t.investmentRequired, 0) / 1000)}K
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Technologies Tab */}
        <TabsContent value="technologies" className="space-y-6">
          {/* Technology Selection */}
          <div className="flex flex-wrap gap-2">
            {availableTechs.map((tech) => {
              const Icon = tech.icon;
              return (
                <Button
                  key={tech.id}
                  variant={selectedTech === tech.id ? "default" : "outline"}
                  onClick={() => setSelectedTech(tech.id)}
                  className="flex items-center gap-2"
                >
                  <Icon className="h-4 w-4" />
                  {tech.name}
                </Button>
              );
            })}
          </div>

          {/* Technology Details */}
          {selectedTechData && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Tech Overview */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <selectedTechData.icon className="h-5 w-5 text-blue-400" />
                    {selectedTechData.name}
                  </CardTitle>
                  <CardDescription>{selectedTechData.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Badge className={getTrendColor(selectedTechData.currentTrend)}>
                      {selectedTechData.currentTrend.toUpperCase()}
                    </Badge>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Market Adoption:</span>
                        <span>{selectedTechData.adoptionRate}%</span>
                      </div>
                      <Progress value={selectedTechData.adoptionRate} className="h-2" />
                    </div>

                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Market Potential:</span>
                        <span>{selectedTechData.marketPotential}%</span>
                      </div>
                      <Progress value={selectedTechData.marketPotential} className="h-2" />
                    </div>

                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Technical Complexity:</span>
                        <span>{selectedTechData.technicalComplexity}%</span>
                      </div>
                      <Progress value={selectedTechData.technicalComplexity} className="h-2" />
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Investment Required:</span>
                      <span className="font-bold text-green-400">
                        ${selectedTechData.investmentRequired.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Time to Market:</span>
                      <span className="font-bold">{selectedTechData.timeToMarket} weeks</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Emerged:</span>
                      <span>{selectedTechData.emergenceYear}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Peak Expected:</span>
                      <span>{selectedTechData.peakYear}</span>
                    </div>
                  </div>

                  <Button
                    onClick={() => onInvestInTech(selectedTechData.id, selectedTechData.investmentRequired)}
                    disabled={companyMoney < selectedTechData.investmentRequired}
                    className="w-full"
                  >
                    {companyMoney >= selectedTechData.investmentRequired ? 'Invest in Technology' : 'Insufficient Funds'}
                  </Button>
                </CardContent>
              </Card>

              {/* Factors */}
              <Card>
                <CardHeader>
                  <CardTitle>Market Factors</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedTechData.factors.map((factor) => (
                    <div key={factor.id} className="p-3 border border-zinc-700 rounded">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-sm">{factor.name}</h4>
                        <Badge className={factor.impact > 0 ? 'bg-green-600' : 'bg-red-600'}>
                          {factor.impact > 0 ? '+' : ''}{factor.impact}
                        </Badge>
                      </div>
                      <p className="text-xs text-zinc-400">{factor.description}</p>
                      <div className="text-xs text-zinc-500 mt-1 capitalize">{factor.type}</div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Opportunities & Threats */}
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-green-400">Opportunities</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {selectedTechData.opportunities.map((opp) => (
                      <div key={opp.id} className="p-3 bg-green-900/20 border border-green-600/30 rounded">
                        <h4 className="font-semibold text-sm text-green-300">{opp.title}</h4>
                        <p className="text-xs text-zinc-300 mt-1">{opp.description}</p>
                        <div className="flex justify-between mt-2 text-xs">
                          <span>Market: ${(opp.marketSize / 1000000).toFixed(1)}M</span>
                          <span className={getDifficultyColor(opp.difficulty)}>
                            {opp.difficulty} difficulty
                          </span>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-red-400">Threats</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {selectedTechData.threats.map((threat) => (
                      <div key={threat.id} className="p-3 bg-red-900/20 border border-red-600/30 rounded">
                        <h4 className="font-semibold text-sm text-red-300">{threat.title}</h4>
                        <p className="text-xs text-zinc-300 mt-1">{threat.description}</p>
                        <div className="flex justify-between mt-2 text-xs">
                          <span className={getSeverityColor(threat.severity)}>
                            {threat.severity} severity
                          </span>
                          <span>{threat.probability}% probability</span>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Technology Grid */}
          {!selectedTechData && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {availableTechs.map((tech) => {
                const Icon = tech.icon;
                return (
                  <motion.div
                    key={tech.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    whileHover={{ scale: 1.02 }}
                    className="cursor-pointer"
                    onClick={() => setSelectedTech(tech.id)}
                  >
                    <Card className="hover:border-zinc-600 transition-colors">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center gap-2">
                          <Icon className="h-5 w-5 text-blue-400" />
                          {tech.name}
                        </CardTitle>
                        <CardDescription>{tech.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Badge className={getTrendColor(tech.currentTrend)}>
                            {tech.currentTrend}
                          </Badge>
                          <span className="text-sm text-zinc-400">{tech.category}</span>
                        </div>

                        <div className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span>Adoption:</span>
                            <span>{tech.adoptionRate}%</span>
                          </div>
                          <Progress value={tech.adoptionRate} className="h-1" />
                        </div>

                        <div className="flex justify-between text-sm">
                          <span>Investment:</span>
                          <span className="font-bold">${(tech.investmentRequired / 1000).toFixed(0)}K</span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* Opportunities Tab */}
        <TabsContent value="opportunities" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {availableTechs.flatMap(tech =>
              tech.opportunities.map(opp => ({
                ...opp,
                techName: tech.name,
                techId: tech.id,
                techIcon: tech.icon
              }))
            ).map((opp) => {
              const Icon = opp.techIcon;
              return (
                <Card key={`${opp.techId}-${opp.id}`} className="hover:border-zinc-600 transition-colors">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Icon className="h-5 w-5 text-blue-400" />
                      {opp.title}
                    </CardTitle>
                    <CardDescription>{opp.techName}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-zinc-300">{opp.description}</p>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-zinc-400">Market Size:</span>
                        <div className="font-bold text-green-400">
                          ${(opp.marketSize / 1000000).toFixed(1)}M
                        </div>
                      </div>
                      <div>
                        <span className="text-zinc-400">Investment:</span>
                        <div className="font-bold">${opp.requiredInvestment.toLocaleString()}</div>
                      </div>
                      <div>
                        <span className="text-zinc-400">Difficulty:</span>
                        <div className={`font-bold ${getDifficultyColor(opp.difficulty)}`}>
                          {opp.difficulty}
                        </div>
                      </div>
                      <div>
                        <span className="text-zinc-400">Timeframe:</span>
                        <div className="font-bold">{opp.timeframe}-term</div>
                      </div>
                    </div>

                    <Button
                      onClick={() => onInvestInTech(opp.techId, opp.requiredInvestment)}
                      disabled={companyMoney < opp.requiredInvestment}
                      className="w-full"
                      size="sm"
                    >
                      Pursue Opportunity
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* Analysis Tab */}
        <TabsContent value="analysis" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Market Maturity Analysis */}
            <Card>
              <CardHeader>
                <CardTitle>Technology Lifecycle</CardTitle>
                <CardDescription>Where each technology stands in its lifecycle</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {availableTechs.map((tech) => {
                    const lifecycle = currentYear - tech.emergenceYear;
                    const maturity = Math.min(100, (lifecycle / (tech.peakYear - tech.emergenceYear)) * 100);

                    return (
                      <div key={tech.id} className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm font-medium">{tech.name}</span>
                          <span className="text-xs text-zinc-400">{lifecycle} years old</span>
                        </div>
                        <Progress value={maturity} className="h-1" />
                        <div className="flex justify-between text-xs text-zinc-500">
                          <span>Emerged {tech.emergenceYear}</span>
                          <span>Peak {tech.peakYear}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Investment Recommendations */}
            <Card>
              <CardHeader>
                <CardTitle>Investment Recommendations</CardTitle>
                <CardDescription>Based on market potential and company budget</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {availableTechs
                    .filter(tech => tech.investmentRequired <= companyMoney * 2) // Affordable-ish
                    .sort((a, b) => (b.marketPotential - b.technicalComplexity) - (a.marketPotential - a.technicalComplexity))
                    .slice(0, 3)
                    .map((tech, index) => {
                      const Icon = tech.icon;
                      const score = tech.marketPotential - tech.technicalComplexity + tech.adoptionRate;

                      return (
                        <div key={tech.id} className="p-3 border border-zinc-700 rounded">
                          <div className="flex items-center gap-3">
                            <div className="text-lg font-bold text-yellow-400">#{index + 1}</div>
                            <Icon className="h-5 w-5 text-blue-400" />
                            <div className="flex-1">
                              <h4 className="font-semibold">{tech.name}</h4>
                              <p className="text-xs text-zinc-400">Score: {score.toFixed(0)}/200</p>
                            </div>
                            <div className="text-right">
                              <div className="text-sm font-bold">${(tech.investmentRequired / 1000).toFixed(0)}K</div>
                              <div className="text-xs text-zinc-400">{tech.timeToMarket}w</div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Market Timeline */}
          <Card>
            <CardHeader>
              <CardTitle>Technology Timeline</CardTitle>
              <CardDescription>Emergence and peak years of technologies</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-zinc-700"></div>
                <div className="space-y-6">
                  {availableTechs
                    .sort((a, b) => a.emergenceYear - b.emergenceYear)
                    .map((tech) => {
                      const Icon = tech.icon;
                      const isCurrentYear = currentYear >= tech.emergenceYear;
                      const isPeakYear = currentYear >= tech.peakYear;

                      return (
                        <div key={tech.id} className="relative flex items-center gap-4">
                          <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center z-10 ${
                            isPeakYear ? 'bg-green-600 border-green-400' :
                            isCurrentYear ? 'bg-blue-600 border-blue-400' :
                            'bg-zinc-800 border-zinc-600'
                          }`}>
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold">{tech.name}</h4>
                            <p className="text-sm text-zinc-400">
                              Emerged {tech.emergenceYear} • Peak {tech.peakYear}
                              {tech.declineYear && ` • Decline ${tech.declineYear}`}
                            </p>
                          </div>
                          <Badge className={getTrendColor(tech.currentTrend)}>
                            {tech.currentTrend}
                          </Badge>
                        </div>
                      );
                    })}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
