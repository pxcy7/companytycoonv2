'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { UsersIcon, PlusIcon } from 'lucide-react';

export function EmployeeManagement() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <UsersIcon className="h-6 w-6 text-blue-400" />
          Employee Management
        </h2>
        <Button>
          <PlusIcon className="h-4 w-4 mr-2" />
          Hire Employee
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Team</CardTitle>
          <CardDescription>
            Hire specialized employees to improve your game development
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <UsersIcon className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-zinc-400 mb-2">No Employees Yet</h3>
            <p className="text-zinc-500 mb-4">Start by hiring your first team member</p>
            <Button>
              <PlusIcon className="h-4 w-4 mr-2" />
              Hire Your First Employee
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {['Designer', 'Programmer', 'Audio Engineer', 'Producer'].map((role) => (
          <Card key={role} className="border-dashed border-zinc-600">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">{role}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-zinc-400 mb-4">
                Specializes in {role.toLowerCase()} tasks
              </p>
              <Button size="sm" className="w-full" disabled>
                Coming Soon
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
