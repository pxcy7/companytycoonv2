'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useGameStore } from '@/store/gameStore';
import { BeakerIcon, LockIcon, CheckCircleIcon, DollarSignIcon } from 'lucide-react';

export function ResearchLab() {
  const { research, company, unlockResearch } = useGameStore();
  const [selectedTab, setSelectedTab] = useState('topics');

  const ResearchCard = ({
    item,
    type
  }: {
    item: any;
    type: 'topic' | 'genre' | 'platform' | 'engine'
  }) => {
    const canAfford = company.money >= item.researchCost;
    const canResearch = !item.isUnlocked && canAfford;

    const handleResearch = () => {
      if (canResearch) {
        unlockResearch(type, item.id);
      }
    };

    return (
      <Card className={`transition-all ${item.isUnlocked ? 'bg-green-900/20 border-green-600/30' : canAfford ? 'hover:bg-zinc-800' : 'opacity-60'}`}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              {item.name}
              {item.isUnlocked ? (
                <CheckCircleIcon className="h-5 w-5 text-green-400" />
              ) : (
                <LockIcon className="h-5 w-5 text-zinc-400" />
              )}
            </CardTitle>
            {item.researchCost > 0 && (
              <Badge variant={canAfford ? "outline" : "destructive"}>
                ${item.researchCost.toLocaleString()}
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Type-specific info */}
          {type === 'genre' && (
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>Design: {Math.round(item.designImportance * 100)}%</div>
              <div>Gameplay: {Math.round(item.gameplayImportance * 100)}%</div>
              <div>Audio: {Math.round(item.audioImportance * 100)}%</div>
              <div>Technical: {Math.round(item.technicalImportance * 100)}%</div>
            </div>
          )}

          {type === 'platform' && (
            <div className="text-xs space-y-1">
              <div>Market Share: {item.marketShare}%</div>
              <div>Audience: {(item.audienceSize / 1000000).toFixed(1)}M</div>
              <div>Dev Cost: ${item.developmentCost.toLocaleString()}</div>
              <div>Royalty: {item.royaltyRate}%</div>
            </div>
          )}

          {type === 'engine' && (
            <div className="text-xs space-y-1">
              <div>Bonuses: +{item.designBonus} Design, +{item.gameplayBonus} Gameplay</div>
              <div>+{item.audioBonus} Audio, +{item.technicalBonus} Technical</div>
              <div>Dev Time: {Math.round(item.developmentTimeMultiplier * 100)}%</div>
            </div>
          )}

          {type === 'topic' && (
            <div className="text-xs">
              <div>Audience Multiplier: {item.audienceMultiplier}x</div>
            </div>
          )}

          {!item.isUnlocked && (
            <Button
              onClick={handleResearch}
              disabled={!canAfford}
              className="w-full"
              size="sm"
            >
              {canAfford ? 'Research' : 'Not Enough Money'}
            </Button>
          )}
        </CardContent>
      </Card>
    );
  };

  const unlockedCount = {
    topics: research.topics.filter(t => t.isUnlocked).length,
    genres: research.genres.filter(g => g.isUnlocked).length,
    platforms: research.platforms.filter(p => p.isUnlocked).length,
    engines: research.engines.filter(e => e.isUnlocked).length,
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <BeakerIcon className="h-6 w-6 text-purple-400" />
            Research Lab
          </h2>
          <p className="text-zinc-400 mt-1">Unlock new topics, genres, platforms, and engines</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-zinc-400">Available Budget</div>
          <div className="text-xl font-bold text-green-400">${company.money.toLocaleString()}</div>
        </div>
      </div>

      {/* Research Categories */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="topics" className="flex items-center gap-2">
            Topics
            <Badge variant="secondary">{unlockedCount.topics}/{research.topics.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="genres" className="flex items-center gap-2">
            Genres
            <Badge variant="secondary">{unlockedCount.genres}/{research.genres.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="platforms" className="flex items-center gap-2">
            Platforms
            <Badge variant="secondary">{unlockedCount.platforms}/{research.platforms.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="engines" className="flex items-center gap-2">
            Engines
            <Badge variant="secondary">{unlockedCount.engines}/{research.engines.length}</Badge>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="topics" className="space-y-4">
          <div className="text-sm text-zinc-400 mb-4">
            Topics determine the theme and audience of your games. Each topic has different audience appeal.
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {research.topics.map((topic) => (
              <ResearchCard key={topic.id} item={topic} type="topic" />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="genres" className="space-y-4">
          <div className="text-sm text-zinc-400 mb-4">
            Genres define gameplay mechanics and determine which skills are most important for success.
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {research.genres.map((genre) => (
              <ResearchCard key={genre.id} item={genre} type="genre" />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="platforms" className="space-y-4">
          <div className="text-sm text-zinc-400 mb-4">
            Platforms expand your potential audience. Each platform has different market characteristics and costs.
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {research.platforms.map((platform) => (
              <ResearchCard key={platform.id} item={platform} type="platform" />
            ))}
          </div>

          {/* Custom Platform Creation */}
          <Card className="border-dashed border-zinc-600">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <BeakerIcon className="h-5 w-5 text-purple-400" />
                Create Custom Console
              </CardTitle>
              <CardDescription>
                Develop your own gaming platform (Coming Soon)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button disabled className="w-full">
                Research Custom Console Technology
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="engines" className="space-y-4">
          <div className="text-sm text-zinc-400 mb-4">
            Game engines provide development tools and bonuses. Better engines offer higher quality potential but cost more.
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {research.engines.map((engine) => (
              <ResearchCard key={engine.id} item={engine} type="engine" />
            ))}
          </div>

          {/* Custom Engine Creation */}
          <Card className="border-dashed border-zinc-600">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <BeakerIcon className="h-5 w-5 text-purple-400" />
                Develop Custom Engine
              </CardTitle>
              <CardDescription>
                Create your own proprietary game engine (Coming Soon)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button disabled className="w-full">
                Start Engine Development
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
