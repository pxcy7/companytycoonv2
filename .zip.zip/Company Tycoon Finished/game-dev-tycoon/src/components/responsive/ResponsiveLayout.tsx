'use client';

import { useState, useEffect, createContext, useContext } from 'react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Drawer, DrawerContent, DrawerTrigger } from '@/components/ui/drawer';
import { MenuIcon, X, ChevronUpIcon, ChevronDownIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

type BreakpointSize = 'mobile' | 'tablet' | 'desktop';

interface ResponsiveContextType {
  breakpoint: BreakpointSize;
  isMobile: boolean;
  isTablet: boolean;
  isDesktop: boolean;
  orientation: 'portrait' | 'landscape';
  touchDevice: boolean;
}

const ResponsiveContext = createContext<ResponsiveContextType | null>(null);

export function ResponsiveProvider({ children }: { children: React.ReactNode }) {
  const [breakpoint, setBreakpoint] = useState<BreakpointSize>('desktop');
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('landscape');
  const [touchDevice, setTouchDevice] = useState(false);

  useEffect(() => {
    const updateBreakpoint = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;

      if (width < 768) {
        setBreakpoint('mobile');
      } else if (width < 1024) {
        setBreakpoint('tablet');
      } else {
        setBreakpoint('desktop');
      }

      setOrientation(height > width ? 'portrait' : 'landscape');
    };

    const detectTouch = () => {
      setTouchDevice('ontouchstart' in window || navigator.maxTouchPoints > 0);
    };

    updateBreakpoint();
    detectTouch();

    window.addEventListener('resize', updateBreakpoint);
    window.addEventListener('orientationchange', updateBreakpoint);

    return () => {
      window.removeEventListener('resize', updateBreakpoint);
      window.removeEventListener('orientationchange', updateBreakpoint);
    };
  }, []);

  const value: ResponsiveContextType = {
    breakpoint,
    isMobile: breakpoint === 'mobile',
    isTablet: breakpoint === 'tablet',
    isDesktop: breakpoint === 'desktop',
    orientation,
    touchDevice
  };

  return (
    <ResponsiveContext.Provider value={value}>
      {children}
    </ResponsiveContext.Provider>
  );
}

export function useResponsive() {
  const context = useContext(ResponsiveContext);
  if (!context) {
    throw new Error('useResponsive must be used within ResponsiveProvider');
  }
  return context;
}

// Mobile Navigation Component
interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
}

export function MobileNav({ isOpen, onClose, children }: MobileNavProps) {
  const { isMobile } = useResponsive();

  if (!isMobile) {
    return <>{children}</>;
  }

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="left" className="w-80 bg-zinc-900 border-zinc-800">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold">Navigation</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
        {children}
      </SheetContent>
    </Sheet>
  );
}

// Touch-Friendly Button Component
interface TouchButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'default' | 'outline' | 'secondary' | 'ghost';
  size?: 'sm' | 'default' | 'lg';
  className?: string;
  disabled?: boolean;
}

export function TouchButton({
  children,
  onClick,
  variant = 'default',
  size = 'default',
  className = '',
  disabled = false
}: TouchButtonProps) {
  const { touchDevice } = useResponsive();

  const touchSize = touchDevice ? {
    sm: 'min-h-[44px] min-w-[44px] px-4',
    default: 'min-h-[48px] min-w-[48px] px-6',
    lg: 'min-h-[52px] min-w-[52px] px-8'
  }[size] : '';

  return (
    <Button
      variant={variant}
      size={size}
      onClick={onClick}
      disabled={disabled}
      className={`${touchSize} ${className} ${touchDevice ? 'active:scale-95' : ''} transition-transform`}
    >
      {children}
    </Button>
  );
}

// Responsive Grid Component
interface ResponsiveGridProps {
  children: React.ReactNode;
  columns?: {
    mobile?: number;
    tablet?: number;
    desktop?: number;
  };
  gap?: number;
  className?: string;
}

export function ResponsiveGrid({
  children,
  columns = { mobile: 1, tablet: 2, desktop: 3 },
  gap = 4,
  className = ''
}: ResponsiveGridProps) {
  const { breakpoint } = useResponsive();

  const getGridCols = () => {
    switch (breakpoint) {
      case 'mobile':
        return `grid-cols-${columns.mobile || 1}`;
      case 'tablet':
        return `grid-cols-${columns.tablet || 2}`;
      case 'desktop':
        return `grid-cols-${columns.desktop || 3}`;
    }
  };

  return (
    <div className={`grid ${getGridCols()} gap-${gap} ${className}`}>
      {children}
    </div>
  );
}

// Collapsible Panel for Mobile
interface CollapsiblePanelProps {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
  icon?: React.ReactNode;
}

export function CollapsiblePanel({
  title,
  children,
  defaultOpen = false,
  icon
}: CollapsiblePanelProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const { isMobile } = useResponsive();

  if (!isMobile) {
    return <div>{children}</div>;
  }

  return (
    <div className="border border-zinc-700 rounded-lg overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-4 bg-zinc-800 flex items-center justify-between hover:bg-zinc-700 transition-colors"
      >
        <div className="flex items-center gap-3">
          {icon}
          <span className="font-medium">{title}</span>
        </div>
        {isOpen ? (
          <ChevronUpIcon className="h-5 w-5" />
        ) : (
          <ChevronDownIcon className="h-5 w-5" />
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="p-4 bg-zinc-900">
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Mobile-Optimized Tabs
interface MobileTabsProps {
  tabs: Array<{ id: string; label: string; icon?: React.ReactNode }>;
  activeTab: string;
  onTabChange: (tabId: string) => void;
  children: React.ReactNode;
}

export function MobileTabs({ tabs, activeTab, onTabChange, children }: MobileTabsProps) {
  const { isMobile } = useResponsive();

  if (!isMobile) {
    return <div>{children}</div>;
  }

  return (
    <div className="flex flex-col h-full">
      {/* Tab Navigation */}
      <div className="flex overflow-x-auto scrollbar-hide border-b border-zinc-700">
        {tabs.map((tab) => (
          <TouchButton
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            variant={activeTab === tab.id ? 'default' : 'ghost'}
            className="flex-shrink-0 rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500"
          >
            <div className="flex items-center gap-2">
              {tab.icon}
              <span className="text-sm">{tab.label}</span>
            </div>
          </TouchButton>
        ))}
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-auto">
        {children}
      </div>
    </div>
  );
}

// Responsive Card Component
interface ResponsiveCardProps {
  children: React.ReactNode;
  className?: string;
  padding?: 'sm' | 'md' | 'lg';
}

export function ResponsiveCard({
  children,
  className = '',
  padding = 'md'
}: ResponsiveCardProps) {
  const { isMobile } = useResponsive();

  const getPadding = () => {
    if (isMobile) {
      return {
        sm: 'p-2',
        md: 'p-3',
        lg: 'p-4'
      }[padding];
    }
    return {
      sm: 'p-3',
      md: 'p-4',
      lg: 'p-6'
    }[padding];
  };

  return (
    <div className={`bg-zinc-900 border border-zinc-700 rounded-lg ${getPadding()} ${className}`}>
      {children}
    </div>
  );
}

// Bottom Sheet for Mobile Actions
interface BottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
}

export function BottomSheet({ isOpen, onClose, title, children }: BottomSheetProps) {
  const { isMobile } = useResponsive();

  if (!isMobile) {
    return null;
  }

  return (
    <Drawer open={isOpen} onOpenChange={onClose}>
      <DrawerContent className="bg-zinc-900 border-zinc-700">
        <div className="p-4">
          {title && (
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">{title}</h3>
              <Button variant="ghost" size="sm" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}
          {children}
        </div>
      </DrawerContent>
    </Drawer>
  );
}

// Touch-friendly input component
interface TouchInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: 'text' | 'number' | 'email';
  label?: string;
  className?: string;
}

export function TouchInput({
  value,
  onChange,
  placeholder,
  type = 'text',
  label,
  className = ''
}: TouchInputProps) {
  const { touchDevice } = useResponsive();

  return (
    <div className={className}>
      {label && (
        <label className="block text-sm font-medium text-zinc-300 mb-2">
          {label}
        </label>
      )}
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={`
          w-full bg-zinc-800 border border-zinc-600 rounded-lg px-4 py-3
          ${touchDevice ? 'min-h-[48px]' : 'h-10'}
          text-white placeholder-zinc-400
          focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500
          transition-colors
        `}
      />
    </div>
  );
}

// Responsive layout wrapper
interface ResponsiveLayoutProps {
  children: React.ReactNode;
  sidebar?: React.ReactNode;
  rightPanel?: React.ReactNode;
  className?: string;
}

export function ResponsiveLayout({
  children,
  sidebar,
  rightPanel,
  className = ''
}: ResponsiveLayoutProps) {
  const { isMobile, isTablet } = useResponsive();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [rightPanelOpen, setRightPanelOpen] = useState(false);

  if (isMobile) {
    return (
      <div className={`flex flex-col h-screen ${className}`}>
        {/* Mobile Header */}
        <div className="flex items-center justify-between p-4 bg-zinc-900 border-b border-zinc-800">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(true)}
          >
            <MenuIcon className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold">Game Dev Tycoon</h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setRightPanelOpen(true)}
          >
            <ChevronUpIcon className="h-5 w-5" />
          </Button>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-auto">
          {children}
        </div>

        {/* Mobile Sidebar */}
        <MobileNav isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)}>
          {sidebar}
        </MobileNav>

        {/* Mobile Right Panel as Bottom Sheet */}
        <BottomSheet
          isOpen={rightPanelOpen}
          onClose={() => setRightPanelOpen(false)}
          title="Quick Stats"
        >
          {rightPanel}
        </BottomSheet>
      </div>
    );
  }

  if (isTablet) {
    return (
      <div className={`flex h-screen ${className}`}>
        {/* Tablet Sidebar - Collapsible */}
        <div className="flex-shrink-0">
          {sidebar}
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {children}
        </div>

        {/* Right Panel - Overlay on tablet */}
        {rightPanelOpen && (
          <div className="fixed inset-y-0 right-0 w-80 bg-zinc-900 border-l border-zinc-800 z-50 overflow-auto">
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Quick Stats</h3>
                <Button variant="ghost" size="sm" onClick={() => setRightPanelOpen(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              {rightPanel}
            </div>
          </div>
        )}
      </div>
    );
  }

  // Desktop layout
  return (
    <div className={`flex h-screen ${className}`}>
      {sidebar && (
        <div className="flex-shrink-0">
          {sidebar}
        </div>
      )}
      <div className="flex-1 overflow-hidden">
        {children}
      </div>
      {rightPanel && (
        <div className="flex-shrink-0 w-80 border-l border-zinc-800 overflow-auto">
          {rightPanel}
        </div>
      )}
    </div>
  );
}
