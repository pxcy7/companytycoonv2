'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import {
  PuzzleIcon,
  SwordIcon,
  MusicIcon,
  WifiIcon,
  GamepadIcon,
  CpuIcon,
  EyeIcon,
  HeartIcon,
  ShieldIcon,
  ZapIcon,
  TargetIcon,
  UsersIcon
} from 'lucide-react';
import { motion } from 'framer-motion';

interface GameFeature {
  id: string;
  name: string;
  category: FeatureCategory;
  description: string;
  developmentCost: number;
  developmentTime: number; // weeks
  requiresSkills: {
    programming?: number;
    gameDesign?: number;
    graphics?: number;
    sound?: number;
  };
  unlockYear: number;
  prerequisites?: string[]; // Other feature IDs required
  qualityBonus: number;
  genreMultipliers: {
    [genre: string]: number;
  };
  icon: any;
  isAdvanced: boolean;
}

type FeatureCategory =
  | 'gameplay'
  | 'graphics'
  | 'audio'
  | 'online'
  | 'accessibility'
  | 'monetization'
  | 'social'
  | 'technical';

const GAME_FEATURES: GameFeature[] = [
  // Gameplay Features
  {
    id: 'save_system',
    name: 'Save System',
    category: 'gameplay',
    description: 'Allow players to save their progress',
    developmentCost: 2000,
    developmentTime: 2,
    requiresSkills: { programming: 30 },
    unlockYear: 1980,
    qualityBonus: 15,
    genreMultipliers: { rpg: 2.0, strategy: 1.5, adventure: 1.8 },
    icon: ShieldIcon,
    isAdvanced: false
  },
  {
    id: 'multiplayer',
    name: 'Multiplayer',
    category: 'online',
    description: 'Support for multiple players',
    developmentCost: 10000,
    developmentTime: 8,
    requiresSkills: { programming: 70, gameDesign: 50 },
    unlockYear: 1995,
    prerequisites: ['networking'],
    qualityBonus: 25,
    genreMultipliers: { shooter: 2.5, strategy: 2.0, action: 1.8 },
    icon: UsersIcon,
    isAdvanced: true
  },
  {
    id: 'ai_companions',
    name: 'AI Companions',
    category: 'gameplay',
    description: 'Intelligent AI-controlled allies',
    developmentCost: 8000,
    developmentTime: 6,
    requiresSkills: { programming: 60, gameDesign: 70 },
    unlockYear: 1990,
    qualityBonus: 20,
    genreMultipliers: { rpg: 2.2, action: 1.5, adventure: 1.8 },
    icon: CpuIcon,
    isAdvanced: true
  },
  {
    id: 'physics_engine',
    name: 'Advanced Physics',
    category: 'technical',
    description: 'Realistic physics simulation',
    developmentCost: 15000,
    developmentTime: 10,
    requiresSkills: { programming: 80, gameDesign: 40 },
    unlockYear: 2000,
    qualityBonus: 30,
    genreMultipliers: { action: 2.0, racing: 2.5, puzzle: 1.3 },
    icon: ZapIcon,
    isAdvanced: true
  },

  // Graphics Features
  {
    id: '3d_graphics',
    name: '3D Graphics',
    category: 'graphics',
    description: 'Three-dimensional visual rendering',
    developmentCost: 12000,
    developmentTime: 8,
    requiresSkills: { graphics: 70, programming: 50 },
    unlockYear: 1992,
    qualityBonus: 35,
    genreMultipliers: { action: 2.0, adventure: 1.8, racing: 2.2 },
    icon: EyeIcon,
    isAdvanced: true
  },
  {
    id: 'dynamic_lighting',
    name: 'Dynamic Lighting',
    category: 'graphics',
    description: 'Real-time lighting effects',
    developmentCost: 8000,
    developmentTime: 5,
    requiresSkills: { graphics: 60, programming: 40 },
    unlockYear: 1995,
    prerequisites: ['3d_graphics'],
    qualityBonus: 20,
    genreMultipliers: { action: 1.8, adventure: 1.5, horror: 2.5 },
    icon: ZapIcon,
    isAdvanced: true
  },

  // Audio Features
  {
    id: 'voice_acting',
    name: 'Voice Acting',
    category: 'audio',
    description: 'Professional voice performances',
    developmentCost: 20000,
    developmentTime: 4,
    requiresSkills: { sound: 60, gameDesign: 30 },
    unlockYear: 1990,
    qualityBonus: 25,
    genreMultipliers: { rpg: 2.0, adventure: 2.2, action: 1.3 },
    icon: MusicIcon,
    isAdvanced: true
  },
  {
    id: 'dynamic_music',
    name: 'Dynamic Music',
    category: 'audio',
    description: 'Music that adapts to gameplay',
    developmentCost: 6000,
    developmentTime: 4,
    requiresSkills: { sound: 70, programming: 40 },
    unlockYear: 1985,
    qualityBonus: 18,
    genreMultipliers: { action: 1.8, adventure: 1.6, rpg: 1.5 },
    icon: MusicIcon,
    isAdvanced: false
  },

  // Online Features
  {
    id: 'online_leaderboards',
    name: 'Online Leaderboards',
    category: 'online',
    description: 'Global player rankings',
    developmentCost: 5000,
    developmentTime: 3,
    requiresSkills: { programming: 50 },
    unlockYear: 2000,
    prerequisites: ['networking'],
    qualityBonus: 15,
    genreMultipliers: { arcade: 2.0, racing: 1.8, puzzle: 1.5 },
    icon: TargetIcon,
    isAdvanced: false
  },

  // Basic Features
  {
    id: 'gamepad_support',
    name: 'Gamepad Support',
    category: 'accessibility',
    description: 'Controller input support',
    developmentCost: 1500,
    developmentTime: 1,
    requiresSkills: { programming: 25 },
    unlockYear: 1985,
    qualityBonus: 10,
    genreMultipliers: { action: 1.5, racing: 1.8, sports: 1.6 },
    icon: GamepadIcon,
    isAdvanced: false
  },
  {
    id: 'tutorials',
    name: 'Tutorial System',
    category: 'accessibility',
    description: 'In-game help and tutorials',
    developmentCost: 3000,
    developmentTime: 2,
    requiresSkills: { gameDesign: 40, graphics: 20 },
    unlockYear: 1985,
    qualityBonus: 12,
    genreMultipliers: { strategy: 2.0, rpg: 1.8, puzzle: 1.5 },
    icon: PuzzleIcon,
    isAdvanced: false
  }
];

interface GameFeaturesProps {
  currentYear: number;
  companyMoney: number;
  selectedGameId?: string;
  onAddFeature: (featureId: string, cost: number) => void;
  gameFeatures: string[]; // Currently implemented features
}

export function GameFeatures({
  currentYear,
  companyMoney,
  selectedGameId,
  onAddFeature,
  gameFeatures
}: GameFeaturesProps) {
  const [selectedCategory, setSelectedCategory] = useState<FeatureCategory>('gameplay');
  const [showAdvancedOnly, setShowAdvancedOnly] = useState(false);

  const categories = [
    { id: 'gameplay', name: 'Gameplay', icon: GamepadIcon },
    { id: 'graphics', name: 'Graphics', icon: EyeIcon },
    { id: 'audio', name: 'Audio', icon: MusicIcon },
    { id: 'online', name: 'Online', icon: WifiIcon },
    { id: 'accessibility', name: 'Accessibility', icon: HeartIcon },
    { id: 'technical', name: 'Technical', icon: CpuIcon }
  ];

  const availableFeatures = GAME_FEATURES.filter(feature =>
    currentYear >= feature.unlockYear &&
    feature.category === selectedCategory &&
    (!showAdvancedOnly || feature.isAdvanced) &&
    !gameFeatures.includes(feature.id)
  );

  const implementedFeatures = GAME_FEATURES.filter(feature =>
    gameFeatures.includes(feature.id)
  );

  const canImplementFeature = (feature: GameFeature) => {
    if (companyMoney < feature.developmentCost) return false;
    if (!selectedGameId) return false;

    // Check prerequisites
    if (feature.prerequisites) {
      return feature.prerequisites.every(prereq => gameFeatures.includes(prereq));
    }

    return true;
  };

  const getCategoryIcon = (categoryId: string) => {
    const category = categories.find(c => c.id === categoryId);
    return category?.icon || GamepadIcon;
  };

  const getFeatureStatusColor = (feature: GameFeature) => {
    if (gameFeatures.includes(feature.id)) return 'border-green-500 bg-green-900/20';
    if (!canImplementFeature(feature)) return 'border-red-500/50 bg-red-900/10';
    return 'border-zinc-600 hover:border-zinc-500';
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <PuzzleIcon className="h-6 w-6 text-green-400" />
            Game Features
          </h2>
          <p className="text-zinc-400 mt-1">Add advanced mechanics and features to your games</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-zinc-400">Development Budget</div>
          <div className="text-xl font-bold text-green-400">${companyMoney.toLocaleString()}</div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Available Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-400">{availableFeatures.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Implemented</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">{implementedFeatures.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Current Year</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-400">{currentYear}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Quality Bonus</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-400">
              +{implementedFeatures.reduce((sum, f) => sum + f.qualityBonus, 0)}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value="browse" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="browse">Browse Features</TabsTrigger>
          <TabsTrigger value="implemented">Implemented ({implementedFeatures.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="browse" className="space-y-6">
          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => {
              const Icon = category.icon;
              const isActive = selectedCategory === category.id;

              return (
                <Button
                  key={category.id}
                  variant={isActive ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category.id as FeatureCategory)}
                  className="flex items-center gap-2"
                >
                  <Icon className="h-4 w-4" />
                  {category.name}
                </Button>
              );
            })}
          </div>

          {/* Advanced Filter */}
          <div className="flex items-center space-x-2">
            <Checkbox
              id="advanced"
              checked={showAdvancedOnly}
              onCheckedChange={(checked) => setShowAdvancedOnly(!!checked)}
            />
            <label htmlFor="advanced" className="text-sm text-zinc-300">
              Show only advanced features
            </label>
          </div>

          {/* Features Grid */}
          {availableFeatures.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <PuzzleIcon className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-zinc-400 mb-2">No Features Available</h3>
                <p className="text-zinc-500">
                  {currentYear < 1990
                    ? "More features will become available as technology advances"
                    : "All features in this category have been implemented"
                  }
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {availableFeatures.map((feature) => {
                const Icon = feature.icon;
                const canImplement = canImplementFeature(feature);
                const hasPrereqs = !feature.prerequisites ||
                  feature.prerequisites.every(prereq => gameFeatures.includes(prereq));

                return (
                  <motion.div
                    key={feature.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card className={`${getFeatureStatusColor(feature)} transition-colors`}>
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-zinc-800 rounded-lg">
                              <Icon className="h-5 w-5 text-blue-400" />
                            </div>
                            <div>
                              <CardTitle className="text-lg">{feature.name}</CardTitle>
                              {feature.isAdvanced && (
                                <Badge variant="outline" className="text-xs mt-1">
                                  Advanced
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardHeader>

                      <CardContent className="space-y-3">
                        <p className="text-sm text-zinc-400">{feature.description}</p>

                        {/* Requirements */}
                        {feature.requiresSkills && (
                          <div>
                            <div className="text-xs font-semibold text-zinc-300 mb-1">Skill Requirements:</div>
                            <div className="flex flex-wrap gap-1">
                              {Object.entries(feature.requiresSkills).map(([skill, level]) => (
                                <Badge key={skill} variant="secondary" className="text-xs">
                                  {skill}: {level}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Prerequisites */}
                        {feature.prerequisites && (
                          <div>
                            <div className="text-xs font-semibold text-zinc-300 mb-1">Prerequisites:</div>
                            <div className="space-y-1">
                              {feature.prerequisites.map((prereqId) => {
                                const prereq = GAME_FEATURES.find(f => f.id === prereqId);
                                const isImplemented = gameFeatures.includes(prereqId);

                                return (
                                  <div key={prereqId} className="flex items-center gap-2">
                                    <div className={`w-2 h-2 rounded-full ${isImplemented ? 'bg-green-400' : 'bg-red-400'}`} />
                                    <span className={`text-xs ${isImplemented ? 'text-green-400' : 'text-red-400'}`}>
                                      {prereq?.name || prereqId}
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}

                        <Separator />

                        {/* Stats */}
                        <div className="grid grid-cols-2 gap-3 text-xs">
                          <div>
                            <span className="text-zinc-400">Development Cost:</span>
                            <div className={`font-semibold ${companyMoney >= feature.developmentCost ? 'text-green-400' : 'text-red-400'}`}>
                              ${feature.developmentCost.toLocaleString()}
                            </div>
                          </div>
                          <div>
                            <span className="text-zinc-400">Development Time:</span>
                            <div className="font-semibold text-blue-400">
                              {feature.developmentTime} weeks
                            </div>
                          </div>
                          <div>
                            <span className="text-zinc-400">Quality Bonus:</span>
                            <div className="font-semibold text-yellow-400">
                              +{feature.qualityBonus}
                            </div>
                          </div>
                          <div>
                            <span className="text-zinc-400">Available Since:</span>
                            <div className="font-semibold text-purple-400">
                              {feature.unlockYear}
                            </div>
                          </div>
                        </div>

                        <Button
                          onClick={() => onAddFeature(feature.id, feature.developmentCost)}
                          disabled={!canImplement || !hasPrereqs}
                          className="w-full"
                          size="sm"
                        >
                          {!hasPrereqs ? 'Missing Prerequisites' :
                           !selectedGameId ? 'Select a Game' :
                           companyMoney < feature.developmentCost ? 'Not Enough Money' :
                           'Implement Feature'}
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="implemented" className="space-y-4">
          {implementedFeatures.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <PuzzleIcon className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-zinc-400 mb-2">No Features Implemented</h3>
                <p className="text-zinc-500">Start implementing features to enhance your games</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {implementedFeatures.map((feature) => {
                const Icon = feature.icon;
                const CategoryIcon = getCategoryIcon(feature.category);

                return (
                  <Card key={feature.id} className="border-green-500 bg-green-900/10">
                    <CardHeader className="pb-3">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-green-800/50 rounded-lg">
                          <Icon className="h-5 w-5 text-green-400" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{feature.name}</CardTitle>
                          <Badge className="bg-green-600 text-white">
                            <CategoryIcon className="h-3 w-3 mr-1" />
                            {feature.category}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-3">
                      <p className="text-sm text-zinc-300">{feature.description}</p>

                      <div className="grid grid-cols-2 gap-3 text-xs">
                        <div>
                          <span className="text-zinc-400">Quality Bonus:</span>
                          <div className="font-semibold text-yellow-400">+{feature.qualityBonus}</div>
                        </div>
                        <div>
                          <span className="text-zinc-400">Investment:</span>
                          <div className="font-semibold text-green-400">
                            ${feature.developmentCost.toLocaleString()}
                          </div>
                        </div>
                      </div>

                      {/* Genre Bonuses */}
                      <div>
                        <div className="text-xs font-semibold text-zinc-300 mb-1">Genre Bonuses:</div>
                        <div className="flex flex-wrap gap-1">
                          {Object.entries(feature.genreMultipliers).map(([genre, multiplier]) => (
                            <Badge key={genre} variant="outline" className="text-xs">
                              {genre}: {multiplier}x
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
