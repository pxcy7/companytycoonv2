'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useGameStore } from '@/store/gameStore';
import {
  PlayIcon,
  PlusIcon,
  TrashIcon,
  SettingsIcon,
  GamepadIcon,
  CalendarIcon,
  DollarSignIcon,
  TrophyIcon,
  VolumeXIcon,
  Volume2Icon,
  BookOpenIcon,
  FileTextIcon,
  StarIcon,
  ZapIcon,
  ShieldIcon,
  CrownIcon,
  RocketIcon,
  UsersIcon,
  TrendingUpIcon,
  AwardIcon,
  TargetIcon,
  CheckIcon,
  SparklesIcon,
  GithubIcon,
  TwitterIcon,
  MessageCircleIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ParticleBackground, FloatingElement } from '@/components/ui/ParticleBackground';

interface SaveGame {
  id: string;
  companyName: string;
  gameWeek: number;
  money: number;
  reputation: number;
  gamesReleased: number;
  totalRevenue: number;
  lastPlayed: Date;
  difficulty: 'easy' | 'normal' | 'hard';
}

interface StartScreenProps {
  onStartGame: (saveData?: SaveGame, isNewGame?: boolean) => void;
  onStartTutorial: () => void;
}

const UPDATE_LOG = [
  {
    version: "v2.0.0",
    title: "Complete Game Overhaul",
    date: "November 2024",
    type: "major",
    changes: [
      {
        category: "🎮 Core Game Systems",
        items: [
          "Complete game development cycle with skill allocation",
          "Dynamic sales tracking with real-time analytics",
          "Advanced research lab with technology progression",
          "Quality-based scoring system affecting sales",
          "Multi-platform publishing system"
        ]
      },
      {
        category: "👥 Employee Management",
        items: [
          "Hire and manage talented developers",
          "Legendary developers with special abilities",
          "Employee skill progression and specializations",
          "Team productivity bonuses and synergies"
        ]
      },
      {
        category: "📢 Marketing & Business",
        items: [
          "Advanced marketing campaigns with hype tracking",
          "Office management with upgrades and equipment",
          "Financial planning and budget management",
          "Company reputation system"
        ]
      },
      {
        category: "📰 Reviews & Competition",
        items: [
          "Professional game review system with realistic scoring",
          "AI-driven competitor companies with unique strategies",
          "Market events and industry trends tracking",
          "Detailed competitor analysis and intelligence"
        ]
      },
      {
        category: "🏆 Achievements & Progress",
        items: [
          "Comprehensive achievement system with rewards",
          "Achievement points and rarity tiers",
          "Progress tracking across all game aspects",
          "Unlockable titles and bonuses"
        ]
      },
      {
        category: "✨ Visual & UX Enhancements",
        items: [
          "Beautiful particle background effects",
          "Smooth micro-animations throughout the UI",
          "Modern gradient design with glass morphism",
          "Interactive floating elements and success bursts",
          "Responsive collapsible panel layout"
        ]
      },
      {
        category: "🎓 Learning & Accessibility",
        items: [
          "Interactive tutorial system with step-by-step guidance",
          "Comprehensive notification center",
          "Advanced game settings and customization",
          "Time tracking with industry events calendar"
        ]
      }
    ]
  },
  {
    version: "v1.5.0",
    title: "Advanced Features",
    date: "October 2024",
    type: "feature",
    changes: [
      {
        category: "🔧 Technical Improvements",
        items: [
          "Next.js 15 with Turbopack for lightning-fast development",
          "TypeScript for enhanced type safety",
          "Zustand state management for optimal performance",
          "Framer Motion for smooth animations"
        ]
      }
    ]
  },
  {
    version: "v1.0.0",
    title: "Initial Release",
    date: "September 2024",
    type: "release",
    changes: [
      {
        category: "🎯 Foundation",
        items: [
          "Basic game development mechanics",
          "Simple UI framework setup",
          "Core data structures and types",
          "Initial project architecture"
        ]
      }
    ]
  }
];

const FEATURES_HIGHLIGHT = [
  {
    icon: GamepadIcon,
    title: "Rich Game Development",
    description: "Create games with detailed skill allocation, quality tracking, and realistic market simulation"
  },
  {
    icon: TrendingUpIcon,
    title: "Real-Time Analytics",
    description: "Track sales performance, market trends, and competitor activities with live dashboards"
  },
  {
    icon: UsersIcon,
    title: "Team Management",
    description: "Hire legendary developers, manage office spaces, and build the ultimate game studio"
  },
  {
    icon: TrophyIcon,
    title: "Achievement System",
    description: "Unlock rewards, track progress, and compete with achievement points and leaderboards"
  },
  {
    icon: TargetIcon,
    title: "Competitor Analysis",
    description: "Analyze rival companies, track market events, and plan strategic business moves"
  },
  {
    icon: SparklesIcon,
    title: "Modern Interface",
    description: "Beautiful animations, particle effects, and intuitive design for an immersive experience"
  }
];

export function StartScreen({ onStartGame, onStartTutorial }: StartScreenProps) {
  const [activeTab, setActiveTab] = useState('play');
  const [savedGames, setSavedGames] = useState<SaveGame[]>([]);
  const [isNewGameDialogOpen, setIsNewGameDialogOpen] = useState(false);
  const [settings, setSettings] = useState({
    companyName: '',
    difficulty: 'normal' as 'easy' | 'normal' | 'hard',
    soundEnabled: true,
    musicEnabled: true,
    volume: 50,
    tutorialEnabled: true
  });

  // Load saved games from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('gameDevTycoon_savedGames');
    if (saved) {
      try {
        const parsedGames = JSON.parse(saved).map((game: any) => ({
          ...game,
          lastPlayed: new Date(game.lastPlayed)
        }));
        setSavedGames(parsedGames);
      } catch (error) {
        console.error('Failed to load saved games:', error);
      }
    }
  }, []);

  const handleStartNewGame = () => {
    if (!settings.companyName.trim()) return;

    const newSave: SaveGame = {
      id: Date.now().toString(),
      companyName: settings.companyName,
      gameWeek: 1,
      money: settings.difficulty === 'easy' ? 25000 : settings.difficulty === 'normal' ? 15000 : 10000,
      reputation: 10,
      gamesReleased: 0,
      totalRevenue: 0,
      lastPlayed: new Date(),
      difficulty: settings.difficulty
    };

    const updatedSaves = [newSave, ...savedGames];
    setSavedGames(updatedSaves);
    localStorage.setItem('gameDevTycoon_savedGames', JSON.stringify(updatedSaves));

    setIsNewGameDialogOpen(false);
    onStartGame(newSave, true);
  };

  const handleLoadGame = (save: SaveGame) => {
    onStartGame(save, false);
  };

  const handleDeleteGame = (gameId: string) => {
    const updatedSaves = savedGames.filter(save => save.id !== gameId);
    setSavedGames(updatedSaves);
    localStorage.setItem('gameDevTycoon_savedGames', JSON.stringify(updatedSaves));
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-400 bg-green-900/20';
      case 'normal': return 'text-yellow-400 bg-yellow-900/20';
      case 'hard': return 'text-red-400 bg-red-900/20';
      default: return 'text-zinc-400 bg-zinc-900/20';
    }
  };

  const getVersionTypeColor = (type: string) => {
    switch (type) {
      case 'major': return 'bg-gradient-to-r from-purple-600 to-blue-600';
      case 'feature': return 'bg-gradient-to-r from-green-600 to-emerald-600';
      case 'release': return 'bg-gradient-to-r from-orange-600 to-yellow-600';
      default: return 'bg-gradient-to-r from-zinc-600 to-zinc-700';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 text-white relative overflow-hidden">
      {/* Background Effects */}
      <ParticleBackground theme="default" intensity="medium" enabled={true} />

      {/* Animated Background Shapes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
          }}
          transition={{
            duration: 20,
            repeat: Number.POSITIVE_INFINITY,
            ease: "linear"
          }}
        />
        <motion.div
          className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl"
          animate={{
            scale: [1.2, 1, 1.2],
            rotate: [360, 180, 0],
          }}
          transition={{
            duration: 15,
            repeat: Number.POSITIVE_INFINITY,
            ease: "linear"
          }}
        />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <FloatingElement intensity="subtle">
            <h1 className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-4">
              Game Dev Tycoon
            </h1>
          </FloatingElement>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="text-xl md:text-2xl text-zinc-300 mb-8"
          >
            Build your gaming empire from garage to global phenomenon
          </motion.p>

          {/* Version Badge */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.8, type: "spring", stiffness: 200 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30 rounded-full backdrop-blur-sm"
          >
            <SparklesIcon className="h-4 w-4 text-purple-400" />
            <span className="text-sm font-medium">Version 2.0.0 - Complete Edition</span>
          </motion.div>
        </motion.div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="max-w-6xl mx-auto"
        >
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-zinc-900/50 backdrop-blur-sm border border-zinc-700/50">
              <TabsTrigger value="play" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600">
                <PlayIcon className="h-4 w-4 mr-2" />
                Play
              </TabsTrigger>
              <TabsTrigger value="updates" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600">
                <FileTextIcon className="h-4 w-4 mr-2" />
                Updates
              </TabsTrigger>
              <TabsTrigger value="features" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600">
                <StarIcon className="h-4 w-4 mr-2" />
                Features
              </TabsTrigger>
              <TabsTrigger value="settings" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600">
                <SettingsIcon className="h-4 w-4 mr-2" />
                Settings
              </TabsTrigger>
            </TabsList>

            {/* Play Tab */}
            <TabsContent value="play" className="mt-8 space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Quick Start */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 }}
                >
                  <Card className="bg-gradient-to-br from-zinc-900/80 to-zinc-800/80 border-zinc-700/50 backdrop-blur-sm hover:border-zinc-600/50 transition-all duration-300">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-3">
                        <div className="p-2 bg-gradient-to-r from-green-600 to-emerald-600 rounded-lg">
                          <PlusIcon className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <div className="text-xl">New Game</div>
                          <div className="text-sm text-zinc-400 font-normal">Start your journey as an indie game developer</div>
                        </div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-zinc-300">
                        Create a new company and begin building your gaming empire
                      </p>
                      <Dialog open={isNewGameDialogOpen} onOpenChange={setIsNewGameDialogOpen}>
                        <DialogTrigger asChild>
                          <Button className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700">
                            Start New Game
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-zinc-900 border-zinc-700">
                          <DialogHeader>
                            <DialogTitle>Create New Game</DialogTitle>
                            <DialogDescription>
                              Set up your gaming company and choose your difficulty
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <Label htmlFor="companyName">Company Name</Label>
                              <Input
                                id="companyName"
                                value={settings.companyName}
                                onChange={(e) => setSettings(prev => ({ ...prev, companyName: e.target.value }))}
                                placeholder="Enter your company name"
                                className="bg-zinc-800 border-zinc-700"
                              />
                            </div>
                            <div>
                              <Label htmlFor="difficulty">Difficulty</Label>
                              <Select value={settings.difficulty} onValueChange={(value: any) => setSettings(prev => ({ ...prev, difficulty: value }))}>
                                <SelectTrigger className="bg-zinc-800 border-zinc-700">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="easy">
                                    <div className="flex items-center gap-2">
                                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                                      Easy - $25,000 starting money
                                    </div>
                                  </SelectItem>
                                  <SelectItem value="normal">
                                    <div className="flex items-center gap-2">
                                      <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                                      Normal - $15,000 starting money
                                    </div>
                                  </SelectItem>
                                  <SelectItem value="hard">
                                    <div className="flex items-center gap-2">
                                      <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                                      Hard - $10,000 starting money
                                    </div>
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button variant="outline" onClick={() => setIsNewGameDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button
                              onClick={handleStartNewGame}
                              disabled={!settings.companyName.trim()}
                              className="bg-gradient-to-r from-green-600 to-emerald-600"
                            >
                              Create Game
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Tutorial */}
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <Card className="bg-gradient-to-br from-zinc-900/80 to-zinc-800/80 border-zinc-700/50 backdrop-blur-sm hover:border-zinc-600/50 transition-all duration-300">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-3">
                        <div className="p-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg">
                          <BookOpenIcon className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <div className="text-xl">Tutorial</div>
                          <div className="text-sm text-zinc-400 font-normal">Learn the basics with guided gameplay</div>
                        </div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-zinc-300">
                        Perfect for new players - learn all the game mechanics step by step
                      </p>
                      <Button
                        onClick={onStartTutorial}
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                      >
                        Start Tutorial
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>

              {/* Saved Games */}
              {savedGames.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <Card className="bg-gradient-to-br from-zinc-900/80 to-zinc-800/80 border-zinc-700/50 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <GamepadIcon className="h-5 w-5 text-blue-400" />
                        Saved Games
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {savedGames.map((save, index) => (
                          <motion.div
                            key={save.id}
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.1 * index }}
                            className="group"
                          >
                            <Card className="bg-zinc-800/50 border-zinc-700 hover:border-zinc-600 transition-all duration-200 group-hover:scale-105">
                              <CardHeader className="pb-3">
                                <div className="flex items-start justify-between">
                                  <div>
                                    <CardTitle className="text-lg">{save.companyName}</CardTitle>
                                    <Badge className={`mt-1 ${getDifficultyColor(save.difficulty)}`}>
                                      {save.difficulty}
                                    </Badge>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleDeleteGame(save.id)}
                                    className="opacity-0 group-hover:opacity-100 transition-opacity text-red-400 hover:text-red-300"
                                  >
                                    <TrashIcon className="h-4 w-4" />
                                  </Button>
                                </div>
                              </CardHeader>
                              <CardContent className="space-y-3">
                                <div className="grid grid-cols-2 gap-2 text-xs">
                                  <div className="flex items-center gap-1">
                                    <CalendarIcon className="h-3 w-3 text-zinc-400" />
                                    Week {save.gameWeek}
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <DollarSignIcon className="h-3 w-3 text-green-400" />
                                    ${save.money.toLocaleString()}
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <TrophyIcon className="h-3 w-3 text-yellow-400" />
                                    {save.reputation} Rep
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <GamepadIcon className="h-3 w-3 text-blue-400" />
                                    {save.gamesReleased} Games
                                  </div>
                                </div>
                                <div className="text-xs text-zinc-500">
                                  Last played: {save.lastPlayed.toLocaleDateString()}
                                </div>
                                <Button
                                  onClick={() => handleLoadGame(save)}
                                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                                  size="sm"
                                >
                                  Continue Game
                                </Button>
                              </CardContent>
                            </Card>
                          </motion.div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </TabsContent>

            {/* Updates Tab */}
            <TabsContent value="updates" className="mt-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-gradient-to-br from-zinc-900/80 to-zinc-800/80 border-zinc-700/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <FileTextIcon className="h-5 w-5 text-purple-400" />
                      Update Log & Changelog
                    </CardTitle>
                    <CardDescription>
                      Complete history of features, improvements, and changes
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[600px] pr-4">
                      <div className="space-y-8">
                        {UPDATE_LOG.map((update, index) => (
                          <motion.div
                            key={update.version}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="relative"
                          >
                            {/* Timeline Line */}
                            {index < UPDATE_LOG.length - 1 && (
                              <div className="absolute left-6 top-16 w-0.5 h-full bg-gradient-to-b from-purple-500/50 to-transparent"></div>
                            )}

                            <div className="flex items-start gap-4">
                              {/* Version Badge */}
                              <div className={`flex-shrink-0 w-12 h-12 rounded-full ${getVersionTypeColor(update.type)} flex items-center justify-center text-white font-bold text-sm shadow-lg`}>
                                {update.version.replace('v', '')}
                              </div>

                              {/* Update Content */}
                              <div className="flex-1 bg-zinc-800/30 rounded-lg p-6 border border-zinc-700/50 backdrop-blur-sm">
                                <div className="flex items-center justify-between mb-4">
                                  <div>
                                    <h3 className="text-xl font-bold text-white">{update.title}</h3>
                                    <p className="text-sm text-zinc-400">{update.date}</p>
                                  </div>
                                  <Badge className={`${getVersionTypeColor(update.type)} text-white border-0`}>
                                    {update.type}
                                  </Badge>
                                </div>

                                <div className="space-y-6">
                                  {update.changes.map((category, catIndex) => (
                                    <div key={catIndex}>
                                      <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                                        {category.category}
                                      </h4>
                                      <div className="grid grid-cols-1 gap-2">
                                        {category.items.map((item, itemIndex) => (
                                          <motion.div
                                            key={itemIndex}
                                            initial={{ opacity: 0, x: -10 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: (index * 0.1) + (catIndex * 0.05) + (itemIndex * 0.02) }}
                                            className="flex items-start gap-3 p-3 bg-zinc-800/50 rounded-lg border border-zinc-700/30"
                                          >
                                            <CheckIcon className="h-4 w-4 text-green-400 mt-0.5 flex-shrink-0" />
                                            <span className="text-sm text-zinc-300">{item}</span>
                                          </motion.div>
                                        ))}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Features Tab */}
            <TabsContent value="features" className="mt-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                <Card className="bg-gradient-to-br from-zinc-900/80 to-zinc-800/80 border-zinc-700/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <StarIcon className="h-5 w-5 text-yellow-400" />
                      Key Features
                    </CardTitle>
                    <CardDescription>
                      Discover what makes Game Dev Tycoon the ultimate gaming business simulator
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {FEATURES_HIGHLIGHT.map((feature, index) => {
                        const Icon = feature.icon;
                        return (
                          <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="group"
                          >
                            <Card className="h-full bg-gradient-to-br from-zinc-800/50 to-zinc-700/50 border-zinc-600/50 hover:border-purple-500/50 transition-all duration-300 group-hover:scale-105">
                              <CardContent className="p-6">
                                <div className="flex items-center gap-3 mb-4">
                                  <div className="p-3 bg-gradient-to-r from-purple-600/20 to-blue-600/20 rounded-lg">
                                    <Icon className="h-6 w-6 text-purple-400" />
                                  </div>
                                  <h3 className="font-semibold text-lg">{feature.title}</h3>
                                </div>
                                <p className="text-zinc-300 text-sm leading-relaxed">{feature.description}</p>
                              </CardContent>
                            </Card>
                          </motion.div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>

                {/* Technical Stack */}
                <Card className="bg-gradient-to-br from-zinc-900/80 to-zinc-800/80 border-zinc-700/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <RocketIcon className="h-5 w-5 text-blue-400" />
                      Technical Excellence
                    </CardTitle>
                    <CardDescription>Built with modern technologies for optimal performance</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {[
                        { name: "Next.js 15", desc: "React framework with Turbopack" },
                        { name: "TypeScript", desc: "Type-safe development" },
                        { name: "Tailwind CSS", desc: "Modern styling system" },
                        { name: "Framer Motion", desc: "Smooth animations" },
                        { name: "Zustand", desc: "State management" },
                        { name: "shadcn/ui", desc: "Beautiful components" },
                        { name: "Recharts", desc: "Data visualization" },
                        { name: "Bun Runtime", desc: "Fast JavaScript runtime" }
                      ].map((tech, index) => (
                        <motion.div
                          key={tech.name}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.05 }}
                          className="p-4 bg-zinc-800/50 rounded-lg border border-zinc-700/50 text-center"
                        >
                          <div className="font-semibold text-sm mb-1">{tech.name}</div>
                          <div className="text-xs text-zinc-400">{tech.desc}</div>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="mt-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-gradient-to-br from-zinc-900/80 to-zinc-800/80 border-zinc-700/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <SettingsIcon className="h-5 w-5 text-zinc-400" />
                      Game Settings
                    </CardTitle>
                    <CardDescription>Configure your gaming experience</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="font-semibold">Audio Settings</h3>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <Label htmlFor="sound-enabled">Sound Effects</Label>
                            <Switch
                              id="sound-enabled"
                              checked={settings.soundEnabled}
                              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, soundEnabled: checked }))}
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <Label htmlFor="music-enabled">Background Music</Label>
                            <Switch
                              id="music-enabled"
                              checked={settings.musicEnabled}
                              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, musicEnabled: checked }))}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="volume">Master Volume</Label>
                            <Slider
                              id="volume"
                              min={0}
                              max={100}
                              step={1}
                              value={[settings.volume]}
                              onValueChange={(value) => setSettings(prev => ({ ...prev, volume: value[0] }))}
                              className="w-full"
                            />
                            <div className="flex justify-between text-xs text-zinc-400">
                              <span>0%</span>
                              <span>{settings.volume}%</span>
                              <span>100%</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h3 className="font-semibold">Gameplay Settings</h3>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <Label htmlFor="tutorial-enabled">Show Tutorial Hints</Label>
                            <Switch
                              id="tutorial-enabled"
                              checked={settings.tutorialEnabled}
                              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, tutorialEnabled: checked }))}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div className="text-center space-y-4">
                      <h3 className="font-semibold">About</h3>
                      <div className="text-sm text-zinc-400 space-y-2">
                        <p>Game Dev Tycoon v2.0.0 - Complete Edition</p>
                        <p>Built with ❤️ using modern web technologies</p>
                        <div className="flex justify-center gap-4 mt-4">
                          <Button variant="outline" size="sm" className="flex items-center gap-2">
                            <GithubIcon className="h-4 w-4" />
                            GitHub
                          </Button>
                          <Button variant="outline" size="sm" className="flex items-center gap-2">
                            <TwitterIcon className="h-4 w-4" />
                            Twitter
                          </Button>
                          <Button variant="outline" size="sm" className="flex items-center gap-2">
                            <MessageCircleIcon className="h-4 w-4" />
                            Discord
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}
