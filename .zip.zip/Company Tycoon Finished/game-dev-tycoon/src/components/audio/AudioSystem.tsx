'use client';

import { useState, useEffect, useRef, createContext, useContext } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Volume2Icon, VolumeXIcon, MusicIcon, PlayIcon, PauseIcon, SkipForwardIcon } from 'lucide-react';

interface AudioTrack {
  id: string;
  name: string;
  url: string;
  category: 'ambient' | 'success' | 'tension' | 'victory' | 'menu';
  loop: boolean;
  volume: number;
}

interface SoundEffect {
  id: string;
  name: string;
  url: string;
  category: 'ui' | 'notification' | 'achievement' | 'error' | 'action';
  volume: number;
}

interface AudioSettings {
  masterVolume: number;
  musicVolume: number;
  sfxVolume: number;
  musicEnabled: boolean;
  sfxEnabled: boolean;
  currentTrack: string | null;
  adaptiveMusic: boolean;
}

interface AudioContextType {
  settings: AudioSettings;
  updateSettings: (settings: Partial<AudioSettings>) => void;
  playTrack: (trackId: string) => void;
  stopMusic: () => void;
  playSfx: (sfxId: string) => void;
  setGameState: (state: 'menu' | 'playing' | 'paused' | 'success' | 'tension') => void;
}

const AudioContext = createContext<AudioContextType | null>(null);

// Audio file URLs (these would be actual audio files in a real implementation)
const MUSIC_TRACKS: AudioTrack[] = [
  {
    id: 'ambient_office',
    name: 'Office Ambience',
    url: '/audio/music/ambient_office.mp3',
    category: 'ambient',
    loop: true,
    volume: 0.6
  },
  {
    id: 'corporate_theme',
    name: 'Corporate Success',
    url: '/audio/music/corporate_theme.mp3',
    category: 'success',
    loop: true,
    volume: 0.7
  },
  {
    id: 'menu_theme',
    name: 'Main Menu',
    url: '/audio/music/menu_theme.mp3',
    category: 'menu',
    loop: true,
    volume: 0.8
  },
  {
    id: 'victory_fanfare',
    name: 'Victory Fanfare',
    url: '/audio/music/victory_fanfare.mp3',
    category: 'victory',
    loop: false,
    volume: 0.9
  },
  {
    id: 'tension_build',
    name: 'Market Tension',
    url: '/audio/music/tension_build.mp3',
    category: 'tension',
    loop: true,
    volume: 0.5
  }
];

const SOUND_EFFECTS: SoundEffect[] = [
  {
    id: 'button_click',
    name: 'Button Click',
    url: '/audio/sfx/button_click.wav',
    category: 'ui',
    volume: 0.4
  },
  {
    id: 'notification_pop',
    name: 'Notification',
    url: '/audio/sfx/notification_pop.wav',
    category: 'notification',
    volume: 0.6
  },
  {
    id: 'achievement_unlock',
    name: 'Achievement Unlocked',
    url: '/audio/sfx/achievement_unlock.wav',
    category: 'achievement',
    volume: 0.8
  },
  {
    id: 'money_gain',
    name: 'Money Gained',
    url: '/audio/sfx/money_gain.wav',
    category: 'action',
    volume: 0.7
  },
  {
    id: 'error_buzz',
    name: 'Error',
    url: '/audio/sfx/error_buzz.wav',
    category: 'error',
    volume: 0.5
  },
  {
    id: 'game_release',
    name: 'Game Released',
    url: '/audio/sfx/game_release.wav',
    category: 'action',
    volume: 0.9
  },
  {
    id: 'employee_hire',
    name: 'Employee Hired',
    url: '/audio/sfx/employee_hire.wav',
    category: 'action',
    volume: 0.6
  },
  {
    id: 'research_complete',
    name: 'Research Complete',
    url: '/audio/sfx/research_complete.wav',
    category: 'action',
    volume: 0.7
  }
];

export function AudioProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<AudioSettings>({
    masterVolume: 80,
    musicVolume: 60,
    sfxVolume: 70,
    musicEnabled: true,
    sfxEnabled: true,
    currentTrack: null,
    adaptiveMusic: true
  });

  const musicRef = useRef<HTMLAudioElement | null>(null);
  const sfxRefs = useRef<Map<string, HTMLAudioElement>>(new Map());
  const gameStateRef = useRef<'menu' | 'playing' | 'paused' | 'success' | 'tension'>('menu');

  // Load audio settings from localStorage
  useEffect(() => {
    const savedSettings = localStorage.getItem('gameDevTycoon_audioSettings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setSettings({ ...settings, ...parsed });
      } catch (error) {
        console.error('Failed to load audio settings:', error);
      }
    }
  }, []);

  // Save settings when they change
  useEffect(() => {
    localStorage.setItem('gameDevTycoon_audioSettings', JSON.stringify(settings));
  }, [settings]);

  // Initialize audio elements
  useEffect(() => {
    // Preload sound effects
    SOUND_EFFECTS.forEach(sfx => {
      const audio = new Audio();
      audio.preload = 'auto';
      audio.volume = 0; // Will be set when played
      // Note: In a real implementation, you would set audio.src = sfx.url
      sfxRefs.current.set(sfx.id, audio);
    });

    // Initialize music player
    musicRef.current = new Audio();
    musicRef.current.loop = true;
    musicRef.current.volume = 0;

    return () => {
      // Cleanup
      sfxRefs.current.forEach(audio => {
        audio.pause();
        audio.src = '';
      });
      if (musicRef.current) {
        musicRef.current.pause();
        musicRef.current.src = '';
      }
    };
  }, []);

  // Adaptive music system
  useEffect(() => {
    if (!settings.adaptiveMusic || !settings.musicEnabled) return;

    const gameState = gameStateRef.current;
    let trackToPlay: string | null = null;

    switch (gameState) {
      case 'menu':
        trackToPlay = 'menu_theme';
        break;
      case 'playing':
        trackToPlay = 'ambient_office';
        break;
      case 'success':
        trackToPlay = 'corporate_theme';
        break;
      case 'tension':
        trackToPlay = 'tension_build';
        break;
      case 'paused':
        // Keep current track but lower volume
        break;
    }

    if (trackToPlay && trackToPlay !== settings.currentTrack) {
      playTrack(trackToPlay);
    }
  }, [settings.adaptiveMusic, settings.musicEnabled]);

  const updateSettings = (newSettings: Partial<AudioSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const playTrack = (trackId: string) => {
    if (!settings.musicEnabled || !musicRef.current) return;

    const track = MUSIC_TRACKS.find(t => t.id === trackId);
    if (!track) return;

    // Fade out current track
    if (settings.currentTrack) {
      const fadeOut = setInterval(() => {
        if (musicRef.current && musicRef.current.volume > 0.1) {
          musicRef.current.volume = Math.max(0, musicRef.current.volume - 0.1);
        } else {
          clearInterval(fadeOut);
          // Switch to new track
          switchTrack(track);
        }
      }, 50);
    } else {
      switchTrack(track);
    }
  };

  const switchTrack = (track: AudioTrack) => {
    if (!musicRef.current) return;

    // In a real implementation, you would set the actual audio source
    // musicRef.current.src = track.url;
    musicRef.current.loop = track.loop;

    // Set volume based on settings
    const finalVolume = (settings.masterVolume / 100) * (settings.musicVolume / 100) * track.volume;
    musicRef.current.volume = finalVolume;

    // Fade in new track
    musicRef.current.volume = 0;
    musicRef.current.play().catch(console.error);

    const fadeIn = setInterval(() => {
      if (musicRef.current && musicRef.current.volume < finalVolume - 0.1) {
        musicRef.current.volume = Math.min(finalVolume, musicRef.current.volume + 0.1);
      } else {
        if (musicRef.current) musicRef.current.volume = finalVolume;
        clearInterval(fadeIn);
      }
    }, 50);

    updateSettings({ currentTrack: track.id });
  };

  const stopMusic = () => {
    if (!musicRef.current) return;

    const fadeOut = setInterval(() => {
      if (musicRef.current && musicRef.current.volume > 0.1) {
        musicRef.current.volume = Math.max(0, musicRef.current.volume - 0.1);
      } else {
        clearInterval(fadeOut);
        if (musicRef.current) {
          musicRef.current.pause();
          musicRef.current.currentTime = 0;
        }
        updateSettings({ currentTrack: null });
      }
    }, 50);
  };

  const playSfx = (sfxId: string) => {
    if (!settings.sfxEnabled) return;

    const audio = sfxRefs.current.get(sfxId);
    const sfx = SOUND_EFFECTS.find(s => s.id === sfxId);

    if (!audio || !sfx) return;

    // Set volume based on settings
    const finalVolume = (settings.masterVolume / 100) * (settings.sfxVolume / 100) * sfx.volume;
    audio.volume = finalVolume;

    // Reset and play
    audio.currentTime = 0;
    audio.play().catch(console.error);
  };

  const setGameState = (state: 'menu' | 'playing' | 'paused' | 'success' | 'tension') => {
    gameStateRef.current = state;

    // Trigger adaptive music if enabled
    if (settings.adaptiveMusic) {
      // Use setTimeout to allow for state updates
      setTimeout(() => {
        const stateCheckInterval = setInterval(() => {
          if (gameStateRef.current === state) {
            clearInterval(stateCheckInterval);
            // Trigger music change logic here if needed
          }
        }, 100);
      }, 100);
    }
  };

  const contextValue: AudioContextType = {
    settings,
    updateSettings,
    playTrack,
    stopMusic,
    playSfx,
    setGameState
  };

  return (
    <AudioContext.Provider value={contextValue}>
      {children}
    </AudioContext.Provider>
  );
}

export function useAudio() {
  const context = useContext(AudioContext);
  if (!context) {
    throw new Error('useAudio must be used within AudioProvider');
  }
  return context;
}

// Audio Controls Component
export function AudioControls() {
  const { settings, updateSettings, playTrack, stopMusic, playSfx } = useAudio();
  const [isExpanded, setIsExpanded] = useState(false);

  const currentTrack = MUSIC_TRACKS.find(t => t.id === settings.currentTrack);

  const testSfx = () => {
    playSfx('achievement_unlock');
  };

  return (
    <Card className="fixed bottom-4 right-4 z-50 w-80">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <MusicIcon className="h-4 w-4" />
            Audio Controls
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            {isExpanded ? '−' : '+'}
          </Button>
        </div>
      </CardHeader>

      {isExpanded && (
        <CardContent className="space-y-4">
          {/* Master Volume */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm">Master Volume</span>
              <span className="text-xs text-zinc-400">{settings.masterVolume}%</span>
            </div>
            <Slider
              value={[settings.masterVolume]}
              onValueChange={([value]) => updateSettings({ masterVolume: value })}
              max={100}
              step={1}
              className="w-full"
            />
          </div>

          {/* Music Volume */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm">Music</span>
              <div className="flex items-center gap-2">
                <span className="text-xs text-zinc-400">{settings.musicVolume}%</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => updateSettings({ musicEnabled: !settings.musicEnabled })}
                  className="h-6 w-6 p-0"
                >
                  {settings.musicEnabled ?
                    <Volume2Icon className="h-3 w-3" /> :
                    <VolumeXIcon className="h-3 w-3" />
                  }
                </Button>
              </div>
            </div>
            <Slider
              value={[settings.musicVolume]}
              onValueChange={([value]) => updateSettings({ musicVolume: value })}
              max={100}
              step={1}
              className="w-full"
              disabled={!settings.musicEnabled}
            />
          </div>

          {/* SFX Volume */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm">Sound Effects</span>
              <div className="flex items-center gap-2">
                <span className="text-xs text-zinc-400">{settings.sfxVolume}%</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => updateSettings({ sfxEnabled: !settings.sfxEnabled })}
                  className="h-6 w-6 p-0"
                >
                  {settings.sfxEnabled ?
                    <Volume2Icon className="h-3 w-3" /> :
                    <VolumeXIcon className="h-3 w-3" />
                  }
                </Button>
              </div>
            </div>
            <Slider
              value={[settings.sfxVolume]}
              onValueChange={([value]) => updateSettings({ sfxVolume: value })}
              max={100}
              step={1}
              className="w-full"
              disabled={!settings.sfxEnabled}
            />
          </div>

          {/* Current Track */}
          {currentTrack && (
            <div className="p-2 bg-zinc-800/50 rounded text-xs">
              <div className="flex items-center justify-between">
                <span>Now Playing:</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={stopMusic}
                  className="h-5 w-5 p-0"
                >
                  <PauseIcon className="h-3 w-3" />
                </Button>
              </div>
              <div className="text-zinc-300 truncate">{currentTrack.name}</div>
            </div>
          )}

          {/* Quick Actions */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => playTrack('ambient_office')}
              className="flex-1 text-xs"
            >
              Play Ambient
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={testSfx}
              className="flex-1 text-xs"
            >
              Test SFX
            </Button>
          </div>

          {/* Adaptive Music Toggle */}
          <div className="flex items-center justify-between">
            <span className="text-sm">Adaptive Music</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => updateSettings({ adaptiveMusic: !settings.adaptiveMusic })}
              className="h-6 text-xs"
            >
              {settings.adaptiveMusic ? 'ON' : 'OFF'}
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  );
}

// Hook for playing specific sound effects
export function useGameSfx() {
  const { playSfx } = useAudio();

  return {
    playClick: () => playSfx('button_click'),
    playNotification: () => playSfx('notification_pop'),
    playAchievement: () => playSfx('achievement_unlock'),
    playMoneyGain: () => playSfx('money_gain'),
    playError: () => playSfx('error_buzz'),
    playGameRelease: () => playSfx('game_release'),
    playEmployeeHire: () => playSfx('employee_hire'),
    playResearchComplete: () => playSfx('research_complete')
  };
}

// Component to handle game state audio changes
export function GameStateAudio({ gameState }: { gameState: 'menu' | 'playing' | 'paused' | 'success' | 'tension' }) {
  const { setGameState } = useAudio();

  useEffect(() => {
    setGameState(gameState);
  }, [gameState, setGameState]);

  return null;
}
