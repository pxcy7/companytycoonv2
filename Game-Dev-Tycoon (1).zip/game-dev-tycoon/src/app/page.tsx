// Instructions: Add console logging and error handling to debug the white screen issue

'use client';

import { useState, useEffect } from 'react';
import { useGameStore } from '@/store/gameStore';
import { Sidebar } from '@/components/layout/Sidebar';
import { GameDevelopment } from '@/components/game/GameDevelopment';
import { SalesAnalytics } from '@/components/game/SalesAnalytics';
import { ResearchLab } from '@/components/game/ResearchLab';
import { EmployeeSystem } from '@/components/advanced/EmployeeSystem';
import { MarketingSystem } from '@/components/advanced/MarketingSystem';
import { OfficeManagement } from '@/components/game/OfficeManagement';
import { GameSettings } from '@/components/game/GameSettings';
import { NotificationCenter } from '@/components/game/NotificationCenter';
import { GameReviews } from '@/components/game/GameReviews';
import { AchievementSystem } from '@/components/game/AchievementSystem';
import { CompetitorAnalysis } from '@/components/game/CompetitorAnalysis';
import { TimeTracker } from '@/components/ui/time-tracker';
import { TutorialSystem } from '@/components/tutorial/TutorialSystem';
import { StartScreen } from '@/components/menu/StartScreen';
import { ParticleBackground, FloatingElement, SuccessBurst } from '@/components/ui/ParticleBackground';
// import { Toaster } from '@/components/ui/sonner';
import { Button } from '@/components/ui/button';
import { PanelLeftOpenIcon, PanelRightOpenIcon } from 'lucide-react';

interface SaveGame {
  id: string;
  companyName: string;
  gameWeek: number;
  money: number;
  reputation: number;
  gamesReleased: number;
  totalRevenue: number;
  lastPlayed: Date;
  difficulty: 'easy' | 'normal' | 'hard';
}

interface MarketingCampaign {
  id: string;
  name: string;
  gameId: string;
  budget: number;
  duration: number;
  startWeek: number;
  status: 'active' | 'completed';
}

export default function Home() {
  console.log('Home component rendering...');

  const [gameState, setGameState] = useState<'menu' | 'tutorial' | 'playing'>('menu');
  const [activeTab, setActiveTab] = useState('develop');
  const [isTutorialActive, setIsTutorialActive] = useState(false);
  const [completedTutorialSteps, setCompletedTutorialSteps] = useState<string[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [marketingCampaigns, setMarketingCampaigns] = useState<MarketingCampaign[]>([]);
  const [isRightPanelOpen, setIsRightPanelOpen] = useState(true);
  const [isLeftPanelOpen, setIsLeftPanelOpen] = useState(true);
  const [showSuccessBurst, setShowSuccessBurst] = useState(false);
  const [particleTheme, setParticleTheme] = useState<'default' | 'success' | 'error' | 'warning' | 'coding'>('default');

  const {
    company,
    gameWeek,
    isGamePaused,
    advanceWeek,
    addMoney,
    addNotification,
    spendMoney,
    pauseGame,
    resumeGame,
    games
  } = useGameStore();

  console.log('Game state:', { gameState, company, gameWeek });

  // Auto-advance weeks when not paused
  useEffect(() => {
    if (gameState === 'playing' && !isGamePaused && !isTutorialActive) {
      const interval = setInterval(() => {
        advanceWeek();
      }, 3000); // Advance every 3 seconds

      return () => clearInterval(interval);
    }
  }, [gameState, isGamePaused, isTutorialActive, advanceWeek]);

  // Save game periodically
  useEffect(() => {
    if (gameState === 'playing') {
      const interval = setInterval(() => {
        // Auto-save current game state
        const currentSave = {
          id: 'current',
          companyName: company.name,
          gameWeek,
          money: company.money,
          reputation: company.reputation,
          gamesReleased: games.filter(g => g.isReleased).length,
          totalRevenue: games.reduce((sum, g) => sum + g.salesData.revenue, 0),
          lastPlayed: new Date(),
          difficulty: 'normal' as const
        };

        // Save to localStorage
        localStorage.setItem('gameDevTycoon_currentGame', JSON.stringify(currentSave));
      }, 30000); // Save every 30 seconds

      return () => clearInterval(interval);
    }
  }, [gameState, company, gameWeek, games]);

  const handleStartGame = (saveData?: SaveGame, isNewGame?: boolean) => {
    if (saveData) {
      // Load save data into store
      useGameStore.setState(state => ({
        ...state,
        company: {
          ...state.company,
          name: saveData.companyName,
          money: saveData.money,
          reputation: saveData.reputation
        },
        gameWeek: saveData.gameWeek
      }));
    }

    setGameState('playing');
    setActiveTab('develop');

    if (isNewGame) {
      addNotification({
        type: 'success',
        title: 'Welcome!',
        message: `${company.name} has been founded! Time to make your first game.`
      });
    }
  };

  const handleStartTutorial = () => {
    // Set up tutorial company
    useGameStore.setState(state => ({
      ...state,
      company: {
        ...state.company,
        name: 'Tutorial Studio',
        money: 15000,
        reputation: 10
      },
      gameWeek: 1
    }));

    setGameState('tutorial');
    setIsTutorialActive(true);
    setActiveTab('develop');
  };

  const handleTutorialComplete = () => {
    setIsTutorialActive(false);
    setGameState('playing');
    addNotification({
      type: 'success',
      title: 'Tutorial Complete!',
      message: 'You\'re ready to build your gaming empire!'
    });
  };

  const handleTutorialSkip = () => {
    setIsTutorialActive(false);
    setGameState('menu');
  };

  const handleHireEmployee = (employee: any, cost: number) => {
    if (spendMoney(cost)) {
      setEmployees(prev => [...prev, { ...employee, isHired: true }]);
      addNotification({
        type: 'success',
        title: 'Employee Hired!',
        message: `${employee.name} has joined your team!`
      });
    }
  };

  const handleFireEmployee = (employeeId: string) => {
    setEmployees(prev => prev.filter(emp => emp.id !== employeeId));
    addNotification({
      type: 'info',
      title: 'Employee Released',
      message: 'Employee has left the company.'
    });
  };

  const handleCreateCampaign = (campaign: any) => {
    setMarketingCampaigns(prev => [...prev, campaign]);
    addNotification({
      type: 'success',
      title: 'Campaign Launched!',
      message: `${campaign.name} is now active!`
    });
  };

  // Calculate current year from game week (starting 1980)
  const currentYear = 1980 + Math.floor((gameWeek - 1) / 52);

  const renderActiveComponent = () => {
    try {
      switch (activeTab) {
        case 'develop':
          return <GameDevelopment />;
        case 'sales':
          return <SalesAnalytics />;
        case 'research':
          return <ResearchLab />;
        case 'employees':
          return (
            <EmployeeSystem
              currentWeek={gameWeek}
              currentYear={currentYear}
              companyMoney={company.money}
              onHireEmployee={handleHireEmployee}
              onFireEmployee={handleFireEmployee}
              employees={employees}
            />
          );
        case 'marketing':
          return (
            <MarketingSystem
              currentWeek={gameWeek}
              companyMoney={company.money}
              games={games}
              onSpendMoney={spendMoney}
              onCreateCampaign={handleCreateCampaign}
            />
          );
        case 'office':
          return (
            <OfficeManagement
              company={company}
              onSpendMoney={spendMoney}
              employees={employees}
            />
          );
        case 'reviews':
          return (
            <GameReviews
              games={games}
              currentWeek={gameWeek}
            />
          );
        case 'achievements':
          return (
            <AchievementSystem
              currentWeek={gameWeek}
              company={company}
              games={games}
              employees={employees}
            />
          );
        case 'competitors':
          return (
            <CompetitorAnalysis
              currentWeek={gameWeek}
              currentYear={currentYear}
              playerCompany={company}
              playerGames={games}
            />
          );
        case 'settings':
          return <GameSettings />;
        case 'notifications':
          return <NotificationCenter />;
        default:
          return <GameDevelopment />;
      }
    } catch (error) {
      console.error('Error rendering component:', error);
      return (
        <div className="p-6">
          <div className="text-red-400">Error loading component: {activeTab}</div>
          <div className="text-sm text-zinc-400 mt-2">{String(error)}</div>
        </div>
      );
    }
  };

  if (gameState === 'menu') {
    try {
      return (
        <>
          <StartScreen
            onStartGame={handleStartGame}
            onStartTutorial={handleStartTutorial}
          />
          {/* <Toaster /> */}
        </>
      );
    } catch (error) {
      console.error('Error rendering StartScreen:', error);
      return (
        <div className="flex items-center justify-center h-screen bg-zinc-950 text-white">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Game Dev Tycoon</h1>
            <div className="text-red-400 mb-4">Error loading start screen</div>
            <button
              onClick={() => setGameState('playing')}
              className="px-4 py-2 bg-blue-600 rounded hover:bg-blue-700"
            >
              Skip to Game
            </button>
          </div>
        </div>
      );
    }
  }

  try {
    return (
      <div className="flex h-screen bg-zinc-950 text-white relative overflow-hidden">
        {/* Particle Background */}
        <ParticleBackground
          theme={particleTheme}
          intensity="low"
          enabled={gameState === 'playing'}
        />

        {/* Success Burst Effect */}
        <SuccessBurst
          trigger={showSuccessBurst}
          onComplete={() => setShowSuccessBurst(false)}
        />

        {/* Left Sidebar */}
        {isLeftPanelOpen && (
          <FloatingElement intensity="subtle" className="company-stats border-r border-zinc-800 z-10 bg-zinc-950/95 backdrop-blur-sm" data-tab="sidebar">
            <Sidebar
              activeTab={activeTab}
              onTabChange={(tab) => {
                setActiveTab(tab);

                // Change particle theme based on tab
                switch (tab) {
                  case 'develop':
                    setParticleTheme('coding');
                    break;
                  case 'sales':
                    setParticleTheme('success');
                    break;
                  case 'achievements':
                    setParticleTheme('warning');
                    break;
                  case 'competitors':
                    setParticleTheme('error');
                    break;
                  default:
                    setParticleTheme('default');
                }

                // Mark tutorial steps as completed
                if (isTutorialActive) {
                  if (tab === 'develop' && !completedTutorialSteps.includes('game-development')) {
                    setCompletedTutorialSteps(prev => [...prev, 'game-development']);
                  } else if (tab === 'research' && !completedTutorialSteps.includes('research-lab')) {
                    setCompletedTutorialSteps(prev => [...prev, 'research-lab']);
                  } else if (tab === 'sales' && !completedTutorialSteps.includes('sales-analytics')) {
                    setCompletedTutorialSteps(prev => [...prev, 'sales-analytics']);
                  }
                }
              }}
            />
          </FloatingElement>
        )}

        {/* Toggle Left Panel Button */}
        {!isLeftPanelOpen && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsLeftPanelOpen(true)}
            className="fixed top-4 left-4 z-20"
          >
            <PanelLeftOpenIcon className="h-4 w-4" />
          </Button>
        )}

        {/* Main Content */}
        <main className="flex-1 overflow-auto relative z-10 bg-zinc-950/80 backdrop-blur-sm">
          {/* Top Bar for Panel Controls */}
          <div className="flex justify-between items-center p-2 border-b border-zinc-800 bg-zinc-900/70 backdrop-blur-sm animate-slide-down">
            <div className="flex items-center gap-2">
              {isLeftPanelOpen && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsLeftPanelOpen(false)}
                  className="interactive-hover"
                >
                  <PanelLeftOpenIcon className="h-4 w-4 rotate-180" />
                </Button>
              )}
              <div className="text-sm text-zinc-400 animate-typing">
                {activeTab.charAt(0).toUpperCase() + activeTab.slice(1).replace('_', ' ')}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="text-xs text-zinc-500 counter-animate">
                Week {gameWeek} • {currentYear}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsRightPanelOpen(!isRightPanelOpen)}
                className="interactive-hover"
              >
                <PanelRightOpenIcon className={`h-4 w-4 ${!isRightPanelOpen ? 'rotate-180' : ''}`} />
              </Button>
            </div>
          </div>

          {/* Component Content */}
          <div data-tab={activeTab} className="h-full animate-scale-in">
            {renderActiveComponent()}
          </div>
        </main>

        {/* Right Panel - Collapsible */}
        {isRightPanelOpen && (
          <FloatingElement
            intensity="subtle"
            className="w-80 border-l border-zinc-800 bg-zinc-900/50 backdrop-blur-sm overflow-auto z-10 animate-slide-up"
          >
            <div className="p-4 space-y-4">
              {/* Time Tracker */}
              <div className="animate-card-hover">
                <TimeTracker
                  currentWeek={gameWeek}
                  isGamePaused={isGamePaused}
                  onTogglePause={isGamePaused ? resumeGame : pauseGame}
                />
              </div>

              {/* Quick Stats */}
              <div className="space-y-3">
                <div className="text-sm font-semibold text-zinc-300 border-b border-zinc-800 pb-2 animate-glow">
                  Company Overview
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-2 bg-zinc-800/50 rounded interactive-hover counter-animate">
                    <div className="text-zinc-400">Games Released</div>
                    <div className="text-lg font-bold text-blue-400">{games.filter(g => g.isReleased).length}</div>
                  </div>
                  <div className="p-2 bg-zinc-800/50 rounded interactive-hover counter-animate">
                    <div className="text-zinc-400">Team Size</div>
                    <div className="text-lg font-bold text-green-400">{employees.length}</div>
                  </div>
                  <div className="p-2 bg-zinc-800/50 rounded interactive-hover counter-animate">
                    <div className="text-zinc-400">Active Campaigns</div>
                    <div className="text-lg font-bold text-orange-400">{marketingCampaigns.filter(c => c.status === 'active').length}</div>
                  </div>
                  <div className="p-2 bg-zinc-800/50 rounded interactive-hover animate-pulse-slow">
                    <div className="text-zinc-400">Gaming Era</div>
                    <div className="text-xs font-bold text-purple-400">
                      {currentYear < 1985 && "🕹️ Arcade"}
                      {currentYear >= 1985 && currentYear < 1995 && "🎮 Console"}
                      {currentYear >= 1995 && currentYear < 2005 && "💿 3D Era"}
                      {currentYear >= 2005 && currentYear < 2015 && "📺 HD Gaming"}
                      {currentYear >= 2015 && "🚀 Modern"}
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="space-y-2">
                <div className="text-sm font-semibold text-zinc-300 border-b border-zinc-800 pb-2">
                  Quick Actions
                </div>
                <div className="grid grid-cols-1 gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setActiveTab('achievements');
                      setShowSuccessBurst(true);
                    }}
                    className="interactive-hover text-xs"
                  >
                    🏆 View Achievements
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setActiveTab('reviews')}
                    className="interactive-hover text-xs"
                  >
                    📰 Check Reviews
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setActiveTab('competitors')}
                    className="interactive-hover text-xs"
                  >
                    🎯 Analyze Competition
                  </Button>
                </div>
              </div>
            </div>
          </FloatingElement>
        )}

        {/* Tutorial System */}
        <TutorialSystem
          isActive={isTutorialActive}
          onComplete={handleTutorialComplete}
          onSkip={handleTutorialSkip}
        />

        {/* Toast Notifications */}
        {/* <Toaster /> */}
      </div>
    );
  } catch (error) {
    console.error('Error rendering main app:', error);
    return (
      <div className="flex items-center justify-center h-screen bg-zinc-950 text-white">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4 text-red-400">Application Error</h1>
          <div className="text-sm text-zinc-400 mb-4">{String(error)}</div>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-blue-600 rounded hover:bg-blue-700"
          >
            Reload Page
          </button>
        </div>
      </div>
    );
  }
}
