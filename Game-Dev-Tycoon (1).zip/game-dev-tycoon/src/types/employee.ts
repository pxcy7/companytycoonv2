// Enhanced Employee System Types

export interface EmployeeSkills {
  programming: number;      // 0-100
  gameDesign: number;      // 0-100
  graphics: number;        // 0-100
  sound: number;          // 0-100
  research: number;       // 0-100
  marketing: number;      // 0-100
  testing: number;        // 0-100
  management: number;     // 0-100
}

export interface EmployeePersonality {
  creativity: number;     // Affects design quality
  focus: number;         // Affects work speed
  teamwork: number;      // Affects team bonuses
  ambition: number;      // Affects skill growth
  stress: number;        // Current stress level (0-100)
  happiness: number;     // Current happiness (0-100)
}

export interface EmployeeNeeds {
  salary: number;        // Monthly salary requirement
  equipment: string[];   // Required equipment/objects
  officeType: 'basic' | 'advanced' | 'premium' | 'executive';
  teamSize: 'solo' | 'small' | 'medium' | 'large';
}

export interface Employee {
  id: string;
  name: string;
  age: number;
  gender: 'male' | 'female';
  avatar: string;        // Avatar image URL or ID

  // Core Stats
  level: number;         // 1-10 (affects skill multipliers)
  experience: number;    // Total experience points
  skills: EmployeeSkills;
  personality: EmployeePersonality;
  needs: EmployeeNeeds;

  // Specializations
  primarySpecialization: EmployeeSpecialization;
  secondarySpecialization?: EmployeeSpecialization;
  favoriteGenres: string[];
  favoriteFeatures: string[];

  // Employment Status
  isHired: boolean;
  hiringCost: number;
  currentTask?: EmployeeTask;
  workEfficiency: number; // 0-150% (affected by happiness, equipment, etc.)

  // Career
  isLegendary: boolean;
  legendaryBonus?: LegendaryBonus;
  careerHistory: EmployeeCareerEntry[];

  // Contract
  contractLength: number; // months remaining
  loyaltyLevel: number;   // 0-100
  lastRaise: number;     // weeks since last raise

  // Development
  skillGrowthRate: number; // How fast they learn
  potentialSkills: EmployeeSkills; // Maximum possible skills
  trainingProgress: TrainingProgress;

  // Quotes and Personality
  quotes: string[];
  workingQuote?: string;
  mood: 'happy' | 'content' | 'neutral' | 'stressed' | 'angry' | 'inspired';
}

export type EmployeeSpecialization =
  | 'programmer'
  | 'game_designer'
  | 'graphic_artist'
  | 'sound_engineer'
  | 'researcher'
  | 'marketer'
  | 'qa_tester'
  | 'producer'
  | 'level_designer'
  | 'ui_designer'
  | 'narrative_designer'
  | 'technical_artist'
  | 'data_analyst';

export interface LegendaryBonus {
  type: 'skill_boost' | 'team_leader' | 'innovation' | 'efficiency' | 'quality';
  name: string;
  description: string;
  effect: {
    skillMultiplier?: number;
    teamBonus?: number;
    qualityBonus?: number;
    speedBonus?: number;
    innovationChance?: number;
  };
}

export interface EmployeeTask {
  type: 'development' | 'research' | 'marketing' | 'testing' | 'training' | 'resting';
  projectId?: string;
  startWeek: number;
  estimatedDuration: number;
  progress: number; // 0-100
  priority: 'low' | 'normal' | 'high' | 'critical';
}

export interface EmployeeCareerEntry {
  company: string;
  role: string;
  startYear: number;
  endYear: number;
  projects: string[];
  skillsGained: Partial<EmployeeSkills>;
}

export interface TrainingProgress {
  skillBeingTrained?: keyof EmployeeSkills;
  progress: number; // 0-100
  trainer?: string; // Employee ID of trainer
  weeksRemaining: number;
  cost: number;
}

// Legendary Developer Definitions (inspired by Mad Games Tycoon 2)
export interface LegendaryDeveloper {
  id: string;
  realName: string;
  gameName: string;
  avatar: string;
  bio: string;
  famousFor: string[];
  skills: EmployeeSkills;
  legendaryBonus: LegendaryBonus;
  availableFromYear: number;
  hiringCost: number;
  quotes: string[];
}

export const LEGENDARY_DEVELOPERS: LegendaryDeveloper[] = [
  {
    id: 'sid_maiern',
    realName: 'Sid Meier',
    gameName: 'Sid Maiern',
    avatar: '/avatars/sid_maiern.png',
    bio: 'Creator of Civilization series and pioneer of strategy games',
    famousFor: ['Civilization', 'Railroad Tycoon', 'Pirates!'],
    skills: {
      programming: 85,
      gameDesign: 98,
      graphics: 60,
      sound: 50,
      research: 95,
      marketing: 70,
      testing: 80,
      management: 85
    },
    legendaryBonus: {
      type: 'innovation',
      name: 'Strategy Genius',
      description: 'Strategy games get +25% quality and innovation bonus',
      effect: {
        qualityBonus: 25,
        innovationChance: 30
      }
    },
    availableFromYear: 1987,
    hiringCost: 150000,
    quotes: [
      "A game is a series of interesting choices.",
      "The goal is to make the player feel clever.",
      "I've always believed that good gameplay trumps good graphics."
    ]
  },
  {
    id: 'hideo_komija',
    realName: 'Hideo Kojima',
    gameName: 'Hideo Komija',
    avatar: '/avatars/hideo_komija.png',
    bio: 'Visionary designer known for cinematic and innovative games',
    famousFor: ['Metal Gear', 'Snatcher', 'Death Stranding'],
    skills: {
      programming: 70,
      gameDesign: 99,
      graphics: 85,
      sound: 90,
      research: 90,
      marketing: 95,
      testing: 75,
      management: 80
    },
    legendaryBonus: {
      type: 'innovation',
      name: 'Auteur Vision',
      description: 'All games get cinematic quality bonus and innovation boost',
      effect: {
        qualityBonus: 20,
        innovationChance: 40,
        teamBonus: 15
      }
    },
    availableFromYear: 1987,
    hiringCost: 200000,
    quotes: [
      "I want my games to be an emotional experience.",
      "The future doesn't belong to people who doubt.",
      "A good story can make even simple gameplay compelling."
    ]
  },
  {
    id: 'shigeru_niyamato',
    realName: 'Shigeru Miyamoto',
    gameName: 'Shigeru Niyamato',
    avatar: '/avatars/shigeru_niyamato.png',
    bio: 'The father of modern video games and creator of Mario',
    famousFor: ['Super Mario', 'The Legend of Zelda', 'Donkey Kong'],
    skills: {
      programming: 75,
      gameDesign: 100,
      graphics: 80,
      sound: 85,
      research: 85,
      marketing: 85,
      testing: 95,
      management: 90
    },
    legendaryBonus: {
      type: 'quality',
      name: 'Nintendo Polish',
      description: 'All platformer and adventure games get supreme quality',
      effect: {
        qualityBonus: 30,
        teamBonus: 20
      }
    },
    availableFromYear: 1981,
    hiringCost: 250000,
    quotes: [
      "A delayed game is eventually good, but a rushed game is forever bad.",
      "I always try to create something fun first.",
      "Video games are meant to be just one thing. Fun."
    ]
  },
  {
    id: 'gabriel_nowell',
    realName: 'Gabe Newell',
    gameName: 'Gabriel Nowell',
    avatar: '/avatars/gabriel_nowell.png',
    bio: 'Co-founder of Valve and revolutionizer of digital distribution',
    famousFor: ['Half-Life', 'Steam', 'Counter-Strike'],
    skills: {
      programming: 90,
      gameDesign: 85,
      graphics: 70,
      sound: 70,
      research: 95,
      marketing: 88,
      testing: 85,
      management: 95
    },
    legendaryBonus: {
      type: 'efficiency',
      name: 'Digital Pioneer',
      description: 'All projects complete 25% faster with quality bonus',
      effect: {
        speedBonus: 25,
        qualityBonus: 15,
        teamBonus: 10
      }
    },
    availableFromYear: 1996,
    hiringCost: 180000,
    quotes: [
      "The most important thing you can do is ship.",
      "We're not just making games, we're building the future.",
      "Customers should be your compass."
    ]
  }
];

// Employee Generation Templates
export interface EmployeeTemplate {
  namePool: string[];
  skillRanges: {
    [K in keyof EmployeeSkills]: [number, number]; // [min, max]
  };
  specializationWeights: {
    [K in EmployeeSpecialization]: number;
  };
  salaryRange: [number, number];
  availableFromYear: number;
}

export const EMPLOYEE_TEMPLATES: { [key: string]: EmployeeTemplate } = {
  junior: {
    namePool: ['Alex', 'Sam', 'Taylor', 'Jordan', 'Casey', 'Riley', 'Morgan', 'Avery'],
    skillRanges: {
      programming: [20, 50],
      gameDesign: [20, 50],
      graphics: [15, 45],
      sound: [10, 40],
      research: [25, 55],
      marketing: [15, 40],
      testing: [30, 60],
      management: [10, 30]
    },
    specializationWeights: {
      programmer: 25,
      game_designer: 20,
      graphic_artist: 20,
      sound_engineer: 15,
      researcher: 10,
      marketer: 5,
      qa_tester: 30,
      producer: 5,
      level_designer: 15,
      ui_designer: 15,
      narrative_designer: 10,
      technical_artist: 10,
      data_analyst: 5
    },
    salaryRange: [2000, 4000],
    availableFromYear: 1980
  },
  senior: {
    namePool: ['Michael', 'Sarah', 'David', 'Lisa', 'Robert', 'Jennifer', 'James', 'Maria'],
    skillRanges: {
      programming: [60, 85],
      gameDesign: [65, 88],
      graphics: [55, 80],
      sound: [50, 75],
      research: [70, 90],
      marketing: [55, 80],
      testing: [65, 85],
      management: [60, 85]
    },
    specializationWeights: {
      programmer: 30,
      game_designer: 25,
      graphic_artist: 20,
      sound_engineer: 15,
      researcher: 20,
      marketer: 15,
      qa_tester: 15,
      producer: 25,
      level_designer: 20,
      ui_designer: 15,
      narrative_designer: 15,
      technical_artist: 20,
      data_analyst: 15
    },
    salaryRange: [8000, 15000],
    availableFromYear: 1985
  },
  expert: {
    namePool: ['William', 'Elizabeth', 'Christopher', 'Margaret', 'Richard', 'Patricia', 'Charles', 'Linda'],
    skillRanges: {
      programming: [80, 95],
      gameDesign: [85, 95],
      graphics: [75, 90],
      sound: [70, 85],
      research: [85, 98],
      marketing: [75, 90],
      testing: [80, 92],
      management: [80, 95]
    },
    specializationWeights: {
      programmer: 20,
      game_designer: 30,
      graphic_artist: 15,
      sound_engineer: 10,
      researcher: 25,
      marketer: 20,
      qa_tester: 10,
      producer: 35,
      level_designer: 15,
      ui_designer: 10,
      narrative_designer: 20,
      technical_artist: 15,
      data_analyst: 20
    },
    salaryRange: [20000, 40000],
    availableFromYear: 1990
  }
};
