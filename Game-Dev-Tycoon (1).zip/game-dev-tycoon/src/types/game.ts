// Core game types and interfaces

export interface GameStats {
  design: number;
  gameplay: number;
  audio: number;
  technical: number;
}

export interface Game {
  id: string;
  name: string;
  topic: string;
  genre: string;
  size: GameSize;
  stats: GameStats;
  engine: string;
  platforms: string[];
  developmentCost: number;
  marketingBudget: number;
  salePrice: number;
  qualityScore: number;
  releaseDate: Date;
  salesData: SalesData;
  isReleased: boolean;
  isInDevelopment: boolean;
}

export interface SalesData {
  totalSales: number;
  currentWeeklySales: number;
  salesHistory: SalesPoint[];
  revenue: number;
  salesLength: number; // in weeks
  currentWeek: number;
  isActive: boolean;
}

export interface SalesPoint {
  week: number;
  sales: number;
  revenue: number;
}

export type GameSize = 'small' | 'medium' | 'large' | 'aaa';

export interface Topic {
  id: string;
  name: string;
  isUnlocked: boolean;
  researchCost: number;
  audienceMultiplier: number;
}

export interface Genre {
  id: string;
  name: string;
  isUnlocked: boolean;
  researchCost: number;
  designImportance: number;
  gameplayImportance: number;
  audioImportance: number;
  technicalImportance: number;
}

export interface Platform {
  id: string;
  name: string;
  isUnlocked: boolean;
  researchCost: number;
  marketShare: number;
  audienceSize: number;
  developmentCost: number;
  royaltyRate: number; // percentage
  isCustom: boolean;
}

export interface Engine {
  id: string;
  name: string;
  isUnlocked: boolean;
  isCustom: boolean;
  cost: number;
  designBonus: number;
  gameplayBonus: number;
  audioBonus: number;
  technicalBonus: number;
  supportedPlatforms: string[];
  developmentTimeMultiplier: number;
}

export interface Employee {
  id: string;
  name: string;
  specialization: 'design' | 'gameplay' | 'audio' | 'technical' | 'management';
  skill: number;
  salary: number;
  experience: number;
  isAssigned: boolean;
}

export interface Company {
  name: string;
  money: number;
  reputation: number;
  researchPoints: number;
  employees: Employee[];
  office: {
    name: string;
    capacity: number;
    cost: number;
    bonuses: GameStats;
  };
}

export interface Research {
  topics: Topic[];
  genres: Genre[];
  platforms: Platform[];
  engines: Engine[];
  activeResearch: {
    type: 'topic' | 'genre' | 'platform' | 'engine';
    id: string;
    progress: number;
    cost: number;
  } | null;
}

export interface GameState {
  company: Company;
  research: Research;
  games: Game[];
  currentGame: Game | null;
  gameWeek: number;
  isGamePaused: boolean;
  notifications: Notification[];
}

export interface Notification {
  id: string;
  type: 'success' | 'warning' | 'error' | 'info';
  title: string;
  message: string;
  timestamp: Date;
  isRead: boolean;
}
