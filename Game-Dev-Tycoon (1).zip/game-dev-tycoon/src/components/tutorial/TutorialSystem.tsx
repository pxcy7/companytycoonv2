'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ArrowRightIcon, CheckCircleIcon, LightbulbIcon, XIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface TutorialStep {
  id: string;
  title: string;
  description: string;
  target?: string; // CSS selector for highlighting
  position?: 'top' | 'bottom' | 'left' | 'right';
  action?: string;
  isCompleted?: boolean;
}

const tutorialSteps: TutorialStep[] = [
  {
    id: 'welcome',
    title: 'Welcome to Game Dev Tycoon!',
    description: 'Build your gaming empire from a small indie studio to a AAA powerhouse. Let\'s start with the basics!',
    action: 'Get Started'
  },
  {
    id: 'company-overview',
    title: 'Your Company',
    description: 'This sidebar shows your company stats: money, reputation, and research points. Keep an eye on your budget!',
    target: '.company-stats',
    position: 'right'
  },
  {
    id: 'game-development',
    title: 'Develop Your First Game',
    description: 'Click on "Develop Game" to create your first masterpiece. You\'ll allocate skill points and choose topics, genres, and platforms.',
    target: '[data-tab="develop"]',
    position: 'right'
  },
  {
    id: 'skill-points',
    title: 'Skill Point Allocation',
    description: 'Distribute skill points across Design, Gameplay, Audio, and Technical. Different genres value different skills!',
    target: '.skill-allocation',
    position: 'top'
  },
  {
    id: 'quality-matters',
    title: 'Quality is Key',
    description: 'Higher quality games sell better and for longer periods. Balance your skill allocation based on the genre you choose.',
    position: 'top'
  },
  {
    id: 'research-lab',
    title: 'Research New Content',
    description: 'Visit the Research Lab to unlock new topics, genres, platforms, and engines. Expand your possibilities!',
    target: '[data-tab="research"]',
    position: 'right'
  },
  {
    id: 'sales-analytics',
    title: 'Track Your Success',
    description: 'Monitor your game sales in real-time. See which games perform best and learn from the data.',
    target: '[data-tab="sales"]',
    position: 'right'
  },
  {
    id: 'reviews-system',
    title: 'Professional Reviews',
    description: 'Check what critics and players think about your games. Reviews affect sales and reputation!',
    target: '[data-tab="reviews"]',
    position: 'right'
  },
  {
    id: 'achievements',
    title: 'Unlock Achievements',
    description: 'Complete challenges to earn achievement points and unlock rewards that help your company grow.',
    target: '[data-tab="achievements"]',
    position: 'right'
  },
  {
    id: 'competitors',
    title: 'Know Your Competition',
    description: 'Analyze rival companies, track market events, and plan your strategy to stay ahead.',
    target: '[data-tab="competitors"]',
    position: 'right'
  },
  {
    id: 'progression',
    title: 'Build Your Empire',
    description: 'Use profits to research new content, hire employees, and upgrade your office. The gaming world awaits!',
    action: 'Start Playing'
  }
];

interface TutorialSystemProps {
  isActive: boolean;
  onComplete: () => void;
  onSkip: () => void;
}

export function TutorialSystem({ isActive, onComplete, onSkip }: TutorialSystemProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (isActive) {
      setIsVisible(true);
    }
  }, [isActive]);

  const handleNext = () => {
    const step = tutorialSteps[currentStep];
    setCompletedSteps(prev => new Set([...prev, step.id]));

    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    setIsVisible(false);
    onComplete();
  };

  const handleSkip = () => {
    setIsVisible(false);
    onSkip();
  };

  const currentTutorialStep = tutorialSteps[currentStep];
  const progress = ((currentStep + 1) / tutorialSteps.length) * 100;

  if (!isActive || !isVisible) return null;

  return (
    <>
      {/* Overlay */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-40"
        onClick={handleSkip}
      />

      {/* Tutorial Card */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          transition={{ duration: 0.3 }}
          className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-md"
        >
          <Card className="border-blue-500/50 bg-zinc-900/95 backdrop-blur-sm">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="text-xs">
                  Step {currentStep + 1} of {tutorialSteps.length}
                </Badge>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleSkip}
                  className="h-6 w-6 p-0"
                >
                  <XIcon className="h-4 w-4" />
                </Button>
              </div>
              <CardTitle className="text-lg flex items-center gap-2">
                <LightbulbIcon className="h-5 w-5 text-yellow-400" />
                {currentTutorialStep.title}
              </CardTitle>
              <Progress value={progress} className="w-full" />
            </CardHeader>
            <CardContent>
              <CardDescription className="text-sm text-zinc-300 mb-6">
                {currentTutorialStep.description}
              </CardDescription>

              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  onClick={handlePrevious}
                  disabled={currentStep === 0}
                  size="sm"
                >
                  Previous
                </Button>

                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    onClick={handleSkip}
                    size="sm"
                    className="text-zinc-400"
                  >
                    Skip Tutorial
                  </Button>
                  <Button onClick={handleNext} size="sm">
                    {currentTutorialStep.action || 'Next'}
                    <ArrowRightIcon className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>

      {/* Highlight Target Element */}
      {currentTutorialStep.target && (
        <TutorialHighlight
          target={currentTutorialStep.target}
          position={currentTutorialStep.position || 'bottom'}
        />
      )}
    </>
  );
}

interface TutorialHighlightProps {
  target: string;
  position: 'top' | 'bottom' | 'left' | 'right';
}

function TutorialHighlight({ target, position }: TutorialHighlightProps) {
  const [elementRect, setElementRect] = useState<DOMRect | null>(null);

  useEffect(() => {
    const element = document.querySelector(target);
    if (element) {
      const rect = element.getBoundingClientRect();
      setElementRect(rect);
    }
  }, [target]);

  if (!elementRect) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed z-45 pointer-events-none"
      style={{
        top: elementRect.top - 4,
        left: elementRect.left - 4,
        width: elementRect.width + 8,
        height: elementRect.height + 8,
      }}
    >
      <div className="w-full h-full border-2 border-blue-400 rounded-lg bg-blue-400/10 animate-pulse" />
    </motion.div>
  );
}

export function TutorialProgress({ completedSteps }: { completedSteps: string[] }) {
  const totalSteps = tutorialSteps.length;
  const completed = completedSteps.length;
  const progress = (completed / totalSteps) * 100;

  if (completed === 0) return null;

  return (
    <Card className="mb-4">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <CheckCircleIcon className="h-4 w-4 text-green-400" />
          Tutorial Progress
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between text-xs text-zinc-400 mb-2">
          <span>Completed: {completed}/{totalSteps}</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-2" />

        {completed === totalSteps && (
          <div className="mt-3 p-2 bg-green-900/20 border border-green-600/30 rounded text-xs text-green-400">
            🎉 Tutorial completed! You're ready to build your gaming empire!
          </div>
        )}
      </CardContent>
    </Card>
  );
}
