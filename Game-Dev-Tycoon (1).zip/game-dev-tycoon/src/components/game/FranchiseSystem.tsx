'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import {
  CrownIcon,
  TrendingUpIcon,
  StarIcon,
  TargetIcon,
  DollarSignIcon,
  GamepadIcon,
  CalendarIcon,
  AwardIcon,
  ZapIcon,
  BookOpenIcon,
  FilmIcon,
  ShoppingCartIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Franchise {
  id: string;
  name: string;
  originalGameId: string;
  sequels: Sequel[];
  brandValue: number; // 0-100
  fanLoyalty: number; // 0-100
  totalSales: number;
  totalRevenue: number;
  merchandising: MerchandisingDeal[];
  licensing: LicensingDeal[];
  status: 'active' | 'dormant' | 'discontinued';
  createdDate: Date;
  lastReleaseDate: Date;
}

interface Sequel {
  id: string;
  gameId: string;
  sequelNumber: number;
  title: string;
  qualityScore: number;
  salesPerformance: 'exceeded' | 'met' | 'below' | 'failed';
  fanReception: 'loved' | 'liked' | 'mixed' | 'disliked' | 'hated';
  releaseDate: Date;
  developmentCost: number;
  salesData: {
    totalSales: number;
    revenue: number;
  };
}

interface MerchandisingDeal {
  id: string;
  type: 'toys' | 'clothing' | 'collectibles' | 'books' | 'movies';
  partner: string;
  upfrontPayment: number;
  royaltyRate: number; // percentage
  duration: number; // months
  projectedRevenue: number;
  startDate: Date;
  status: 'active' | 'completed' | 'cancelled';
}

interface LicensingDeal {
  id: string;
  type: 'mobile_port' | 'console_port' | 'remake' | 'remaster' | 'spinoff';
  licensee: string;
  upfrontFee: number;
  royaltyRate: number;
  minGuarantee: number;
  qualityRequirement: number;
  status: 'negotiating' | 'active' | 'completed';
}

interface FranchiseSystemProps {
  games: any[];
  currentWeek: number;
  companyMoney: number;
  onSpendMoney: (amount: number) => boolean;
  onCreateSequel: (sequelData: any) => void;
}

const MERCHANDISING_PARTNERS = [
  { id: 'toyland', name: 'ToyLand Inc.', specialty: 'toys', reliability: 85 },
  { id: 'fashion_forward', name: 'Fashion Forward', specialty: 'clothing', reliability: 90 },
  { id: 'collectors_corner', name: 'Collectors Corner', specialty: 'collectibles', reliability: 95 },
  { id: 'page_turner', name: 'Page Turner Books', specialty: 'books', reliability: 80 },
  { id: 'blockbuster_films', name: 'Blockbuster Films', specialty: 'movies', reliability: 70 }
];

const LICENSING_COMPANIES = [
  { id: 'mobile_masters', name: 'Mobile Masters', specialty: 'mobile_port', offer_rate: 0.15 },
  { id: 'console_kings', name: 'Console Kings', specialty: 'console_port', offer_rate: 0.12 },
  { id: 'retro_revival', name: 'Retro Revival Studios', specialty: 'remake', offer_rate: 0.20 },
  { id: 'hd_remasters', name: 'HD Remasters Co.', specialty: 'remaster', offer_rate: 0.10 },
  { id: 'spinoff_specialists', name: 'Spinoff Specialists', specialty: 'spinoff', offer_rate: 0.18 }
];

export function FranchiseSystem({
  games,
  currentWeek,
  companyMoney,
  onSpendMoney,
  onCreateSequel
}: FranchiseSystemProps) {
  const [franchises, setFranchises] = useState<Franchise[]>([]);
  const [selectedFranchise, setSelectedFranchise] = useState<string>('');
  const [activeTab, setActiveTab] = useState('overview');
  const [newSequelData, setNewSequelData] = useState({
    franchiseId: '',
    title: '',
    budget: 50000,
    marketingBudget: 10000
  });

  // Identify potential franchises from successful games
  useEffect(() => {
    const eligibleGames = games.filter(game =>
      game.isReleased &&
      game.qualityScore >= 70 &&
      game.salesData.totalSales >= 50000 &&
      !franchises.some(f => f.originalGameId === game.id)
    );

    eligibleGames.forEach(game => {
      // Auto-create franchise for very successful games
      if (game.qualityScore >= 85 && game.salesData.totalSales >= 100000) {
        createFranchise(game);
      }
    });
  }, [games]);

  const createFranchise = (originalGame: any) => {
    const newFranchise: Franchise = {
      id: Math.random().toString(36).substr(2, 9),
      name: originalGame.name,
      originalGameId: originalGame.id,
      sequels: [],
      brandValue: Math.min(originalGame.qualityScore, 90),
      fanLoyalty: Math.min(originalGame.qualityScore - 10, 85),
      totalSales: originalGame.salesData.totalSales,
      totalRevenue: originalGame.salesData.revenue,
      merchandising: [],
      licensing: [],
      status: 'active',
      createdDate: new Date(),
      lastReleaseDate: originalGame.releaseDate
    };

    setFranchises(prev => [...prev, newFranchise]);
  };

  const createSequel = () => {
    const franchise = franchises.find(f => f.id === newSequelData.franchiseId);
    if (!franchise) return;

    const totalCost = newSequelData.budget + newSequelData.marketingBudget;
    if (!onSpendMoney(totalCost)) return;

    const sequelNumber = franchise.sequels.length + 2;
    const newSequel: Sequel = {
      id: Math.random().toString(36).substr(2, 9),
      gameId: '', // Will be set when game is created
      sequelNumber,
      title: newSequelData.title || `${franchise.name} ${sequelNumber}`,
      qualityScore: 0, // Will be determined by development
      salesPerformance: 'met',
      fanReception: 'liked',
      releaseDate: new Date(),
      developmentCost: newSequelData.budget,
      salesData: {
        totalSales: 0,
        revenue: 0
      }
    };

    // Calculate sequel modifier based on franchise health
    const franchiseModifier = {
      brandBonus: franchise.brandValue / 100,
      loyaltyBonus: franchise.fanLoyalty / 100,
      sequelFatigue: Math.max(0, 1 - (franchise.sequels.length * 0.1))
    };

    onCreateSequel({
      ...newSequel,
      franchiseModifier,
      originalGame: games.find(g => g.id === franchise.originalGameId)
    });

    // Update franchise
    setFranchises(prev => prev.map(f =>
      f.id === franchise.id
        ? { ...f, sequels: [...f.sequels, newSequel] }
        : f
    ));

    // Reset form
    setNewSequelData({
      franchiseId: '',
      title: '',
      budget: 50000,
      marketingBudget: 10000
    });
  };

  const createMerchandisingDeal = (franchiseId: string, dealType: string) => {
    const partner = MERCHANDISING_PARTNERS.find(p => p.specialty === dealType);
    if (!partner) return;

    const franchise = franchises.find(f => f.id === franchiseId);
    if (!franchise) return;

    const dealValue = franchise.brandValue * 1000 + Math.random() * 50000;
    const upfront = dealValue * 0.3;

    if (!onSpendMoney(5000)) return; // Deal negotiation cost

    const newDeal: MerchandisingDeal = {
      id: Math.random().toString(36).substr(2, 9),
      type: dealType as any,
      partner: partner.name,
      upfrontPayment: upfront,
      royaltyRate: 15 + Math.random() * 10,
      duration: 12 + Math.random() * 24,
      projectedRevenue: dealValue,
      startDate: new Date(),
      status: 'active'
    };

    setFranchises(prev => prev.map(f =>
      f.id === franchiseId
        ? { ...f, merchandising: [...f.merchandising, newDeal] }
        : f
    ));
  };

  const selectedFranchiseData = franchises.find(f => f.id === selectedFranchise);

  const getFranchiseHealthColor = (value: number) => {
    if (value >= 80) return 'text-green-400';
    if (value >= 60) return 'text-yellow-400';
    if (value >= 40) return 'text-orange-400';
    return 'text-red-400';
  };

  const getPerformanceIcon = (performance: string) => {
    switch (performance) {
      case 'exceeded': return <TrendingUpIcon className="h-4 w-4 text-green-400" />;
      case 'met': return <TargetIcon className="h-4 w-4 text-blue-400" />;
      case 'below': return <TrendingDownIcon className="h-4 w-4 text-orange-400" />;
      case 'failed': return <TrendingDownIcon className="h-4 w-4 text-red-400" />;
      default: return <TargetIcon className="h-4 w-4 text-zinc-400" />;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <CrownIcon className="h-6 w-6 text-yellow-400" />
            Franchise Management
          </h2>
          <p className="text-zinc-400 mt-1">Build lasting game series and expand your IP</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-zinc-400">Active Franchises</div>
          <div className="text-xl font-bold text-yellow-400">{franchises.filter(f => f.status === 'active').length}</div>
        </div>
      </div>

      {/* Franchise Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Total Franchises</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-400">{franchises.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Total Sequels</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-400">
              {franchises.reduce((sum, f) => sum + f.sequels.length, 0)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Franchise Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">
              ${franchises.reduce((sum, f) => sum + f.totalRevenue, 0).toLocaleString()}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Avg Brand Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-400">
              {franchises.length > 0
                ? Math.round(franchises.reduce((sum, f) => sum + f.brandValue, 0) / franchises.length)
                : 0}
            </div>
          </CardContent>
        </Card>
      </div>

      {franchises.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <CrownIcon className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-zinc-400 mb-2">No Franchises Yet</h3>
            <p className="text-zinc-500 mb-4">
              Create successful games (70+ quality, 50k+ sales) to start franchises
            </p>
          </CardContent>
        </Card>
      ) : (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="sequels">Sequels</TabsTrigger>
            <TabsTrigger value="merchandising">Merchandising</TabsTrigger>
            <TabsTrigger value="licensing">Licensing</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Franchise Selection */}
            <div className="flex flex-wrap gap-2">
              {franchises.map((franchise) => (
                <Button
                  key={franchise.id}
                  variant={selectedFranchise === franchise.id ? "default" : "outline"}
                  onClick={() => setSelectedFranchise(franchise.id)}
                  className="flex items-center gap-2"
                >
                  <CrownIcon className="h-4 w-4" />
                  {franchise.name}
                  <Badge variant="secondary" className="ml-1">
                    {franchise.sequels.length + 1}
                  </Badge>
                </Button>
              ))}
            </div>

            {/* Selected Franchise Details */}
            {selectedFranchiseData && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CrownIcon className="h-5 w-5 text-yellow-400" />
                      {selectedFranchiseData.name} Franchise
                    </CardTitle>
                    <CardDescription>
                      Created {selectedFranchiseData.createdDate.toLocaleDateString()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Brand Value</Label>
                        <div className={`text-2xl font-bold ${getFranchiseHealthColor(selectedFranchiseData.brandValue)}`}>
                          {selectedFranchiseData.brandValue}/100
                        </div>
                        <Progress value={selectedFranchiseData.brandValue} className="mt-1" />
                      </div>
                      <div>
                        <Label>Fan Loyalty</Label>
                        <div className={`text-2xl font-bold ${getFranchiseHealthColor(selectedFranchiseData.fanLoyalty)}`}>
                          {selectedFranchiseData.fanLoyalty}/100
                        </div>
                        <Progress value={selectedFranchiseData.fanLoyalty} className="mt-1" />
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Total Games:</span>
                        <span className="font-bold">{selectedFranchiseData.sequels.length + 1}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Total Sales:</span>
                        <span className="font-bold text-blue-400">
                          {selectedFranchiseData.totalSales.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Total Revenue:</span>
                        <span className="font-bold text-green-400">
                          ${selectedFranchiseData.totalRevenue.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Status:</span>
                        <Badge className={
                          selectedFranchiseData.status === 'active' ? 'bg-green-600' :
                          selectedFranchiseData.status === 'dormant' ? 'bg-yellow-600' :
                          'bg-red-600'
                        }>
                          {selectedFranchiseData.status}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Franchise Timeline</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {/* Original Game */}
                      <div className="flex items-center gap-3 p-3 bg-zinc-800/50 rounded">
                        <GamepadIcon className="h-5 w-5 text-blue-400" />
                        <div className="flex-1">
                          <div className="font-semibold">{selectedFranchiseData.name}</div>
                          <div className="text-sm text-zinc-400">Original Game</div>
                        </div>
                        <StarIcon className="h-4 w-4 text-yellow-400" />
                      </div>

                      {/* Sequels */}
                      {selectedFranchiseData.sequels.map((sequel) => (
                        <div key={sequel.id} className="flex items-center gap-3 p-3 bg-zinc-800/30 rounded">
                          <GamepadIcon className="h-5 w-5 text-green-400" />
                          <div className="flex-1">
                            <div className="font-semibold">{sequel.title}</div>
                            <div className="text-sm text-zinc-400">
                              {sequel.releaseDate.toLocaleDateString()}
                            </div>
                          </div>
                          {getPerformanceIcon(sequel.salesPerformance)}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="sequels" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Create New Sequel */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ZapIcon className="h-5 w-5 text-green-400" />
                    Create Sequel
                  </CardTitle>
                  <CardDescription>Develop the next game in your franchise</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Select Franchise</Label>
                    <Select
                      value={newSequelData.franchiseId}
                      onValueChange={(value) => setNewSequelData(prev => ({ ...prev, franchiseId: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Choose franchise" />
                      </SelectTrigger>
                      <SelectContent>
                        {franchises.filter(f => f.status === 'active').map((franchise) => (
                          <SelectItem key={franchise.id} value={franchise.id}>
                            {franchise.name} ({franchise.sequels.length + 1} games)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Sequel Title</Label>
                    <Input
                      value={newSequelData.title}
                      onChange={(e) => setNewSequelData(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Leave blank for auto-naming"
                    />
                  </div>

                  <div>
                    <Label>Development Budget: ${newSequelData.budget.toLocaleString()}</Label>
                    <input
                      type="range"
                      min="25000"
                      max="200000"
                      step="5000"
                      value={newSequelData.budget}
                      onChange={(e) => setNewSequelData(prev => ({ ...prev, budget: Number(e.target.value) }))}
                      className="w-full"
                    />
                  </div>

                  <div>
                    <Label>Marketing Budget: ${newSequelData.marketingBudget.toLocaleString()}</Label>
                    <input
                      type="range"
                      min="5000"
                      max="50000"
                      step="1000"
                      value={newSequelData.marketingBudget}
                      onChange={(e) => setNewSequelData(prev => ({ ...prev, marketingBudget: Number(e.target.value) }))}
                      className="w-full"
                    />
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Total Cost:</span>
                      <span className={companyMoney >= (newSequelData.budget + newSequelData.marketingBudget) ? 'text-green-400' : 'text-red-400'}>
                        ${(newSequelData.budget + newSequelData.marketingBudget).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <Button
                    onClick={createSequel}
                    disabled={!newSequelData.franchiseId || companyMoney < (newSequelData.budget + newSequelData.marketingBudget)}
                    className="w-full"
                  >
                    Start Development
                  </Button>
                </CardContent>
              </Card>

              {/* Sequel Performance */}
              <Card>
                <CardHeader>
                  <CardTitle>Sequel Performance Guide</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="p-3 bg-green-900/20 border border-green-600/30 rounded">
                      <h4 className="font-semibold text-green-400">Success Factors</h4>
                      <ul className="text-sm mt-2 space-y-1">
                        <li>• Improve on original game quality</li>
                        <li>• Maintain franchise themes</li>
                        <li>• Don't rush development</li>
                        <li>• Listen to fan feedback</li>
                      </ul>
                    </div>

                    <div className="p-3 bg-red-900/20 border border-red-600/30 rounded">
                      <h4 className="font-semibold text-red-400">Risk Factors</h4>
                      <ul className="text-sm mt-2 space-y-1">
                        <li>• Sequel fatigue (3+ games)</li>
                        <li>• Major gameplay changes</li>
                        <li>• Long gaps between releases</li>
                        <li>• Lower quality than predecessor</li>
                      </ul>
                    </div>

                    <div className="p-3 bg-blue-900/20 border border-blue-600/30 rounded">
                      <h4 className="font-semibold text-blue-400">Franchise Bonuses</h4>
                      <ul className="text-sm mt-2 space-y-1">
                        <li>• Built-in fan base</li>
                        <li>• Marketing recognition</li>
                        <li>• Established mechanics</li>
                        <li>• Merchandising opportunities</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="merchandising" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {MERCHANDISING_PARTNERS.map((partner) => (
                <Card key={partner.id} className="cursor-pointer hover:bg-zinc-800/50 transition-colors">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <ShoppingCartIcon className="h-5 w-5 text-blue-400" />
                      {partner.name}
                    </CardTitle>
                    <CardDescription>Specializes in {partner.specialty}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Reliability:</span>
                      <span className="font-bold">{partner.reliability}%</span>
                    </div>

                    <Button
                      size="sm"
                      className="w-full"
                      onClick={() => selectedFranchise && createMerchandisingDeal(selectedFranchise, partner.specialty)}
                      disabled={!selectedFranchise}
                    >
                      Negotiate Deal
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Active Deals */}
            {selectedFranchiseData?.merchandising.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Active Merchandising Deals</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {selectedFranchiseData.merchandising.map((deal) => (
                      <div key={deal.id} className="p-3 border border-zinc-700 rounded">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-semibold">{deal.partner}</h4>
                            <p className="text-sm text-zinc-400 capitalize">{deal.type} merchandise</p>
                          </div>
                          <Badge className={
                            deal.status === 'active' ? 'bg-green-600' :
                            deal.status === 'completed' ? 'bg-blue-600' :
                            'bg-red-600'
                          }>
                            {deal.status}
                          </Badge>
                        </div>
                        <div className="mt-2 grid grid-cols-2 gap-4 text-sm">
                          <div>Upfront: ${deal.upfrontPayment.toLocaleString()}</div>
                          <div>Royalty: {deal.royaltyRate}%</div>
                          <div>Duration: {deal.duration} months</div>
                          <div>Projected: ${deal.projectedRevenue.toLocaleString()}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="licensing" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {LICENSING_COMPANIES.map((company) => (
                <Card key={company.id} className="cursor-pointer hover:bg-zinc-800/50 transition-colors">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <BookOpenIcon className="h-5 w-5 text-purple-400" />
                      {company.name}
                    </CardTitle>
                    <CardDescription>Specializes in {company.specialty.replace('_', ' ')}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Offer Rate:</span>
                      <span className="font-bold">{(company.offer_rate * 100).toFixed(1)}%</span>
                    </div>

                    <Button
                      size="sm"
                      className="w-full"
                      disabled={!selectedFranchise}
                    >
                      Request Quote
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
