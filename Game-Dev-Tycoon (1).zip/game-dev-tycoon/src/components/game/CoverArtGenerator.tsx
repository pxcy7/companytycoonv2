'use client';

import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  ImageIcon,
  PaletteIcon,
  WandIcon,
  DownloadIcon,
  RefreshCwIcon,
  SaveIcon,
  EyeIcon,
  ZapIcon,
  SparklesIcon,
  LayersIcon,
  TypeIcon,
  AdjustmentsIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface CoverArtStyle {
  id: string;
  name: string;
  description: string;
  baseTemplate: string;
  colorPalette: string[];
  typography: string;
  effects: string[];
  suitableFor: string[];
}

interface GeneratedCover {
  id: string;
  gameTitle: string;
  style: string;
  genre: string;
  elements: CoverElement[];
  colors: string[];
  timestamp: Date;
  downloadUrl: string;
}

interface CoverElement {
  type: 'title' | 'character' | 'background' | 'logo' | 'effect';
  content: string;
  position: { x: number; y: number };
  size: number;
  color: string;
  opacity: number;
  rotation: number;
}

interface CoverArtGeneratorProps {
  gameTitle?: string;
  gameGenre?: string;
  gameTheme?: string;
  onSave?: (cover: GeneratedCover) => void;
}

const ART_STYLES: CoverArtStyle[] = [
  {
    id: 'modern_minimalist',
    name: 'Modern Minimalist',
    description: 'Clean, simple design with bold typography',
    baseTemplate: 'minimalist',
    colorPalette: ['#1a1a1a', '#ffffff', '#3b82f6', '#64748b'],
    typography: 'sans-serif-bold',
    effects: ['gradient', 'shadow'],
    suitableFor: ['puzzle', 'strategy', 'indie']
  },
  {
    id: 'retro_pixel',
    name: 'Retro Pixel Art',
    description: '8-bit inspired pixel art style',
    baseTemplate: 'pixel',
    colorPalette: ['#ff6b6b', '#4ecdc4', '#ffe66d', '#6a4c93'],
    typography: 'pixel-font',
    effects: ['pixelate', 'scan-lines'],
    suitableFor: ['arcade', 'retro', 'platformer']
  },
  {
    id: 'dark_fantasy',
    name: 'Dark Fantasy',
    description: 'Gothic and mysterious atmosphere',
    baseTemplate: 'dark',
    colorPalette: ['#1a0b1a', '#4a0e4e', '#8b5a3c', '#d4af37'],
    typography: 'gothic',
    effects: ['fog', 'glow', 'particles'],
    suitableFor: ['rpg', 'adventure', 'horror']
  },
  {
    id: 'sci_fi_neon',
    name: 'Sci-Fi Neon',
    description: 'Futuristic with neon accents',
    baseTemplate: 'futuristic',
    colorPalette: ['#0a0a0a', '#00ffff', '#ff00ff', '#ffff00'],
    typography: 'futuristic',
    effects: ['neon-glow', 'hologram', 'grid'],
    suitableFor: ['action', 'shooter', 'simulation']
  },
  {
    id: 'hand_drawn',
    name: 'Hand-Drawn Artistic',
    description: 'Organic, illustrated aesthetic',
    baseTemplate: 'artistic',
    colorPalette: ['#f7f3e9', '#8b4513', '#228b22', '#dc143c'],
    typography: 'handwritten',
    effects: ['brush-stroke', 'texture', 'watercolor'],
    suitableFor: ['adventure', 'indie', 'casual']
  },
  {
    id: 'corporate_professional',
    name: 'Corporate Professional',
    description: 'Business-like, professional appearance',
    baseTemplate: 'professional',
    colorPalette: ['#ffffff', '#2563eb', '#64748b', '#1e293b'],
    typography: 'corporate',
    effects: ['gradient', 'reflection'],
    suitableFor: ['simulation', 'strategy', 'educational']
  }
];

const GENRE_TEMPLATES = {
  action: { primaryColor: '#ff4444', secondaryColor: '#ffaa00', style: 'dynamic' },
  adventure: { primaryColor: '#4444ff', secondaryColor: '#44ffaa', style: 'exploration' },
  rpg: { primaryColor: '#aa44ff', secondaryColor: '#ffaa44', style: 'fantasy' },
  strategy: { primaryColor: '#44aaff', secondaryColor: '#aaffaa', style: 'analytical' },
  puzzle: { primaryColor: '#ffaa44', secondaryColor: '#aa44ff', style: 'clean' },
  simulation: { primaryColor: '#44ffaa', secondaryColor: '#4444ff', style: 'realistic' },
  sports: { primaryColor: '#ff6600', secondaryColor: '#00ff66', style: 'energetic' },
  racing: { primaryColor: '#ff0066', secondaryColor: '#66ff00', style: 'speed' }
};

export function CoverArtGenerator({
  gameTitle = '',
  gameGenre = '',
  gameTheme = '',
  onSave
}: CoverArtGeneratorProps) {
  const [selectedStyle, setSelectedStyle] = useState<string>('modern_minimalist');
  const [generatedCovers, setGeneratedCovers] = useState<GeneratedCover[]>([]);
  const [currentCover, setCurrentCover] = useState<GeneratedCover | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [customization, setCustomization] = useState({
    title: gameTitle,
    subtitle: '',
    primaryColor: '#3b82f6',
    secondaryColor: '#64748b',
    backgroundIntensity: 70,
    titleSize: 48,
    effectIntensity: 50,
    logoPosition: 'center'
  });

  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Auto-generate initial cover when component mounts
  useEffect(() => {
    if (gameTitle && gameGenre) {
      generateCoverArt();
    }
  }, [gameTitle, gameGenre]);

  const generateCoverArt = async () => {
    setIsGenerating(true);

    // Simulate AI generation delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    const style = ART_STYLES.find(s => s.id === selectedStyle) || ART_STYLES[0];
    const genreTemplate = GENRE_TEMPLATES[gameGenre as keyof typeof GENRE_TEMPLATES];

    const newCover: GeneratedCover = {
      id: Math.random().toString(36).substr(2, 9),
      gameTitle: customization.title || 'Untitled Game',
      style: style.name,
      genre: gameGenre,
      elements: generateCoverElements(style, genreTemplate),
      colors: style.colorPalette,
      timestamp: new Date(),
      downloadUrl: '' // Would be set after canvas rendering
    };

    setCurrentCover(newCover);
    setGeneratedCovers(prev => [newCover, ...prev.slice(0, 9)]); // Keep last 10
    setIsGenerating(false);

    // Render the cover to canvas
    renderCoverToCanvas(newCover);
  };

  const generateCoverElements = (style: CoverArtStyle, genreTemplate: any): CoverElement[] => {
    const elements: CoverElement[] = [];

    // Background element
    elements.push({
      type: 'background',
      content: style.baseTemplate,
      position: { x: 0, y: 0 },
      size: 100,
      color: genreTemplate?.primaryColor || style.colorPalette[0],
      opacity: customization.backgroundIntensity / 100,
      rotation: 0
    });

    // Title element
    elements.push({
      type: 'title',
      content: customization.title || 'Game Title',
      position: { x: 50, y: customization.logoPosition === 'top' ? 20 : 50 },
      size: customization.titleSize,
      color: style.colorPalette[1],
      opacity: 1,
      rotation: 0
    });

    // Genre-specific character/icon
    if (genreTemplate) {
      elements.push({
        type: 'character',
        content: getGenreIcon(gameGenre),
        position: { x: 75, y: 25 },
        size: 40,
        color: genreTemplate.secondaryColor,
        opacity: 0.8,
        rotation: Math.random() * 20 - 10
      });
    }

    // Effects based on style
    style.effects.forEach((effect, index) => {
      elements.push({
        type: 'effect',
        content: effect,
        position: { x: Math.random() * 100, y: Math.random() * 100 },
        size: 20 + Math.random() * 30,
        color: style.colorPalette[Math.floor(Math.random() * style.colorPalette.length)],
        opacity: (customization.effectIntensity / 100) * 0.6,
        rotation: Math.random() * 360
      });
    });

    return elements;
  };

  const getGenreIcon = (genre: string): string => {
    const icons = {
      action: '⚔️',
      adventure: '🗺️',
      rpg: '🐉',
      strategy: '♟️',
      puzzle: '🧩',
      simulation: '🏗️',
      sports: '⚽',
      racing: '🏎️'
    };
    return icons[genre as keyof typeof icons] || '🎮';
  };

  const renderCoverToCanvas = (cover: GeneratedCover) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size (standard game cover dimensions)
    canvas.width = 400;
    canvas.height = 600;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Render each element
    cover.elements.forEach(element => {
      ctx.save();

      const x = (element.position.x / 100) * canvas.width;
      const y = (element.position.y / 100) * canvas.height;

      ctx.globalAlpha = element.opacity;
      ctx.translate(x, y);
      ctx.rotate((element.rotation * Math.PI) / 180);

      switch (element.type) {
        case 'background':
          renderBackground(ctx, element, canvas.width, canvas.height);
          break;
        case 'title':
          renderTitle(ctx, element);
          break;
        case 'character':
          renderCharacter(ctx, element);
          break;
        case 'effect':
          renderEffect(ctx, element);
          break;
      }

      ctx.restore();
    });
  };

  const renderBackground = (ctx: CanvasRenderingContext2D, element: CoverElement, width: number, height: number) => {
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, element.color);
    gradient.addColorStop(1, adjustColor(element.color, -30));

    ctx.fillStyle = gradient;
    ctx.fillRect(-width/2, -height/2, width, height);
  };

  const renderTitle = (ctx: CanvasRenderingContext2D, element: CoverElement) => {
    ctx.fillStyle = element.color;
    ctx.font = `bold ${element.size}px Arial`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    // Add text shadow
    ctx.shadowColor = 'rgba(0,0,0,0.5)';
    ctx.shadowBlur = 4;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 2;

    ctx.fillText(element.content, 0, 0);
  };

  const renderCharacter = (ctx: CanvasRenderingContext2D, element: CoverElement) => {
    ctx.font = `${element.size}px Arial`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(element.content, 0, 0);
  };

  const renderEffect = (ctx: CanvasRenderingContext2D, element: CoverElement) => {
    ctx.fillStyle = element.color;
    ctx.beginPath();
    ctx.arc(0, 0, element.size / 2, 0, Math.PI * 2);
    ctx.fill();
  };

  const adjustColor = (color: string, amount: number): string => {
    // Simple color adjustment (would be more sophisticated in real implementation)
    return color;
  };

  const downloadCover = () => {
    const canvas = canvasRef.current;
    if (!canvas || !currentCover) return;

    const link = document.createElement('a');
    link.download = `${currentCover.gameTitle.replace(/\s+/g, '_')}_cover.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  const saveCover = () => {
    if (currentCover && onSave) {
      onSave(currentCover);
    }
  };

  const selectedStyleData = ART_STYLES.find(s => s.id === selectedStyle);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <PaletteIcon className="h-6 w-6 text-purple-400" />
            Cover Art Generator
          </h2>
          <p className="text-zinc-400 mt-1">Create stunning game cover art with AI assistance</p>
        </div>
        <Button
          onClick={generateCoverArt}
          disabled={isGenerating}
          className="bg-purple-600 hover:bg-purple-700"
        >
          {isGenerating ? (
            <>
              <RefreshCwIcon className="h-4 w-4 mr-2 animate-spin" />
              Generating...
            </>
          ) : (
            <>
              <WandIcon className="h-4 w-4 mr-2" />
              Generate Art
            </>
          )}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Configuration Panel */}
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AdjustmentsIcon className="h-5 w-5" />
                Customization
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Game Title</Label>
                <Input
                  value={customization.title}
                  onChange={(e) => setCustomization(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Enter game title"
                />
              </div>

              <div>
                <Label>Art Style</Label>
                <Select value={selectedStyle} onValueChange={setSelectedStyle}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ART_STYLES.map((style) => (
                      <SelectItem key={style.id} value={style.id}>
                        {style.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {selectedStyleData && (
                  <p className="text-xs text-zinc-500 mt-1">{selectedStyleData.description}</p>
                )}
              </div>

              <div>
                <Label>Primary Color</Label>
                <div className="flex gap-2 mt-1">
                  <input
                    type="color"
                    value={customization.primaryColor}
                    onChange={(e) => setCustomization(prev => ({ ...prev, primaryColor: e.target.value }))}
                    className="w-12 h-8 rounded border border-zinc-600"
                  />
                  <Input
                    value={customization.primaryColor}
                    onChange={(e) => setCustomization(prev => ({ ...prev, primaryColor: e.target.value }))}
                    className="flex-1"
                  />
                </div>
              </div>

              <div>
                <Label>Title Size: {customization.titleSize}px</Label>
                <Slider
                  value={[customization.titleSize]}
                  onValueChange={([value]) => setCustomization(prev => ({ ...prev, titleSize: value }))}
                  min={24}
                  max={72}
                  step={2}
                  className="mt-2"
                />
              </div>

              <div>
                <Label>Background Intensity: {customization.backgroundIntensity}%</Label>
                <Slider
                  value={[customization.backgroundIntensity]}
                  onValueChange={([value]) => setCustomization(prev => ({ ...prev, backgroundIntensity: value }))}
                  min={0}
                  max={100}
                  step={5}
                  className="mt-2"
                />
              </div>

              <div>
                <Label>Effect Intensity: {customization.effectIntensity}%</Label>
                <Slider
                  value={[customization.effectIntensity]}
                  onValueChange={([value]) => setCustomization(prev => ({ ...prev, effectIntensity: value }))}
                  min={0}
                  max={100}
                  step={5}
                  className="mt-2"
                />
              </div>
            </CardContent>
          </Card>

          {/* Style Recommendations */}
          {selectedStyleData && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Style Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <Label className="text-xs">Suitable For:</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {selectedStyleData.suitableFor.map((genre) => (
                      <Badge key={genre} variant="outline" className="text-xs">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-xs">Color Palette:</Label>
                  <div className="flex gap-1 mt-1">
                    {selectedStyleData.colorPalette.map((color, index) => (
                      <div
                        key={index}
                        className="w-6 h-6 rounded border border-zinc-600"
                        style={{ backgroundColor: color }}
                        title={color}
                      />
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-xs">Effects:</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {selectedStyleData.effects.map((effect) => (
                      <Badge key={effect} variant="secondary" className="text-xs">
                        {effect}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Preview Panel */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <EyeIcon className="h-5 w-5" />
                Live Preview
              </CardTitle>
            </CardHeader>
            <CardContent className="flex justify-center">
              <div className="relative">
                <canvas
                  ref={canvasRef}
                  className="border border-zinc-600 rounded-lg shadow-lg max-w-full h-auto"
                  style={{ maxHeight: '500px' }}
                />
                {isGenerating && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-lg">
                    <div className="text-center">
                      <SparklesIcon className="h-8 w-8 text-purple-400 animate-spin mx-auto mb-2" />
                      <p className="text-white">Generating artwork...</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          {currentCover && (
            <div className="flex gap-4 justify-center">
              <Button onClick={downloadCover} variant="outline">
                <DownloadIcon className="h-4 w-4 mr-2" />
                Download PNG
              </Button>
              <Button onClick={saveCover} variant="outline">
                <SaveIcon className="h-4 w-4 mr-2" />
                Save to Library
              </Button>
              <Button onClick={generateCoverArt} variant="outline">
                <RefreshCwIcon className="h-4 w-4 mr-2" />
                Regenerate
              </Button>
            </div>
          )}

          {/* Generated Covers History */}
          {generatedCovers.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LayersIcon className="h-5 w-5" />
                  Recent Generations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 md:grid-cols-4 gap-3">
                  {generatedCovers.map((cover) => (
                    <motion.div
                      key={cover.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="aspect-[2/3] bg-zinc-800 rounded border border-zinc-600 p-2 cursor-pointer hover:border-zinc-500 transition-colors"
                      onClick={() => setCurrentCover(cover)}
                    >
                      <div className="w-full h-full bg-gradient-to-br from-zinc-700 to-zinc-800 rounded flex items-center justify-center text-xs text-center">
                        <div>
                          <div className="font-semibold">{cover.gameTitle}</div>
                          <div className="text-zinc-400">{cover.style}</div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
