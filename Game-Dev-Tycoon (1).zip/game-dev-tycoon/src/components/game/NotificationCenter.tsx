'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import {
  BellIcon,
  CheckCircleIcon,
  AlertCircleIcon,
  InfoIcon,
  XCircleIcon,
  SearchIcon,
  TrashIcon,
  ArchiveIcon,
  FilterIcon,
  SortAscIcon,
  MarkdownIcon,
  CalendarIcon,
  TrendingUpIcon,
  UsersIcon,
  DollarSignIcon,
  BeakerIcon,
  GamepadIcon
} from 'lucide-react';
import { useGameStore } from '@/store/gameStore';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';

interface Notification {
  id: string;
  type: 'success' | 'warning' | 'error' | 'info';
  category: 'game' | 'sales' | 'employees' | 'research' | 'marketing' | 'system';
  title: string;
  message: string;
  timestamp: Date;
  isRead: boolean;
  isArchived: boolean;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  actionable?: {
    label: string;
    action: () => void;
  };
}

export function NotificationCenter() {
  const { notifications, markNotificationRead } = useGameStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'priority'>('newest');
  const [showArchived, setShowArchived] = useState(false);
  const [selectedNotifications, setSelectedNotifications] = useState<string[]>([]);

  // Extended notifications with mock data for demonstration
  const [extendedNotifications, setExtendedNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'success',
      category: 'game',
      title: 'Game Released Successfully!',
      message: 'Your game "Super Adventure Quest" has been released and is now available for purchase.',
      timestamp: new Date(Date.now() - 2 * 60 * 1000), // 2 minutes ago
      isRead: false,
      isArchived: false,
      priority: 'high',
      actionable: {
        label: 'View Sales',
        action: () => console.log('Navigate to sales')
      }
    },
    {
      id: '2',
      type: 'info',
      category: 'sales',
      title: 'Sales Milestone Reached',
      message: 'Your game has sold 10,000 copies! Revenue: $199,900',
      timestamp: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
      isRead: false,
      isArchived: false,
      priority: 'normal'
    },
    {
      id: '3',
      type: 'warning',
      category: 'employees',
      title: 'Employee Happiness Low',
      message: 'John Smith\'s happiness has dropped to 45%. Consider giving a raise or improving office conditions.',
      timestamp: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
      isRead: true,
      isArchived: false,
      priority: 'normal'
    },
    {
      id: '4',
      type: 'success',
      category: 'research',
      title: 'Research Complete',
      message: 'You have successfully researched "3D Graphics" technology!',
      timestamp: new Date(Date.now() - 45 * 60 * 1000), // 45 minutes ago
      isRead: true,
      isArchived: false,
      priority: 'low'
    },
    {
      id: '5',
      type: 'info',
      category: 'marketing',
      title: 'Campaign Performance Update',
      message: 'Your "Launch Campaign" has reached 50,000 people with 8.5% engagement rate.',
      timestamp: new Date(Date.now() - 60 * 60 * 1000), // 1 hour ago
      isRead: false,
      isArchived: false,
      priority: 'normal'
    },
    {
      id: '6',
      type: 'error',
      category: 'system',
      title: 'Auto-save Failed',
      message: 'Unable to auto-save your progress. Please save manually to prevent data loss.',
      timestamp: new Date(Date.now() - 90 * 60 * 1000), // 1.5 hours ago
      isRead: false,
      isArchived: false,
      priority: 'urgent'
    }
  ]);

  // Combine store notifications with extended ones
  const allNotifications = [
    ...notifications.map(n => ({
      ...n,
      category: 'game' as const,
      isArchived: false,
      priority: 'normal' as const
    })),
    ...extendedNotifications
  ];

  const filteredNotifications = allNotifications.filter(notification => {
    if (showArchived && !notification.isArchived) return false;
    if (!showArchived && notification.isArchived) return false;

    if (filterCategory !== 'all' && notification.category !== filterCategory) return false;
    if (filterType !== 'all' && notification.type !== filterType) return false;

    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      return (
        notification.title.toLowerCase().includes(searchLower) ||
        notification.message.toLowerCase().includes(searchLower)
      );
    }

    return true;
  }).sort((a, b) => {
    switch (sortBy) {
      case 'newest':
        return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
      case 'oldest':
        return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
      case 'priority':
        const priorityOrder = { urgent: 4, high: 3, normal: 2, low: 1 };
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      default:
        return 0;
    }
  });

  const unreadCount = allNotifications.filter(n => !n.isRead && !n.isArchived).length;
  const urgentCount = allNotifications.filter(n => n.priority === 'urgent' && !n.isRead).length;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'success': return CheckCircleIcon;
      case 'warning': return AlertCircleIcon;
      case 'error': return XCircleIcon;
      case 'info': return InfoIcon;
      default: return BellIcon;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'game': return GamepadIcon;
      case 'sales': return DollarSignIcon;
      case 'employees': return UsersIcon;
      case 'research': return BeakerIcon;
      case 'marketing': return TrendingUpIcon;
      case 'system': return InfoIcon;
      default: return BellIcon;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'success': return 'text-green-400 border-green-500';
      case 'warning': return 'text-yellow-400 border-yellow-500';
      case 'error': return 'text-red-400 border-red-500';
      case 'info': return 'text-blue-400 border-blue-500';
      default: return 'text-zinc-400 border-zinc-500';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-600';
      case 'high': return 'bg-orange-600';
      case 'normal': return 'bg-blue-600';
      case 'low': return 'bg-zinc-600';
      default: return 'bg-zinc-600';
    }
  };

  const markAsRead = (notificationId: string) => {
    if (markNotificationRead) {
      markNotificationRead(notificationId);
    }
    setExtendedNotifications(prev =>
      prev.map(n => n.id === notificationId ? { ...n, isRead: true } : n)
    );
  };

  const markAllAsRead = () => {
    filteredNotifications.forEach(n => {
      if (!n.isRead) {
        markAsRead(n.id);
      }
    });
  };

  const archiveNotification = (notificationId: string) => {
    setExtendedNotifications(prev =>
      prev.map(n => n.id === notificationId ? { ...n, isArchived: true } : n)
    );
  };

  const deleteNotification = (notificationId: string) => {
    setExtendedNotifications(prev => prev.filter(n => n.id !== notificationId));
  };

  const bulkAction = (action: 'read' | 'archive' | 'delete') => {
    selectedNotifications.forEach(id => {
      switch (action) {
        case 'read':
          markAsRead(id);
          break;
        case 'archive':
          archiveNotification(id);
          break;
        case 'delete':
          deleteNotification(id);
          break;
      }
    });
    setSelectedNotifications([]);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <BellIcon className="h-6 w-6 text-blue-400" />
            Notification Center
            {unreadCount > 0 && (
              <Badge variant="destructive" className="ml-2">
                {unreadCount}
              </Badge>
            )}
          </h2>
          <p className="text-zinc-400 mt-1">Stay updated with game events and system messages</p>
        </div>
        <div className="flex items-center gap-2">
          {urgentCount > 0 && (
            <Badge variant="destructive" className="bg-red-600">
              {urgentCount} Urgent
            </Badge>
          )}
          <Button onClick={markAllAsRead} disabled={unreadCount === 0}>
            <CheckCircleIcon className="h-4 w-4 mr-2" />
            Mark All Read
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        {[
          { label: 'Total', count: allNotifications.length, color: 'text-zinc-400' },
          { label: 'Unread', count: unreadCount, color: 'text-blue-400' },
          { label: 'Urgent', count: urgentCount, color: 'text-red-400' },
          { label: 'Sales', count: allNotifications.filter(n => n.category === 'sales').length, color: 'text-green-400' },
          { label: 'Employees', count: allNotifications.filter(n => n.category === 'employees').length, color: 'text-purple-400' },
          { label: 'Research', count: allNotifications.filter(n => n.category === 'research').length, color: 'text-yellow-400' }
        ].map(stat => (
          <Card key={stat.label} className="p-3">
            <div className="text-xs text-zinc-400">{stat.label}</div>
            <div className={`text-lg font-bold ${stat.color}`}>{stat.count}</div>
          </Card>
        ))}
      </div>

      {/* Filters and Search */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4 items-center">
            <div className="flex-1 min-w-64">
              <div className="relative">
                <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-zinc-400" />
                <Input
                  placeholder="Search notifications..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="game">Game</SelectItem>
                <SelectItem value="sales">Sales</SelectItem>
                <SelectItem value="employees">Employees</SelectItem>
                <SelectItem value="research">Research</SelectItem>
                <SelectItem value="marketing">Marketing</SelectItem>
                <SelectItem value="system">System</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="success">Success</SelectItem>
                <SelectItem value="info">Info</SelectItem>
                <SelectItem value="warning">Warning</SelectItem>
                <SelectItem value="error">Error</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Sort" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="oldest">Oldest</SelectItem>
                <SelectItem value="priority">Priority</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              onClick={() => setShowArchived(!showArchived)}
            >
              {showArchived ? 'Show Active' : 'Show Archived'}
            </Button>
          </div>

          {selectedNotifications.length > 0 && (
            <div className="mt-4 p-3 bg-zinc-800/50 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm text-zinc-300">
                  {selectedNotifications.length} notifications selected
                </span>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => bulkAction('read')}>
                    Mark Read
                  </Button>
                  <Button size="sm" onClick={() => bulkAction('archive')}>
                    Archive
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => bulkAction('delete')}>
                    Delete
                  </Button>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Notifications List */}
      <div className="space-y-3">
        {filteredNotifications.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <BellIcon className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-zinc-400 mb-2">No Notifications</h3>
              <p className="text-zinc-500">
                {showArchived ? 'No archived notifications found' : 'You\'re all caught up!'}
              </p>
            </CardContent>
          </Card>
        ) : (
          <AnimatePresence>
            {filteredNotifications.map((notification) => {
              const Icon = getNotificationIcon(notification.type);
              const CategoryIcon = getCategoryIcon(notification.category);
              const isSelected = selectedNotifications.includes(notification.id);

              return (
                <motion.div
                  key={notification.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card className={`
                    transition-all cursor-pointer hover:bg-zinc-800/30
                    ${!notification.isRead ? 'border-l-4 border-l-blue-500' : ''}
                    ${isSelected ? 'bg-blue-900/20 border-blue-500' : ''}
                    ${notification.priority === 'urgent' ? 'border-red-500/50' : ''}
                  `}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedNotifications(prev => [...prev, notification.id]);
                            } else {
                              setSelectedNotifications(prev => prev.filter(id => id !== notification.id));
                            }
                          }}
                          className="mt-1"
                        />

                        <div className={`p-2 rounded-lg border ${getTypeColor(notification.type)}`}>
                          <Icon className="h-5 w-5" />
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <h4 className={`font-semibold ${!notification.isRead ? 'text-white' : 'text-zinc-300'}`}>
                                  {notification.title}
                                </h4>
                                <Badge className={`text-xs ${getPriorityColor(notification.priority)}`}>
                                  {notification.priority}
                                </Badge>
                                <div className="flex items-center gap-1 text-xs text-zinc-500">
                                  <CategoryIcon className="h-3 w-3" />
                                  {notification.category}
                                </div>
                              </div>
                              <p className={`text-sm ${!notification.isRead ? 'text-zinc-200' : 'text-zinc-400'}`}>
                                {notification.message}
                              </p>
                              <div className="flex items-center gap-4 mt-2">
                                <span className="text-xs text-zinc-500 flex items-center gap-1">
                                  <CalendarIcon className="h-3 w-3" />
                                  {formatDistanceToNow(notification.timestamp, { addSuffix: true })}
                                </span>
                                {notification.actionable && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={notification.actionable.action}
                                    className="h-6 px-2 text-xs"
                                  >
                                    {notification.actionable.label}
                                  </Button>
                                )}
                              </div>
                            </div>

                            <div className="flex items-center gap-1 ml-4">
                              {!notification.isRead && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => markAsRead(notification.id)}
                                  className="h-6 w-6 p-0"
                                >
                                  <CheckCircleIcon className="h-4 w-4" />
                                </Button>
                              )}

                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => archiveNotification(notification.id)}
                                className="h-6 w-6 p-0"
                              >
                                <ArchiveIcon className="h-4 w-4" />
                              </Button>

                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => deleteNotification(notification.id)}
                                className="h-6 w-6 p-0 text-red-400 hover:text-red-300"
                              >
                                <TrashIcon className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}
