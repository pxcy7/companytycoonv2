'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useGameStore } from '@/store/gameStore';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { TrendingUpIcon, TrendingDownIcon, DollarSignIcon, GamepadIcon } from 'lucide-react';

export function SalesAnalytics() {
  const { games, gameWeek } = useGameStore();
  const [selectedGame, setSelectedGame] = useState<string>('');

  const releasedGames = games.filter(g => g.isReleased);
  const activeGames = releasedGames.filter(g => g.salesData.isActive);

  // Calculate overall stats
  const totalRevenue = releasedGames.reduce((sum, game) => sum + game.salesData.revenue, 0);
  const totalSales = releasedGames.reduce((sum, game) => sum + game.salesData.totalSales, 0);
  const weeklyRevenue = releasedGames.reduce((sum, game) => {
    const lastSale = game.salesData.salesHistory[game.salesData.salesHistory.length - 1];
    return sum + (lastSale ? lastSale.revenue : 0);
  }, 0);
  const weeklySales = releasedGames.reduce((sum, game) => sum + game.salesData.currentWeeklySales, 0);

  // Get current game or default to latest
  const currentGame = selectedGame
    ? releasedGames.find(g => g.id === selectedGame)
    : releasedGames[releasedGames.length - 1];

  useEffect(() => {
    if (releasedGames.length > 0 && !selectedGame) {
      setSelectedGame(releasedGames[releasedGames.length - 1].id);
    }
  }, [releasedGames.length, selectedGame]);

  // Prepare chart data for current game
  const chartData = currentGame?.salesData.salesHistory.map((point, index) => ({
    week: `Week ${point.week}`,
    sales: point.sales,
    revenue: point.revenue,
    cumulativeSales: currentGame.salesData.salesHistory
      .slice(0, index + 1)
      .reduce((sum, p) => sum + p.sales, 0),
  })) || [];

  // Calculate trends
  const getRevenueChange = () => {
    if (!currentGame || currentGame.salesData.salesHistory.length < 2) return 0;
    const history = currentGame.salesData.salesHistory;
    const current = history[history.length - 1]?.revenue || 0;
    const previous = history[history.length - 2]?.revenue || 0;
    return previous > 0 ? ((current - previous) / previous) * 100 : 0;
  };

  const getSalesChange = () => {
    if (!currentGame || currentGame.salesData.salesHistory.length < 2) return 0;
    const history = currentGame.salesData.salesHistory;
    const current = history[history.length - 1]?.sales || 0;
    const previous = history[history.length - 2]?.sales || 0;
    return previous > 0 ? ((current - previous) / previous) * 100 : 0;
  };

  const revenueChange = getRevenueChange();
  const salesChange = getSalesChange();

  if (releasedGames.length === 0) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <GamepadIcon className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-zinc-400 mb-2">No Games Released Yet</h3>
          <p className="text-zinc-500">Release your first game to see sales analytics</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Sales & Analytics</h2>
        <div className="flex items-center gap-2">
          <span className="text-sm text-zinc-400">Week {gameWeek}</span>
          {activeGames.length > 0 && (
            <Badge variant="outline" className="text-green-400 border-green-400">
              {activeGames.length} Active
            </Badge>
          )}
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSignIcon className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">
              ${totalRevenue.toLocaleString()}
            </div>
            <p className="text-xs text-zinc-400">
              +${weeklyRevenue.toLocaleString()} this week
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            <GamepadIcon className="h-4 w-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-400">
              {totalSales.toLocaleString()}
            </div>
            <p className="text-xs text-zinc-400">
              +{weeklySales.toLocaleString()} this week
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Weekly Revenue</CardTitle>
            {revenueChange >= 0 ? (
              <TrendingUpIcon className="h-4 w-4 text-green-400" />
            ) : (
              <TrendingDownIcon className="h-4 w-4 text-red-400" />
            )}
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${weeklyRevenue.toLocaleString()}
            </div>
            <p className={`text-xs ${revenueChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {revenueChange >= 0 ? '+' : ''}{revenueChange.toFixed(1)}% from last week
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Weekly Sales</CardTitle>
            {salesChange >= 0 ? (
              <TrendingUpIcon className="h-4 w-4 text-green-400" />
            ) : (
              <TrendingDownIcon className="h-4 w-4 text-red-400" />
            )}
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {weeklySales.toLocaleString()}
            </div>
            <p className={`text-xs ${salesChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {salesChange >= 0 ? '+' : ''}{salesChange.toFixed(1)}% from last week
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Game Selection */}
      <div className="flex flex-wrap gap-2">
        {releasedGames.map((game) => (
          <button
            key={game.id}
            onClick={() => setSelectedGame(game.id)}
            className={`px-3 py-1 rounded-md text-sm transition-colors ${
              selectedGame === game.id
                ? 'bg-blue-600 text-white'
                : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
            }`}
          >
            {game.name}
            {game.salesData.isActive && (
              <span className="ml-1 inline-block w-2 h-2 bg-green-400 rounded-full" />
            )}
          </button>
        ))}
      </div>

      {/* Current Game Details */}
      {currentGame && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Game Info */}
          <Card>
            <CardHeader>
              <CardTitle>{currentGame.name}</CardTitle>
              <CardDescription>
                {currentGame.topic} • {currentGame.genre} • {currentGame.size}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Quality Score</span>
                  <span>{currentGame.qualityScore}/100</span>
                </div>
                <Progress value={currentGame.qualityScore} />
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <Label>Total Sales</Label>
                  <div className="font-bold text-lg">{currentGame.salesData.totalSales.toLocaleString()}</div>
                </div>
                <div>
                  <Label>Total Revenue</Label>
                  <div className="font-bold text-lg text-green-400">
                    ${currentGame.salesData.revenue.toLocaleString()}
                  </div>
                </div>
                <div>
                  <Label>Sale Price</Label>
                  <div className="font-bold">${currentGame.salePrice}</div>
                </div>
                <div>
                  <Label>Platforms</Label>
                  <div className="flex flex-wrap gap-1">
                    {currentGame.platforms.map(platform => (
                      <Badge key={platform} variant="outline" className="text-xs">
                        {platform}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>

              {currentGame.salesData.isActive && (
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Sales Period Progress</span>
                    <span>{currentGame.salesData.currentWeek}/{currentGame.salesData.salesLength} weeks</span>
                  </div>
                  <Progress
                    value={(currentGame.salesData.currentWeek / currentGame.salesData.salesLength) * 100}
                  />
                </div>
              )}

              <div className="pt-2 border-t">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-zinc-400">Status</span>
                  <Badge
                    variant={currentGame.salesData.isActive ? "default" : "secondary"}
                    className={currentGame.salesData.isActive ? "bg-green-600" : ""}
                  >
                    {currentGame.salesData.isActive ? "Selling" : "Complete"}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Sales Chart */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Sales History</CardTitle>
              <CardDescription>Weekly sales and revenue data</CardDescription>
            </CardHeader>
            <CardContent>
              {chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="week" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '6px'
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="sales"
                      stroke="#60A5FA"
                      strokeWidth={2}
                      name="Weekly Sales"
                    />
                    <Line
                      type="monotone"
                      dataKey="cumulativeSales"
                      stroke="#34D399"
                      strokeWidth={2}
                      name="Total Sales"
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-zinc-400">
                  No sales data available
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* All Games Overview */}
      <Card>
        <CardHeader>
          <CardTitle>All Games Performance</CardTitle>
          <CardDescription>Revenue comparison across all released games</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={releasedGames.map(game => ({
              name: game.name,
              revenue: game.salesData.revenue,
              sales: game.salesData.totalSales,
              quality: game.qualityScore,
            }))}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1F2937',
                  border: '1px solid #374151',
                  borderRadius: '6px'
                }}
              />
              <Bar dataKey="revenue" fill="#34D399" name="Revenue ($)" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <div className="text-xs text-zinc-400 mb-1">{children}</div>;
}
