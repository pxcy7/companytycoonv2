'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import {
  BuildingIcon,
  ArrowUpIcon,
  MonitorIcon,
  ArmchairIcon,
  CoffeeIcon,
  WifiIcon,
  ShieldIcon,
  TrophyIcon,
  ZapIcon,
  UsersIcon,
  StarIcon,
  CheckCircleIcon
} from 'lucide-react';
import { motion } from 'framer-motion';

interface Office {
  id: string;
  name: string;
  description: string;
  capacity: number;
  cost: number;
  monthlyRent: number;
  bonuses: {
    creativity: number;
    productivity: number;
    happiness: number;
    research: number;
  };
  requirements: {
    employees?: number;
    revenue?: number;
    reputation?: number;
  };
  image: string;
  isUnlocked: boolean;
  tier: 'basic' | 'professional' | 'corporate' | 'luxury';
}

interface Equipment {
  id: string;
  name: string;
  description: string;
  cost: number;
  category: 'workstation' | 'furniture' | 'amenity' | 'technology' | 'decoration';
  bonuses: {
    productivity?: number;
    creativity?: number;
    happiness?: number;
    research?: number;
  };
  requirements: {
    officeSize?: 'small' | 'medium' | 'large' | 'enterprise';
    employees?: number;
  };
  icon: any;
  quantity: number;
  maxQuantity: number;
}

const OFFICES: Office[] = [
  {
    id: 'garage',
    name: 'Garage',
    description: 'Humble beginnings in a residential garage. Limited space but rent-free!',
    capacity: 3,
    cost: 0,
    monthlyRent: 0,
    bonuses: { creativity: 5, productivity: 0, happiness: -5, research: 0 },
    requirements: {},
    image: '🏠',
    isUnlocked: true,
    tier: 'basic'
  },
  {
    id: 'small_office',
    name: 'Small Office',
    description: 'A proper office space in a business district. Professional environment.',
    capacity: 8,
    cost: 15000,
    monthlyRent: 2000,
    bonuses: { creativity: 10, productivity: 15, happiness: 10, research: 5 },
    requirements: { employees: 3, revenue: 50000 },
    image: '🏢',
    isUnlocked: false,
    tier: 'professional'
  },
  {
    id: 'medium_office',
    name: 'Medium Office',
    description: 'Spacious office with multiple rooms and meeting areas.',
    capacity: 20,
    cost: 50000,
    monthlyRent: 8000,
    bonuses: { creativity: 20, productivity: 25, happiness: 20, research: 15 },
    requirements: { employees: 8, revenue: 200000, reputation: 50 },
    image: '🏛️',
    isUnlocked: false,
    tier: 'corporate'
  },
  {
    id: 'large_office',
    name: 'Corporate Headquarters',
    description: 'Premium office space with top-tier amenities and prestige location.',
    capacity: 50,
    cost: 200000,
    monthlyRent: 25000,
    bonuses: { creativity: 35, productivity: 40, happiness: 35, research: 30 },
    requirements: { employees: 20, revenue: 1000000, reputation: 80 },
    image: '🏗️',
    isUnlocked: false,
    tier: 'luxury'
  }
];

const EQUIPMENT: Equipment[] = [
  // Workstations
  {
    id: 'basic_computer',
    name: 'Basic Computer',
    description: 'Standard desktop computer for development work',
    cost: 1200,
    category: 'workstation',
    bonuses: { productivity: 5 },
    requirements: {},
    icon: MonitorIcon,
    quantity: 0,
    maxQuantity: 20
  },
  {
    id: 'high_end_workstation',
    name: 'High-End Workstation',
    description: 'Powerful computer with premium specs for demanding tasks',
    cost: 3500,
    category: 'workstation',
    bonuses: { productivity: 15, creativity: 5 },
    requirements: { officeSize: 'medium' },
    icon: MonitorIcon,
    quantity: 0,
    maxQuantity: 15
  },

  // Furniture
  {
    id: 'ergonomic_chair',
    name: 'Ergonomic Chair',
    description: 'Comfortable chair that reduces fatigue and improves focus',
    cost: 400,
    category: 'furniture',
    bonuses: { happiness: 8, productivity: 3 },
    requirements: {},
    icon: ArmchairIcon,
    quantity: 0,
    maxQuantity: 30
  },
  {
    id: 'standing_desk',
    name: 'Standing Desk',
    description: 'Adjustable desk that promotes health and creativity',
    cost: 800,
    category: 'furniture',
    bonuses: { creativity: 10, happiness: 5 },
    requirements: { officeSize: 'medium' },
    icon: ArrowUpIcon,
    quantity: 0,
    maxQuantity: 20
  },

  // Amenities
  {
    id: 'coffee_machine',
    name: 'Professional Coffee Machine',
    description: 'High-quality coffee to keep the team energized',
    cost: 2000,
    category: 'amenity',
    bonuses: { happiness: 15, productivity: 8 },
    requirements: { employees: 5 },
    icon: CoffeeIcon,
    quantity: 0,
    maxQuantity: 3
  },
  {
    id: 'game_room',
    name: 'Game Room',
    description: 'Recreation area with games and entertainment for stress relief',
    cost: 8000,
    category: 'amenity',
    bonuses: { happiness: 25, creativity: 15 },
    requirements: { officeSize: 'large', employees: 10 },
    icon: TrophyIcon,
    quantity: 0,
    maxQuantity: 1
  },

  // Technology
  {
    id: 'high_speed_internet',
    name: 'High-Speed Internet',
    description: 'Ultra-fast internet connection for seamless development',
    cost: 5000,
    category: 'technology',
    bonuses: { productivity: 20, research: 10 },
    requirements: { officeSize: 'medium' },
    icon: WifiIcon,
    quantity: 0,
    maxQuantity: 1
  },
  {
    id: 'server_room',
    name: 'Server Room',
    description: 'Dedicated servers for testing and development',
    cost: 15000,
    category: 'technology',
    bonuses: { research: 25, productivity: 15 },
    requirements: { officeSize: 'large', employees: 15 },
    icon: ShieldIcon,
    quantity: 0,
    maxQuantity: 1
  }
];

interface OfficeManagementProps {
  company: any;
  onSpendMoney: (amount: number) => boolean;
  employees: any[];
}

export function OfficeManagement({ company, onSpendMoney, employees }: OfficeManagementProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [currentOffice, setCurrentOffice] = useState(OFFICES[0]);
  const [equipment, setEquipment] = useState(EQUIPMENT);

  const canUpgradeToOffice = (office: Office) => {
    if (office.isUnlocked) return false;

    const { employees: reqEmployees = 0, revenue = 0, reputation = 0 } = office.requirements;

    return (
      employees.length >= reqEmployees &&
      company.money >= office.cost &&
      (revenue === 0 || true) && // TODO: Add revenue tracking
      company.reputation >= reputation
    );
  };

  const canBuyEquipment = (item: Equipment) => {
    if (item.quantity >= item.maxQuantity) return false;
    if (company.money < item.cost) return false;

    const { officeSize, employees: reqEmployees = 0 } = item.requirements;

    if (officeSize) {
      const officeTypes = { small: 1, medium: 2, large: 3, enterprise: 4 };
      const currentOfficeType = currentOffice.tier === 'basic' ? 0 :
                               currentOffice.tier === 'professional' ? 1 :
                               currentOffice.tier === 'corporate' ? 2 : 3;

      if (currentOfficeType < officeTypes[officeSize]) return false;
    }

    return employees.length >= reqEmployees;
  };

  const upgradeOffice = (office: Office) => {
    if (onSpendMoney(office.cost)) {
      setCurrentOffice(office);
      const updatedOffices = OFFICES.map(o =>
        o.id === office.id ? { ...o, isUnlocked: true } : o
      );
      // TODO: Update global state with new office
    }
  };

  const buyEquipment = (item: Equipment) => {
    if (onSpendMoney(item.cost)) {
      setEquipment(prev => prev.map(eq =>
        eq.id === item.id ? { ...eq, quantity: eq.quantity + 1 } : eq
      ));
    }
  };

  const getTotalBonuses = () => {
    const officeBonuses = currentOffice.bonuses;
    const equipmentBonuses = equipment.reduce((total, item) => {
      if (item.quantity > 0) {
        Object.entries(item.bonuses).forEach(([key, value]) => {
          total[key] = (total[key] || 0) + (value * item.quantity);
        });
      }
      return total;
    }, {} as any);

    return {
      creativity: (officeBonuses.creativity || 0) + (equipmentBonuses.creativity || 0),
      productivity: (officeBonuses.productivity || 0) + (equipmentBonuses.productivity || 0),
      happiness: (officeBonuses.happiness || 0) + (equipmentBonuses.happiness || 0),
      research: (officeBonuses.research || 0) + (equipmentBonuses.research || 0)
    };
  };

  const totalBonuses = getTotalBonuses();

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <BuildingIcon className="h-6 w-6 text-blue-400" />
            Office Management
          </h2>
          <p className="text-zinc-400 mt-1">Upgrade your workspace to boost team performance</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-zinc-400">Monthly Rent</div>
          <div className="text-xl font-bold text-red-400">${currentOffice.monthlyRent.toLocaleString()}</div>
        </div>
      </div>

      {/* Current Office Overview */}
      <Card className="border-blue-500/30 bg-blue-900/10">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <span className="text-2xl">{currentOffice.image}</span>
            <div>
              <div className="text-xl">{currentOffice.name}</div>
              <Badge className={`
                ${currentOffice.tier === 'basic' ? 'bg-gray-600' : ''}
                ${currentOffice.tier === 'professional' ? 'bg-blue-600' : ''}
                ${currentOffice.tier === 'corporate' ? 'bg-purple-600' : ''}
                ${currentOffice.tier === 'luxury' ? 'bg-yellow-600' : ''}
              `}>
                {currentOffice.tier}
              </Badge>
            </div>
          </CardTitle>
          <CardDescription>{currentOffice.description}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <div className="text-sm text-zinc-400">Capacity</div>
              <div className="text-lg font-bold">{employees.length}/{currentOffice.capacity}</div>
              <Progress value={(employees.length / currentOffice.capacity) * 100} className="mt-1 h-2" />
            </div>
            <div>
              <div className="text-sm text-zinc-400">Creativity Bonus</div>
              <div className="text-lg font-bold text-purple-400">+{totalBonuses.creativity}%</div>
            </div>
            <div>
              <div className="text-sm text-zinc-400">Productivity Bonus</div>
              <div className="text-lg font-bold text-green-400">+{totalBonuses.productivity}%</div>
            </div>
            <div>
              <div className="text-sm text-zinc-400">Happiness Bonus</div>
              <div className="text-lg font-bold text-yellow-400">+{totalBonuses.happiness}%</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="upgrades">Office Upgrades</TabsTrigger>
          <TabsTrigger value="equipment">Equipment</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Office Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Office Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Space Utilization:</span>
                    <span className={employees.length > currentOffice.capacity * 0.8 ? 'text-red-400' : 'text-green-400'}>
                      {Math.round((employees.length / currentOffice.capacity) * 100)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Equipment Items:</span>
                    <span className="text-blue-400">{equipment.reduce((sum, eq) => sum + eq.quantity, 0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Monthly Overhead:</span>
                    <span className="text-red-400">${currentOffice.monthlyRent.toLocaleString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Productivity Bonuses</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span>Creativity:</span>
                    <div className="flex items-center gap-2">
                      <Progress value={Math.min(totalBonuses.creativity, 100)} className="w-20 h-2" />
                      <span className="text-purple-400">+{totalBonuses.creativity}%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Productivity:</span>
                    <div className="flex items-center gap-2">
                      <Progress value={Math.min(totalBonuses.productivity, 100)} className="w-20 h-2" />
                      <span className="text-green-400">+{totalBonuses.productivity}%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Happiness:</span>
                    <div className="flex items-center gap-2">
                      <Progress value={Math.min(totalBonuses.happiness, 100)} className="w-20 h-2" />
                      <span className="text-yellow-400">+{totalBonuses.happiness}%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Research:</span>
                    <div className="flex items-center gap-2">
                      <Progress value={Math.min(totalBonuses.research, 100)} className="w-20 h-2" />
                      <span className="text-blue-400">+{totalBonuses.research}%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="upgrades" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {OFFICES.map((office) => {
              const canUpgrade = canUpgradeToOffice(office);
              const isCurrent = office.id === currentOffice.id;

              return (
                <motion.div
                  key={office.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className={`
                    ${isCurrent ? 'border-blue-500 bg-blue-900/20' : ''}
                    ${canUpgrade ? 'border-green-500/50' : ''}
                    ${!office.isUnlocked && !canUpgrade ? 'opacity-60' : ''}
                  `}>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-3">
                        <span className="text-2xl">{office.image}</span>
                        <div>
                          <div className="flex items-center gap-2">
                            {office.name}
                            {isCurrent && <CheckCircleIcon className="h-5 w-5 text-blue-400" />}
                          </div>
                          <Badge className={`
                            ${office.tier === 'basic' ? 'bg-gray-600' : ''}
                            ${office.tier === 'professional' ? 'bg-blue-600' : ''}
                            ${office.tier === 'corporate' ? 'bg-purple-600' : ''}
                            ${office.tier === 'luxury' ? 'bg-yellow-600' : ''}
                          `}>
                            {office.tier}
                          </Badge>
                        </div>
                      </CardTitle>
                      <CardDescription>{office.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <span className="text-zinc-400">Capacity:</span>
                          <div className="font-bold">{office.capacity} employees</div>
                        </div>
                        <div>
                          <span className="text-zinc-400">Monthly Rent:</span>
                          <div className="font-bold text-red-400">${office.monthlyRent.toLocaleString()}</div>
                        </div>
                      </div>

                      <div>
                        <div className="text-sm text-zinc-400 mb-2">Bonuses:</div>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div>Creativity: +{office.bonuses.creativity}%</div>
                          <div>Productivity: +{office.bonuses.productivity}%</div>
                          <div>Happiness: +{office.bonuses.happiness}%</div>
                          <div>Research: +{office.bonuses.research}%</div>
                        </div>
                      </div>

                      {office.requirements && Object.keys(office.requirements).length > 0 && (
                        <div>
                          <div className="text-sm text-zinc-400 mb-2">Requirements:</div>
                          <div className="space-y-1 text-xs">
                            {office.requirements.employees && (
                              <div className={employees.length >= office.requirements.employees ? 'text-green-400' : 'text-red-400'}>
                                Employees: {office.requirements.employees}
                              </div>
                            )}
                            {office.requirements.reputation && (
                              <div className={company.reputation >= office.requirements.reputation ? 'text-green-400' : 'text-red-400'}>
                                Reputation: {office.requirements.reputation}
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      <Separator />

                      <div className="flex justify-between items-center">
                        <span className="text-sm font-semibold">Cost:</span>
                        <span className={`font-bold ${company.money >= office.cost ? 'text-green-400' : 'text-red-400'}`}>
                          ${office.cost.toLocaleString()}
                        </span>
                      </div>

                      <Button
                        onClick={() => upgradeOffice(office)}
                        disabled={!canUpgrade || isCurrent}
                        className="w-full"
                      >
                        {isCurrent ? 'Current Office' :
                         office.isUnlocked ? 'Move Here' :
                         canUpgrade ? 'Upgrade' : 'Requirements Not Met'}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="equipment" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {equipment.map((item) => {
              const canBuy = canBuyEquipment(item);
              const Icon = item.icon;

              return (
                <Card key={item.id} className={`${item.quantity > 0 ? 'border-green-500/30 bg-green-900/10' : ''}`}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Icon className="h-5 w-5 text-blue-400" />
                      {item.name}
                      {item.quantity > 0 && (
                        <Badge variant="outline" className="text-green-400 border-green-400">
                          {item.quantity}
                        </Badge>
                      )}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-zinc-400">{item.description}</p>

                    <div className="text-xs">
                      <div className="text-zinc-400 mb-1">Bonuses:</div>
                      {Object.entries(item.bonuses).map(([key, value]) => (
                        <div key={key} className="flex justify-between">
                          <span className="capitalize">{key}:</span>
                          <span className="text-green-400">+{value}%</span>
                        </div>
                      ))}
                    </div>

                    <Separator />

                    <div className="flex justify-between items-center">
                      <span className="text-sm">Cost:</span>
                      <span className={`font-bold ${company.money >= item.cost ? 'text-green-400' : 'text-red-400'}`}>
                        ${item.cost.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex justify-between items-center text-xs">
                      <span>Quantity:</span>
                      <span>{item.quantity}/{item.maxQuantity}</span>
                    </div>

                    <Button
                      onClick={() => buyEquipment(item)}
                      disabled={!canBuy}
                      className="w-full"
                      size="sm"
                    >
                      {item.quantity >= item.maxQuantity ? 'Max Reached' :
                       !canBuy ? 'Cannot Buy' : 'Purchase'}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
