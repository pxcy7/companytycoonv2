'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useGameStore } from '@/store/gameStore';
import type { GameStats, GameSize } from '@/types/game';
import { Slider } from '@/components/ui/slider';

export function GameDevelopment() {
  const {
    createGame,
    currentGame,
    updateGame,
    releaseGame,
    company,
    research,
    calculateGameQuality,
    spendMoney
  } = useGameStore();

  const [gameName, setGameName] = useState('');
  const [selectedTopic, setSelectedTopic] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('');
  const [selectedSize, setSelectedSize] = useState<GameSize>('small');
  const [selectedEngine, setSelectedEngine] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [gameStats, setGameStats] = useState<GameStats>({
    design: 0,
    gameplay: 0,
    audio: 0,
    technical: 0
  });
  const [totalPoints, setTotalPoints] = useState(100);
  const [salePrice, setSalePrice] = useState(19.99);
  const [marketingBudget, setMarketingBudget] = useState(0);

  const unlockedTopics = research.topics.filter(t => t.isUnlocked);
  const unlockedGenres = research.genres.filter(g => g.isUnlocked);
  const unlockedPlatforms = research.platforms.filter(p => p.isUnlocked);
  const unlockedEngines = research.engines.filter(e => e.isUnlocked);

  // Calculate costs and stats based on game size
  const getSizeMultiplier = (size: GameSize) => {
    switch (size) {
      case 'small': return { cost: 1, points: 100, time: 4 };
      case 'medium': return { cost: 3, points: 200, time: 8 };
      case 'large': return { cost: 8, points: 400, time: 16 };
      case 'aaa': return { cost: 20, points: 800, time: 32 };
    }
  };

  const sizeMultiplier = getSizeMultiplier(selectedSize);
  const baseCost = 5000 * sizeMultiplier.cost;
  const engineCost = unlockedEngines.find(e => e.id === selectedEngine)?.cost || 0;
  const platformCosts = selectedPlatforms.reduce((acc, platformId) => {
    const platform = unlockedPlatforms.find(p => p.id === platformId);
    return acc + (platform?.developmentCost || 0);
  }, 0);
  const totalCost = baseCost + engineCost + platformCosts + marketingBudget;

  // Update available points when size changes
  useEffect(() => {
    const newTotal = sizeMultiplier.points;
    setTotalPoints(newTotal);

    // Reset stats if they exceed new total
    const currentTotal = Object.values(gameStats).reduce((sum, val) => sum + val, 0);
    if (currentTotal > newTotal) {
      setGameStats({ design: 0, gameplay: 0, audio: 0, technical: 0 });
    }
  }, [selectedSize]);

  // Set defaults on mount
  useEffect(() => {
    if (unlockedTopics.length > 0 && !selectedTopic) {
      setSelectedTopic(unlockedTopics[0].id);
    }
    if (unlockedGenres.length > 0 && !selectedGenre) {
      setSelectedGenre(unlockedGenres[0].id);
    }
    if (unlockedEngines.length > 0 && !selectedEngine) {
      setSelectedEngine(unlockedEngines[0].id);
    }
    if (unlockedPlatforms.length > 0 && selectedPlatforms.length === 0) {
      setSelectedPlatforms([unlockedPlatforms[0].id]);
    }
  }, [unlockedTopics, unlockedGenres, unlockedEngines, unlockedPlatforms]);

  const handleStatChange = (stat: keyof GameStats, value: number[]) => {
    const newValue = value[0];
    const currentTotal = Object.values(gameStats).reduce((sum, val) => sum + val, 0);
    const remainingPoints = totalPoints - currentTotal + gameStats[stat];

    if (newValue <= remainingPoints) {
      setGameStats(prev => ({ ...prev, [stat]: newValue }));
    }
  };

  const usedPoints = Object.values(gameStats).reduce((sum, val) => sum + val, 0);
  const remainingPoints = totalPoints - usedPoints;

  const canAfford = company.money >= totalCost;
  const canCreateGame = gameName && selectedTopic && selectedGenre && selectedEngine &&
                       selectedPlatforms.length > 0 && canAfford;

  const predictedQuality = selectedGenre && selectedEngine ?
    calculateGameQuality(gameStats, selectedGenre, selectedEngine) : 0;

  const handleCreateGame = () => {
    if (!canCreateGame) return;

    if (spendMoney(totalCost)) {
      createGame({
        name: gameName,
        topic: selectedTopic,
        genre: selectedGenre,
        size: selectedSize,
        stats: gameStats,
        engine: selectedEngine,
        platforms: selectedPlatforms,
        developmentCost: totalCost,
        marketingBudget,
        salePrice,
      });

      // Reset form
      setGameName('');
      setGameStats({ design: 0, gameplay: 0, audio: 0, technical: 0 });
      setMarketingBudget(0);
    }
  };

  const handleReleaseGame = () => {
    if (currentGame?.isInDevelopment) {
      releaseGame(currentGame.id);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Game Development</h2>
        {currentGame?.isInDevelopment && (
          <Button onClick={handleReleaseGame} className="bg-green-600 hover:bg-green-700">
            Release {currentGame.name}
          </Button>
        )}
      </div>

      {currentGame?.isInDevelopment ? (
        <Card>
          <CardHeader>
            <CardTitle>Current Project: {currentGame.name}</CardTitle>
            <CardDescription>
              {currentGame.topic} • {currentGame.genre} • {currentGame.size}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <Label>Design</Label>
                <div className="text-2xl font-bold text-blue-400">{currentGame.stats.design}</div>
              </div>
              <div>
                <Label>Gameplay</Label>
                <div className="text-2xl font-bold text-green-400">{currentGame.stats.gameplay}</div>
              </div>
              <div>
                <Label>Audio</Label>
                <div className="text-2xl font-bold text-yellow-400">{currentGame.stats.audio}</div>
              </div>
              <div>
                <Label>Technical</Label>
                <div className="text-2xl font-bold text-red-400">{currentGame.stats.technical}</div>
              </div>
            </div>
            <div className="mt-4">
              <Label>Predicted Quality Score</Label>
              <div className="flex items-center gap-2 mt-1">
                <Progress value={currentGame.qualityScore || predictedQuality} className="flex-1" />
                <span className="text-lg font-bold">{Math.round(currentGame.qualityScore || predictedQuality)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Game Setup */}
          <Card>
            <CardHeader>
              <CardTitle>New Game Project</CardTitle>
              <CardDescription>Start developing your next hit game</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="gameName">Game Name</Label>
                <Input
                  id="gameName"
                  value={gameName}
                  onChange={(e) => setGameName(e.target.value)}
                  placeholder="Enter game name"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Topic</Label>
                  <Select value={selectedTopic} onValueChange={setSelectedTopic}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select topic" />
                    </SelectTrigger>
                    <SelectContent>
                      {unlockedTopics.map((topic) => (
                        <SelectItem key={topic.id} value={topic.id}>
                          {topic.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Genre</Label>
                  <Select value={selectedGenre} onValueChange={setSelectedGenre}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select genre" />
                    </SelectTrigger>
                    <SelectContent>
                      {unlockedGenres.map((genre) => (
                        <SelectItem key={genre.id} value={genre.id}>
                          {genre.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>Game Size</Label>
                <Select value={selectedSize} onValueChange={(value: GameSize) => setSelectedSize(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Small Game (4 weeks)</SelectItem>
                    <SelectItem value="medium">Medium Game (8 weeks)</SelectItem>
                    <SelectItem value="large">Large Game (16 weeks)</SelectItem>
                    <SelectItem value="aaa">AAA Game (32 weeks)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Engine</Label>
                <Select value={selectedEngine} onValueChange={setSelectedEngine}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select engine" />
                  </SelectTrigger>
                  <SelectContent>
                    {unlockedEngines.map((engine) => (
                      <SelectItem key={engine.id} value={engine.id}>
                        {engine.name} {engine.cost > 0 && `($${engine.cost.toLocaleString()})`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Sale Price</Label>
                <Input
                  type="number"
                  value={salePrice}
                  onChange={(e) => setSalePrice(Number(e.target.value))}
                  min="0"
                  step="0.01"
                />
              </div>

              <div>
                <Label>Marketing Budget</Label>
                <Input
                  type="number"
                  value={marketingBudget}
                  onChange={(e) => setMarketingBudget(Number(e.target.value))}
                  min="0"
                />
              </div>
            </CardContent>
          </Card>

          {/* Skill Allocation */}
          <Card>
            <CardHeader>
              <CardTitle>Skill Allocation</CardTitle>
              <CardDescription>
                Distribute {totalPoints} skill points across different areas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-lg font-semibold">
                  Points Remaining: <span className="text-blue-400">{remainingPoints}</span>
                </div>
                <Progress value={(usedPoints / totalPoints) * 100} className="mt-2" />
              </div>

              {(['design', 'gameplay', 'audio', 'technical'] as const).map((stat) => (
                <div key={stat} className="space-y-2">
                  <div className="flex justify-between">
                    <Label className="capitalize">{stat}</Label>
                    <span className="font-bold">{gameStats[stat]}</span>
                  </div>
                  <Slider
                    value={[gameStats[stat]]}
                    onValueChange={(value) => handleStatChange(stat, value)}
                    max={Math.min(100, remainingPoints + gameStats[stat])}
                    step={1}
                    className="w-full"
                  />
                </div>
              ))}

              <div className="pt-4">
                <Label>Predicted Quality Score</Label>
                <div className="flex items-center gap-2 mt-1">
                  <Progress value={predictedQuality} className="flex-1" />
                  <span className="text-lg font-bold">{Math.round(predictedQuality)}</span>
                </div>
              </div>

              <div className="pt-4 border-t">
                <div className="flex justify-between text-sm mb-2">
                  <span>Total Cost:</span>
                  <span className={canAfford ? 'text-green-400' : 'text-red-400'}>
                    ${totalCost.toLocaleString()}
                  </span>
                </div>
                <Button
                  onClick={handleCreateGame}
                  disabled={!canCreateGame}
                  className="w-full"
                >
                  Start Development
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
