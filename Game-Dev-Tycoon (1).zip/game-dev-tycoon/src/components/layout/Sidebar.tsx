'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useGameStore } from '@/store/gameStore';
import {
  GamepadIcon,
  TrendingUpIcon,
  BeakerIcon,
  UsersIcon,
  BuildingIcon,
  SettingsIcon,
  PlayIcon,
  PauseIcon,
  BellIcon,
  MegaphoneIcon,
  NewspaperIcon,
  TrophyIcon,
  TargetIcon
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  const {
    company,
    gameWeek,
    isGamePaused,
    pauseGame,
    resumeGame,
    notifications
  } = useGameStore();

  const unreadNotifications = notifications.filter(n => !n.isRead).length;

  const menuItems = [
    { id: 'develop', label: 'Develop Game', icon: GamepadIcon },
    { id: 'sales', label: 'Sales & Analytics', icon: TrendingUpIcon },
    { id: 'research', label: 'Research', icon: BeakerIcon },
    { id: 'employees', label: 'Employees', icon: UsersIcon },
    { id: 'marketing', label: 'Marketing', icon: MegaphoneIcon },
    { id: 'office', label: 'Office', icon: BuildingIcon },
    { id: 'reviews', label: 'Reviews', icon: NewspaperIcon },
    { id: 'achievements', label: 'Achievements', icon: TrophyIcon },
    { id: 'competitors', label: 'Competitors', icon: TargetIcon },
    { id: 'settings', label: 'Settings', icon: SettingsIcon },
  ];

  return (
    <div className="w-64 bg-zinc-900 border-r border-zinc-800 flex flex-col h-screen">
      {/* Header */}
      <div className="p-4 border-b border-zinc-800">
        <h1 className="text-xl font-bold text-white">{company.name}</h1>
        <div className="flex items-center justify-between mt-2">
          <div className="text-sm text-zinc-400">Week {gameWeek}</div>
          <Button
            size="sm"
            variant={isGamePaused ? "default" : "secondary"}
            onClick={isGamePaused ? resumeGame : pauseGame}
            className="h-6 px-2"
          >
            {isGamePaused ? <PlayIcon className="h-3 w-3" /> : <PauseIcon className="h-3 w-3" />}
          </Button>
        </div>
      </div>

      {/* Company Stats */}
      <div className="p-4 border-b border-zinc-800">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-zinc-400">Money:</span>
            <span className="text-green-400 font-mono">${company.money.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-zinc-400">Reputation:</span>
            <span className="text-blue-400">{company.reputation}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-zinc-400">Research Points:</span>
            <span className="text-purple-400">{company.researchPoints}</span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            const hasNotification = item.id === 'settings' && unreadNotifications > 0;

            return (
              <li key={item.id}>
                <Button
                  variant={isActive ? "secondary" : "ghost"}
                  className={`w-full justify-start text-left ${
                    isActive
                      ? 'bg-zinc-800 text-white'
                      : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
                  }`}
                  onClick={() => onTabChange(item.id)}
                  data-tab={item.id}
                >
                  <Icon className="h-4 w-4 mr-3" />
                  {item.label}
                  {hasNotification && (
                    <Badge variant="destructive" className="ml-auto h-4 w-4 p-0 text-xs">
                      {unreadNotifications}
                    </Badge>
                  )}
                </Button>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Notifications Button */}
      <div className="p-4 border-t border-zinc-800">
        <Button
          variant="outline"
          className="w-full justify-start"
          onClick={() => onTabChange('notifications')}
        >
          <BellIcon className="h-4 w-4 mr-3" />
          Notifications
          {unreadNotifications > 0 && (
            <Badge variant="destructive" className="ml-auto">
              {unreadNotifications}
            </Badge>
          )}
        </Button>
      </div>
    </div>
  );
}
