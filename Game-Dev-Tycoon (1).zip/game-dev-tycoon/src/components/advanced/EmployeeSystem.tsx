'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import {
  UsersIcon,
  PlusIcon,
  StarIcon,
  BrainIcon,
  TrendingUpIcon,
  DollarSignIcon,
  CalendarIcon,
  AwardIcon,
  UserCheckIcon,
  UserXIcon,
  GraduationCapIcon,
  MessageSquareIcon
} from 'lucide-react';
import { type Employee, type EmployeeSpecialization, type LegendaryDeveloper, LEGENDARY_DEVELOPERS, EMPLOYEE_TEMPLATES } from '@/types/employee';
import { motion } from 'framer-motion';

interface EmployeeSystemProps {
  currentWeek: number;
  currentYear: number;
  companyMoney: number;
  onHireEmployee: (employee: Employee, cost: number) => void;
  onFireEmployee: (employeeId: string) => void;
  employees: Employee[];
}

export function EmployeeSystem({
  currentWeek,
  currentYear,
  companyMoney,
  onHireEmployee,
  onFireEmployee,
  employees
}: EmployeeSystemProps) {
  const [activeTab, setActiveTab] = useState('team');
  const [availableEmployees, setAvailableEmployees] = useState<Employee[]>([]);
  const [availableLegends, setAvailableLegends] = useState<LegendaryDeveloper[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [isHireDialogOpen, setIsHireDialogOpen] = useState(false);
  const [searchFilter, setSearchFilter] = useState('');
  const [specializationFilter, setSpecializationFilter] = useState<string>('all');

  // Generate available employees
  useEffect(() => {
    const generateEmployee = (template: keyof typeof EMPLOYEE_TEMPLATES): Employee => {
      const templateData = EMPLOYEE_TEMPLATES[template];
      const id = Math.random().toString(36).substr(2, 9);
      const name = templateData.namePool[Math.floor(Math.random() * templateData.namePool.length)];

      // Generate skills within template ranges
      const skills = Object.keys(templateData.skillRanges).reduce((acc, skill) => {
        const [min, max] = templateData.skillRanges[skill as keyof typeof templateData.skillRanges];
        acc[skill as keyof typeof acc] = Math.floor(Math.random() * (max - min + 1)) + min;
        return acc;
      }, {} as any);

      // Select specialization based on weights
      const specs = Object.keys(templateData.specializationWeights);
      const totalWeight = Object.values(templateData.specializationWeights).reduce((a, b) => a + b, 0);
      let random = Math.random() * totalWeight;
      let selectedSpec = specs[0] as EmployeeSpecialization;

      for (const spec of specs) {
        random -= templateData.specializationWeights[spec as EmployeeSpecialization];
        if (random <= 0) {
          selectedSpec = spec as EmployeeSpecialization;
          break;
        }
      }

      const [minSalary, maxSalary] = templateData.salaryRange;
      const salary = Math.floor(Math.random() * (maxSalary - minSalary + 1)) + minSalary;

      return {
        id,
        name: name + ' ' + ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones'][Math.floor(Math.random() * 5)],
        age: Math.floor(Math.random() * 30) + 22,
        gender: Math.random() > 0.3 ? 'male' : 'female',
        avatar: `/avatars/employee_${Math.floor(Math.random() * 20) + 1}.png`,
        level: template === 'junior' ? 1 : template === 'senior' ? Math.floor(Math.random() * 3) + 3 : Math.floor(Math.random() * 3) + 6,
        experience: 0,
        skills,
        personality: {
          creativity: Math.floor(Math.random() * 100),
          focus: Math.floor(Math.random() * 100),
          teamwork: Math.floor(Math.random() * 100),
          ambition: Math.floor(Math.random() * 100),
          stress: Math.floor(Math.random() * 30),
          happiness: Math.floor(Math.random() * 40) + 60
        },
        needs: {
          salary,
          equipment: [],
          officeType: template === 'junior' ? 'basic' : template === 'senior' ? 'advanced' : 'premium',
          teamSize: 'medium'
        },
        primarySpecialization: selectedSpec,
        favoriteGenres: ['action', 'strategy'].slice(0, Math.floor(Math.random() * 3) + 1),
        favoriteFeatures: [],
        isHired: false,
        hiringCost: salary * 3,
        workEfficiency: 100,
        isLegendary: false,
        careerHistory: [],
        contractLength: 12,
        loyaltyLevel: 70,
        lastRaise: 0,
        skillGrowthRate: Math.random() * 0.5 + 0.5,
        potentialSkills: skills,
        trainingProgress: {
          progress: 0,
          weeksRemaining: 0,
          cost: 0
        },
        quotes: [
          "Let's make something amazing!",
          "I love working on games!",
          "This project is going to be great!"
        ],
        mood: 'content'
      };
    };

    // Generate pool of available employees
    const newEmployees: Employee[] = [];
    for (let i = 0; i < 8; i++) {
      if (Math.random() < 0.6) newEmployees.push(generateEmployee('junior'));
      if (Math.random() < 0.3) newEmployees.push(generateEmployee('senior'));
      if (Math.random() < 0.1 && currentYear >= 1990) newEmployees.push(generateEmployee('expert'));
    }

    setAvailableEmployees(newEmployees);

    // Filter available legendary developers by year
    const legends = LEGENDARY_DEVELOPERS.filter(legend =>
      currentYear >= legend.availableFromYear &&
      !employees.some(emp => emp.name === legend.gameName)
    );
    setAvailableLegends(legends);
  }, [currentWeek, currentYear, employees]);

  const filteredEmployees = availableEmployees.filter(emp => {
    const matchesSearch = emp.name.toLowerCase().includes(searchFilter.toLowerCase());
    const matchesSpec = specializationFilter === 'all' || emp.primarySpecialization === specializationFilter;
    return matchesSearch && matchesSpec;
  });

  const getSpecializationColor = (spec: EmployeeSpecialization) => {
    const colors = {
      programmer: 'bg-blue-500',
      game_designer: 'bg-purple-500',
      graphic_artist: 'bg-pink-500',
      sound_engineer: 'bg-green-500',
      researcher: 'bg-yellow-500',
      marketer: 'bg-red-500',
      qa_tester: 'bg-orange-500',
      producer: 'bg-indigo-500',
      level_designer: 'bg-cyan-500',
      ui_designer: 'bg-emerald-500',
      narrative_designer: 'bg-rose-500',
      technical_artist: 'bg-violet-500',
      data_analyst: 'bg-amber-500'
    };
    return colors[spec] || 'bg-gray-500';
  };

  const getSkillColor = (value: number) => {
    if (value >= 90) return 'text-purple-400';
    if (value >= 75) return 'text-blue-400';
    if (value >= 60) return 'text-green-400';
    if (value >= 40) return 'text-yellow-400';
    return 'text-red-400';
  };

  const handleHireEmployee = (employee: Employee) => {
    if (companyMoney >= employee.hiringCost) {
      onHireEmployee(employee, employee.hiringCost);
      setAvailableEmployees(prev => prev.filter(emp => emp.id !== employee.id));
      setIsHireDialogOpen(false);
      setSelectedEmployee(null);
    }
  };

  const handleHireLegend = (legend: LegendaryDeveloper) => {
    if (companyMoney >= legend.hiringCost) {
      const legendEmployee: Employee = {
        id: legend.id,
        name: legend.gameName,
        age: 35,
        gender: 'male',
        avatar: legend.avatar,
        level: 10,
        experience: 10000,
        skills: legend.skills,
        personality: {
          creativity: 95,
          focus: 90,
          teamwork: 85,
          ambition: 95,
          stress: 20,
          happiness: 90
        },
        needs: {
          salary: legend.hiringCost / 10,
          equipment: ['premium_computer', 'ergonomic_chair', 'high_end_monitor'],
          officeType: 'executive',
          teamSize: 'large'
        },
        primarySpecialization: 'game_designer',
        favoriteGenres: [],
        favoriteFeatures: [],
        isHired: false,
        hiringCost: legend.hiringCost,
        workEfficiency: 150,
        isLegendary: true,
        legendaryBonus: legend.legendaryBonus,
        careerHistory: [],
        contractLength: 24,
        loyaltyLevel: 95,
        lastRaise: 0,
        skillGrowthRate: 0.1,
        potentialSkills: legend.skills,
        trainingProgress: {
          progress: 0,
          weeksRemaining: 0,
          cost: 0
        },
        quotes: legend.quotes,
        mood: 'inspired'
      };

      onHireEmployee(legendEmployee, legend.hiringCost);
      setAvailableLegends(prev => prev.filter(l => l.id !== legend.id));
      setIsHireDialogOpen(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <UsersIcon className="h-6 w-6 text-blue-400" />
            Employee Management
          </h2>
          <p className="text-zinc-400 mt-1">Build your dream development team</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-sm text-zinc-400">Team Size</div>
            <div className="text-lg font-bold">{employees.length}/20</div>
          </div>
          <Button onClick={() => setIsHireDialogOpen(true)}>
            <PlusIcon className="h-4 w-4 mr-2" />
            Hire Employee
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="team">Your Team ({employees.length})</TabsTrigger>
          <TabsTrigger value="candidates">Candidates ({availableEmployees.length})</TabsTrigger>
          <TabsTrigger value="legends">Legends ({availableLegends.length})</TabsTrigger>
        </TabsList>

        {/* Current Team */}
        <TabsContent value="team" className="space-y-4">
          {employees.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <UsersIcon className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-zinc-400 mb-2">No Employees Yet</h3>
                <p className="text-zinc-500 mb-4">Start building your team by hiring your first employee</p>
                <Button onClick={() => setIsHireDialogOpen(true)}>
                  <PlusIcon className="h-4 w-4 mr-2" />
                  Hire Your First Employee
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {employees.map((employee) => (
                <motion.div
                  key={employee.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className={`${employee.isLegendary ? 'border-purple-500 bg-purple-900/10' : 'border-zinc-700'}`}>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-zinc-700 rounded-full flex items-center justify-center">
                            {employee.isLegendary ? (
                              <StarIcon className="h-6 w-6 text-purple-400" />
                            ) : (
                              <UserCheckIcon className="h-6 w-6 text-blue-400" />
                            )}
                          </div>
                          <div>
                            <CardTitle className="text-lg flex items-center gap-2">
                              {employee.name}
                              {employee.isLegendary && <StarIcon className="h-4 w-4 text-purple-400" />}
                            </CardTitle>
                            <Badge className={`${getSpecializationColor(employee.primarySpecialization)} text-white`}>
                              {employee.primarySpecialization.replace('_', ' ')}
                            </Badge>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onFireEmployee(employee.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <UserXIcon className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {/* Key Skills */}
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="flex justify-between">
                          <span>Programming:</span>
                          <span className={getSkillColor(employee.skills.programming)}>
                            {employee.skills.programming}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Design:</span>
                          <span className={getSkillColor(employee.skills.gameDesign)}>
                            {employee.skills.gameDesign}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Graphics:</span>
                          <span className={getSkillColor(employee.skills.graphics)}>
                            {employee.skills.graphics}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Sound:</span>
                          <span className={getSkillColor(employee.skills.sound)}>
                            {employee.skills.sound}
                          </span>
                        </div>
                      </div>

                      {/* Status */}
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                          <span>Happiness:</span>
                          <span className={employee.personality.happiness >= 70 ? 'text-green-400' : 'text-yellow-400'}>
                            {employee.personality.happiness}%
                          </span>
                        </div>
                        <Progress value={employee.personality.happiness} className="h-1" />
                      </div>

                      {/* Salary */}
                      <div className="flex justify-between items-center text-sm">
                        <span className="flex items-center gap-1">
                          <DollarSignIcon className="h-3 w-3" />
                          Salary:
                        </span>
                        <span className="text-green-400">${employee.needs.salary.toLocaleString()}/mo</span>
                      </div>

                      {/* Legendary Bonus */}
                      {employee.isLegendary && employee.legendaryBonus && (
                        <div className="p-2 bg-purple-900/20 border border-purple-500/30 rounded text-xs">
                          <div className="font-semibold text-purple-300">{employee.legendaryBonus.name}</div>
                          <div className="text-purple-400">{employee.legendaryBonus.description}</div>
                        </div>
                      )}

                      {/* Quote */}
                      {employee.workingQuote && (
                        <div className="text-xs italic text-zinc-400 border-l-2 border-zinc-600 pl-2">
                          "{employee.workingQuote}"
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Available Candidates */}
        <TabsContent value="candidates" className="space-y-4">
          {/* Filters */}
          <div className="flex gap-4">
            <div className="flex-1">
              <Input
                placeholder="Search candidates..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
              />
            </div>
            <Select value={specializationFilter} onValueChange={setSpecializationFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by specialization" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Specializations</SelectItem>
                <SelectItem value="programmer">Programmer</SelectItem>
                <SelectItem value="game_designer">Game Designer</SelectItem>
                <SelectItem value="graphic_artist">Graphic Artist</SelectItem>
                <SelectItem value="sound_engineer">Sound Engineer</SelectItem>
                <SelectItem value="researcher">Researcher</SelectItem>
                <SelectItem value="qa_tester">QA Tester</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredEmployees.map((employee) => (
              <Card key={employee.id} className="border-zinc-700 hover:border-zinc-600 transition-colors">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-zinc-700 rounded-full flex items-center justify-center">
                      <UserCheckIcon className="h-5 w-5 text-blue-400" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{employee.name}</CardTitle>
                      <Badge className={`${getSpecializationColor(employee.primarySpecialization)} text-white text-xs`}>
                        {employee.primarySpecialization.replace('_', ' ')}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Top Skills */}
                  <div className="text-xs space-y-1">
                    <div className="flex justify-between">
                      <span>Programming:</span>
                      <span className={getSkillColor(employee.skills.programming)}>{employee.skills.programming}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Design:</span>
                      <span className={getSkillColor(employee.skills.gameDesign)}>{employee.skills.gameDesign}</span>
                    </div>
                  </div>

                  {/* Hiring Cost */}
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Hiring Cost:</span>
                    <span className={`text-sm ${companyMoney >= employee.hiringCost ? 'text-green-400' : 'text-red-400'}`}>
                      ${employee.hiringCost.toLocaleString()}
                    </span>
                  </div>

                  <Button
                    size="sm"
                    className="w-full"
                    onClick={() => handleHireEmployee(employee)}
                    disabled={companyMoney < employee.hiringCost}
                  >
                    {companyMoney >= employee.hiringCost ? 'Hire' : 'Not Enough Money'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Legendary Developers */}
        <TabsContent value="legends" className="space-y-4">
          <div className="text-sm text-zinc-400 mb-4">
            Legendary developers become available throughout gaming history. They provide exceptional bonuses but cost significantly more.
          </div>

          {availableLegends.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <StarIcon className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-zinc-400 mb-2">No Legends Available</h3>
                <p className="text-zinc-500">
                  Legendary developers will become available as gaming history progresses.
                  Current year: {currentYear}
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {availableLegends.map((legend) => (
                <Card key={legend.id} className="border-purple-500 bg-gradient-to-br from-purple-900/20 to-blue-900/20">
                  <CardHeader>
                    <div className="flex items-start gap-4">
                      <div className="w-16 h-16 bg-purple-700 rounded-full flex items-center justify-center">
                        <StarIcon className="h-8 w-8 text-yellow-400" />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-xl flex items-center gap-2">
                          {legend.gameName}
                          <StarIcon className="h-5 w-5 text-purple-400" />
                        </CardTitle>
                        <CardDescription className="text-purple-300">
                          Based on {legend.realName}
                        </CardDescription>
                        <div className="mt-2">
                          <Badge variant="outline" className="border-purple-400 text-purple-300">
                            {legend.legendaryBonus.name}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-zinc-300">{legend.bio}</p>

                    <div className="space-y-2">
                      <h4 className="text-sm font-semibold">Famous For:</h4>
                      <div className="flex flex-wrap gap-1">
                        {legend.famousFor.map((game) => (
                          <Badge key={game} variant="secondary" className="text-xs">
                            {game}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="p-3 bg-purple-900/30 border border-purple-500/30 rounded">
                      <h4 className="text-sm font-semibold text-purple-300 mb-1">
                        {legend.legendaryBonus.name}
                      </h4>
                      <p className="text-xs text-purple-200">
                        {legend.legendaryBonus.description}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="flex justify-between">
                        <span>Programming:</span>
                        <span className={getSkillColor(legend.skills.programming)}>{legend.skills.programming}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Design:</span>
                        <span className={getSkillColor(legend.skills.gameDesign)}>{legend.skills.gameDesign}</span>
                      </div>
                    </div>

                    <Separator />

                    <div className="flex justify-between items-center">
                      <span className="text-sm font-semibold">Hiring Cost:</span>
                      <span className={`text-lg font-bold ${companyMoney >= legend.hiringCost ? 'text-green-400' : 'text-red-400'}`}>
                        ${legend.hiringCost.toLocaleString()}
                      </span>
                    </div>

                    <Button
                      className="w-full bg-purple-600 hover:bg-purple-700"
                      onClick={() => handleHireLegend(legend)}
                      disabled={companyMoney < legend.hiringCost}
                    >
                      {companyMoney >= legend.hiringCost ? 'Hire Legend' : 'Not Enough Money'}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Hire Dialog */}
      <Dialog open={isHireDialogOpen} onOpenChange={setIsHireDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Quick Hire</DialogTitle>
            <DialogDescription>
              Browse and hire employees quickly
            </DialogDescription>
          </DialogHeader>
          {/* Quick hire interface could go here */}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsHireDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
