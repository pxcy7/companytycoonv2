'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Separator } from '@/components/ui/separator';
import {
  TrendingUpIcon,
  TargetIcon,
  MegaphoneIcon,
  TvIcon,
  RadioIcon,
  GlobeIcon,
  UsersIcon,
  CalendarIcon,
  DollarSignIcon,
  BarChart3Icon,
  SparklesIcon,
  AwardIcon,
  NewspaperIcon
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { motion } from 'framer-motion';

interface MarketingCampaign {
  id: string;
  name: string;
  type: CampaignType;
  gameId: string;
  budget: number;
  duration: number; // weeks
  startWeek: number;
  targetAudience: string[];
  channels: MarketingChannel[];
  status: 'planned' | 'active' | 'completed';
  effectiveness: number; // 0-100
  reachEstimate: number;
  hypeGenerated: number;
  actualResults?: CampaignResults;
}

interface CampaignResults {
  actualReach: number;
  hypeIncrease: number;
  salesBoost: number;
  brandAwareness: number;
  cost: number;
}

type CampaignType =
  | 'teaser'
  | 'announcement'
  | 'preview'
  | 'review_embargo'
  | 'launch'
  | 'post_launch'
  | 'dlc_promotion';

type MarketingChannel =
  | 'social_media'
  | 'gaming_press'
  | 'influencers'
  | 'tv_ads'
  | 'radio_ads'
  | 'online_ads'
  | 'print_media'
  | 'events'
  | 'beta_program'
  | 'demo_release';

interface HypeData {
  gameId: string;
  gameName: string;
  currentHype: number; // 0-100
  maxHype: number;
  hypeDecay: number; // weekly decay rate
  history: HypePoint[];
  factors: HypeFactor[];
}

interface HypePoint {
  week: number;
  hype: number;
  event?: string;
}

interface HypeFactor {
  type: 'positive' | 'negative';
  source: string;
  impact: number;
  description: string;
}

interface MarketingSystemProps {
  currentWeek: number;
  companyMoney: number;
  games: any[];
  onSpendMoney: (amount: number) => boolean;
  onCreateCampaign: (campaign: MarketingCampaign) => void;
}

const MARKETING_CHANNELS = [
  {
    id: 'social_media',
    name: 'Social Media',
    icon: GlobeIcon,
    costPerWeek: 500,
    reach: 'High',
    effectiveness: 85,
    description: 'Twitter, Facebook, Instagram campaigns'
  },
  {
    id: 'gaming_press',
    name: 'Gaming Press',
    icon: NewspaperIcon,
    costPerWeek: 1500,
    reach: 'Medium',
    effectiveness: 95,
    description: 'IGN, GameSpot, Polygon coverage'
  },
  {
    id: 'influencers',
    name: 'Influencers',
    icon: UsersIcon,
    costPerWeek: 2000,
    reach: 'High',
    effectiveness: 90,
    description: 'YouTube, Twitch streamers'
  },
  {
    id: 'tv_ads',
    name: 'TV Advertising',
    icon: TvIcon,
    costPerWeek: 5000,
    reach: 'Very High',
    effectiveness: 70,
    description: 'Television commercials'
  },
  {
    id: 'online_ads',
    name: 'Online Ads',
    icon: TargetIcon,
    costPerWeek: 800,
    reach: 'High',
    effectiveness: 75,
    description: 'Google, YouTube, banner ads'
  },
  {
    id: 'events',
    name: 'Gaming Events',
    icon: CalendarIcon,
    costPerWeek: 3000,
    reach: 'Medium',
    effectiveness: 100,
    description: 'E3, PAX, Gamescom presence'
  }
];

const CAMPAIGN_TYPES = [
  {
    id: 'teaser',
    name: 'Teaser Campaign',
    description: 'Build initial awareness and mystery',
    optimalWeeksBeforeRelease: 20,
    hypeMultiplier: 1.2,
    duration: [2, 4]
  },
  {
    id: 'announcement',
    name: 'Official Announcement',
    description: 'Reveal the game to the world',
    optimalWeeksBeforeRelease: 16,
    hypeMultiplier: 1.5,
    duration: [1, 2]
  },
  {
    id: 'preview',
    name: 'Preview Campaign',
    description: 'Show gameplay and features',
    optimalWeeksBeforeRelease: 8,
    hypeMultiplier: 1.3,
    duration: [3, 6]
  },
  {
    id: 'launch',
    name: 'Launch Campaign',
    description: 'Maximum push for release week',
    optimalWeeksBeforeRelease: 0,
    hypeMultiplier: 2.0,
    duration: [1, 3]
  }
];

export function MarketingSystem({
  currentWeek,
  companyMoney,
  games,
  onSpendMoney,
  onCreateCampaign
}: MarketingSystemProps) {
  const [activeTab, setActiveTab] = useState('campaigns');
  const [activeCampaigns, setActiveCampaigns] = useState<MarketingCampaign[]>([]);
  const [hypeData, setHypeData] = useState<HypeData[]>([]);
  const [newCampaign, setNewCampaign] = useState({
    name: '',
    type: 'announcement' as CampaignType,
    gameId: '',
    budget: 5000,
    duration: 4,
    channels: [] as MarketingChannel[]
  });

  // Initialize hype data for games
  useEffect(() => {
    const gameHypeData = games.filter(g => g.isReleased || g.isInDevelopment).map(game => ({
      gameId: game.id,
      gameName: game.name,
      currentHype: Math.floor(Math.random() * 30) + 10,
      maxHype: 100,
      hypeDecay: 2,
      history: [],
      factors: []
    }));
    setHypeData(gameHypeData);
  }, [games]);

  // Calculate campaign cost
  const calculateCampaignCost = () => {
    const channelCosts = newCampaign.channels.reduce((total, channel) => {
      const channelData = MARKETING_CHANNELS.find(c => c.id === channel);
      return total + (channelData?.costPerWeek || 0);
    }, 0);
    return channelCosts * newCampaign.duration + newCampaign.budget;
  };

  const totalCost = calculateCampaignCost();

  const createCampaign = () => {
    if (!newCampaign.gameId || newCampaign.channels.length === 0) return;

    if (onSpendMoney(totalCost)) {
      const campaign: MarketingCampaign = {
        id: Math.random().toString(36).substr(2, 9),
        name: newCampaign.name || `${newCampaign.type} Campaign`,
        type: newCampaign.type,
        gameId: newCampaign.gameId,
        budget: newCampaign.budget,
        duration: newCampaign.duration,
        startWeek: currentWeek,
        targetAudience: ['gamers', 'casual'],
        channels: newCampaign.channels,
        status: 'active',
        effectiveness: calculateEffectiveness(),
        reachEstimate: calculateReach(),
        hypeGenerated: 0
      };

      setActiveCampaigns(prev => [...prev, campaign]);
      onCreateCampaign(campaign);

      // Reset form
      setNewCampaign({
        name: '',
        type: 'announcement',
        gameId: '',
        budget: 5000,
        duration: 4,
        channels: []
      });
    }
  };

  const calculateEffectiveness = () => {
    const channelEffectiveness = newCampaign.channels.reduce((avg, channel) => {
      const channelData = MARKETING_CHANNELS.find(c => c.id === channel);
      return avg + (channelData?.effectiveness || 0);
    }, 0) / Math.max(newCampaign.channels.length, 1);

    const campaignType = CAMPAIGN_TYPES.find(c => c.id === newCampaign.type);
    const typeMultiplier = campaignType?.hypeMultiplier || 1;

    return Math.min(100, channelEffectiveness * typeMultiplier);
  };

  const calculateReach = () => {
    const baseReach = newCampaign.budget * 2;
    const channelMultiplier = newCampaign.channels.length * 0.5 + 1;
    return Math.floor(baseReach * channelMultiplier);
  };

  const getChannelIcon = (channelId: string) => {
    const channel = MARKETING_CHANNELS.find(c => c.id === channelId);
    return channel?.icon || MegaphoneIcon;
  };

  // Sample hype chart data
  const sampleHypeData = [
    { week: currentWeek - 8, hype: 15 },
    { week: currentWeek - 6, hype: 25 },
    { week: currentWeek - 4, hype: 35 },
    { week: currentWeek - 2, hype: 55 },
    { week: currentWeek, hype: 45 },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <MegaphoneIcon className="h-6 w-6 text-orange-400" />
            Marketing & Hype Management
          </h2>
          <p className="text-zinc-400 mt-1">Build awareness and excitement for your games</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-zinc-400">Marketing Budget</div>
          <div className="text-xl font-bold text-green-400">${companyMoney.toLocaleString()}</div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
          <TabsTrigger value="hype">Hype Tracking</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="channels">Channels</TabsTrigger>
        </TabsList>

        {/* Campaign Management */}
        <TabsContent value="campaigns" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Create New Campaign */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <SparklesIcon className="h-5 w-5 text-purple-400" />
                  Create Campaign
                </CardTitle>
                <CardDescription>Launch a new marketing campaign</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Campaign Name</Label>
                  <Input
                    value={newCampaign.name}
                    onChange={(e) => setNewCampaign(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter campaign name"
                  />
                </div>

                <div>
                  <Label>Campaign Type</Label>
                  <Select
                    value={newCampaign.type}
                    onValueChange={(value: CampaignType) => setNewCampaign(prev => ({ ...prev, type: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CAMPAIGN_TYPES.map((type) => (
                        <SelectItem key={type.id} value={type.id}>
                          {type.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Target Game</Label>
                  <Select
                    value={newCampaign.gameId}
                    onValueChange={(value) => setNewCampaign(prev => ({ ...prev, gameId: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a game" />
                    </SelectTrigger>
                    <SelectContent>
                      {games.filter(g => g.isInDevelopment || g.isReleased).map((game) => (
                        <SelectItem key={game.id} value={game.id}>
                          {game.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Budget: ${newCampaign.budget.toLocaleString()}</Label>
                  <Slider
                    value={[newCampaign.budget]}
                    onValueChange={([value]) => setNewCampaign(prev => ({ ...prev, budget: value }))}
                    max={50000}
                    min={1000}
                    step={500}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Duration: {newCampaign.duration} weeks</Label>
                  <Slider
                    value={[newCampaign.duration]}
                    onValueChange={([value]) => setNewCampaign(prev => ({ ...prev, duration: value }))}
                    max={12}
                    min={1}
                    step={1}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Marketing Channels</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {MARKETING_CHANNELS.map((channel) => {
                      const Icon = channel.icon;
                      const isSelected = newCampaign.channels.includes(channel.id as MarketingChannel);

                      return (
                        <button
                          key={channel.id}
                          onClick={() => {
                            if (isSelected) {
                              setNewCampaign(prev => ({
                                ...prev,
                                channels: prev.channels.filter(c => c !== channel.id)
                              }));
                            } else {
                              setNewCampaign(prev => ({
                                ...prev,
                                channels: [...prev.channels, channel.id as MarketingChannel]
                              }));
                            }
                          }}
                          className={`p-3 rounded-lg border text-left transition-colors ${
                            isSelected
                              ? 'border-blue-500 bg-blue-500/20'
                              : 'border-zinc-600 hover:border-zinc-500'
                          }`}
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <Icon className="h-4 w-4" />
                            <span className="text-sm font-medium">{channel.name}</span>
                          </div>
                          <div className="text-xs text-zinc-400">
                            ${channel.costPerWeek}/week
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Estimated Effectiveness:</span>
                    <span className="text-blue-400">{Math.round(calculateEffectiveness())}%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Estimated Reach:</span>
                    <span className="text-green-400">{calculateReach().toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm font-semibold">
                    <span>Total Cost:</span>
                    <span className={companyMoney >= totalCost ? 'text-green-400' : 'text-red-400'}>
                      ${totalCost.toLocaleString()}
                    </span>
                  </div>
                </div>

                <Button
                  onClick={createCampaign}
                  disabled={!newCampaign.gameId || newCampaign.channels.length === 0 || companyMoney < totalCost}
                  className="w-full"
                >
                  Launch Campaign
                </Button>
              </CardContent>
            </Card>

            {/* Active Campaigns */}
            <Card>
              <CardHeader>
                <CardTitle>Active Campaigns ({activeCampaigns.length})</CardTitle>
                <CardDescription>Currently running marketing campaigns</CardDescription>
              </CardHeader>
              <CardContent>
                {activeCampaigns.length === 0 ? (
                  <div className="text-center py-8">
                    <MegaphoneIcon className="h-12 w-12 text-zinc-600 mx-auto mb-4" />
                    <p className="text-zinc-400">No active campaigns</p>
                    <p className="text-sm text-zinc-500">Create your first campaign to start building hype</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {activeCampaigns.map((campaign) => (
                      <motion.div
                        key={campaign.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="p-4 border border-zinc-700 rounded-lg"
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h4 className="font-semibold">{campaign.name}</h4>
                            <p className="text-sm text-zinc-400">{campaign.type.replace('_', ' ')}</p>
                          </div>
                          <Badge variant="outline" className="text-green-400 border-green-400">
                            {campaign.status}
                          </Badge>
                        </div>

                        <div className="space-y-2">
                          <div className="flex justify-between text-xs">
                            <span>Progress:</span>
                            <span>{Math.min(currentWeek - campaign.startWeek, campaign.duration)}/{campaign.duration} weeks</span>
                          </div>
                          <Progress
                            value={(Math.min(currentWeek - campaign.startWeek, campaign.duration) / campaign.duration) * 100}
                            className="h-1"
                          />
                        </div>

                        <div className="flex gap-1 mt-3">
                          {campaign.channels.map((channelId) => {
                            const Icon = getChannelIcon(channelId);
                            return (
                              <div
                                key={channelId}
                                className="p-1 bg-zinc-800 rounded"
                                title={channelId.replace('_', ' ')}
                              >
                                <Icon className="h-3 w-3" />
                              </div>
                            );
                          })}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Hype Tracking */}
        <TabsContent value="hype" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUpIcon className="h-5 w-5 text-green-400" />
                  Hype Levels
                </CardTitle>
                <CardDescription>Current excitement levels for your games</CardDescription>
              </CardHeader>
              <CardContent>
                {hypeData.length === 0 ? (
                  <div className="text-center py-8">
                    <BarChart3Icon className="h-12 w-12 text-zinc-600 mx-auto mb-4" />
                    <p className="text-zinc-400">No games to track</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {hypeData.map((data) => (
                      <div key={data.gameId} className="space-y-2">
                        <div className="flex justify-between">
                          <span className="font-medium">{data.gameName}</span>
                          <span className="text-sm text-zinc-400">{data.currentHype}/100</span>
                        </div>
                        <Progress value={data.currentHype} className="h-2" />
                        <div className="flex justify-between text-xs text-zinc-500">
                          <span>Hype Level</span>
                          <span>
                            {data.currentHype >= 80 && "🔥 Extremely High"}
                            {data.currentHype >= 60 && data.currentHype < 80 && "📈 High"}
                            {data.currentHype >= 40 && data.currentHype < 60 && "📊 Moderate"}
                            {data.currentHype >= 20 && data.currentHype < 40 && "📉 Low"}
                            {data.currentHype < 20 && "😴 Very Low"}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Hype History</CardTitle>
                <CardDescription>Track hype changes over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart data={sampleHypeData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="week" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '6px'
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="hype"
                      stroke="#F59E0B"
                      fill="#F59E0B"
                      fillOpacity={0.3}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Hype Factors */}
          <Card>
            <CardHeader>
              <CardTitle>Hype Factors</CardTitle>
              <CardDescription>Events and factors affecting game excitement</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h4 className="text-sm font-semibold text-green-400 flex items-center gap-2">
                    <TrendingUpIcon className="h-4 w-4" />
                    Positive Factors
                  </h4>
                  <div className="space-y-2">
                    <div className="p-3 bg-green-900/20 border border-green-600/30 rounded">
                      <div className="text-sm font-medium">Successful Preview</div>
                      <div className="text-xs text-green-300">+15 hype from gameplay reveal</div>
                    </div>
                    <div className="p-3 bg-green-900/20 border border-green-600/30 rounded">
                      <div className="text-sm font-medium">Influencer Coverage</div>
                      <div className="text-xs text-green-300">+8 hype from streamer reactions</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-sm font-semibold text-red-400 flex items-center gap-2">
                    <TrendingUpIcon className="h-4 w-4 rotate-180" />
                    Negative Factors
                  </h4>
                  <div className="space-y-2">
                    <div className="p-3 bg-red-900/20 border border-red-600/30 rounded">
                      <div className="text-sm font-medium">Development Delay</div>
                      <div className="text-xs text-red-300">-12 hype from postponed release</div>
                    </div>
                    <div className="p-3 bg-red-900/20 border border-red-600/30 rounded">
                      <div className="text-sm font-medium">Controversy</div>
                      <div className="text-xs text-red-300">-5 hype from design criticism</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Total Campaigns</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{activeCampaigns.length}</div>
                <p className="text-xs text-zinc-400">This quarter</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Marketing Spend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-400">
                  ${activeCampaigns.reduce((sum, c) => sum + c.budget, 0).toLocaleString()}
                </div>
                <p className="text-xs text-zinc-400">Total invested</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Avg. Effectiveness</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-400">
                  {activeCampaigns.length > 0
                    ? Math.round(activeCampaigns.reduce((sum, c) => sum + c.effectiveness, 0) / activeCampaigns.length)
                    : 0}%
                </div>
                <p className="text-xs text-zinc-400">Campaign performance</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Channels Tab */}
        <TabsContent value="channels" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {MARKETING_CHANNELS.map((channel) => {
              const Icon = channel.icon;
              return (
                <Card key={channel.id}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Icon className="h-5 w-5 text-blue-400" />
                      {channel.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-zinc-400">{channel.description}</p>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Cost per week:</span>
                        <span className="text-green-400">${channel.costPerWeek.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Reach:</span>
                        <span className="text-blue-400">{channel.reach}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Effectiveness:</span>
                        <span className="text-purple-400">{channel.effectiveness}%</span>
                      </div>
                    </div>

                    <div className="pt-2">
                      <div className="text-xs text-zinc-500 mb-1">Effectiveness</div>
                      <Progress value={channel.effectiveness} className="h-1" />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
