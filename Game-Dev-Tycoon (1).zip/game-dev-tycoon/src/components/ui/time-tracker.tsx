'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { CalendarIcon, TrendingUpIcon, AlertTriangleIcon, StarIcon } from 'lucide-react';
import { motion } from 'framer-motion';

interface TimeTrackerProps {
  currentWeek: number;
  isGamePaused: boolean;
  onTogglePause: () => void;
}

interface IndustryEvent {
  id: string;
  title: string;
  description: string;
  week: number;
  type: 'conference' | 'trend' | 'competition' | 'market_shift' | 'technology';
  impact: 'positive' | 'negative' | 'neutral';
  effectDescription: string;
}

const INDUSTRY_EVENTS: IndustryEvent[] = [
  {
    id: 'gdc_spring',
    title: 'Game Developers Conference',
    description: 'The biggest game development conference of the year',
    week: 12,
    type: 'conference',
    impact: 'positive',
    effectDescription: '+20% Research speed for 4 weeks'
  },
  {
    id: 'e3_summer',
    title: 'E3 Gaming Expo',
    description: 'Major gaming expo with industry announcements',
    week: 24,
    type: 'conference',
    impact: 'positive',
    effectDescription: '+30% Marketing effectiveness for 8 weeks'
  },
  {
    id: 'mobile_boom',
    title: 'Mobile Gaming Boom',
    description: 'Smartphones revolutionize the gaming market',
    week: 156,
    type: 'market_shift',
    impact: 'positive',
    effectDescription: 'Mobile platform sales +50%'
  },
  {
    id: 'indie_renaissance',
    title: 'Indie Game Renaissance',
    description: 'Independent developers gain mainstream recognition',
    week: 208,
    type: 'trend',
    impact: 'positive',
    effectDescription: 'Small games get +25% sales boost'
  },
  {
    id: 'vr_emergence',
    title: 'VR Technology Emerges',
    description: 'Virtual Reality becomes commercially viable',
    week: 312,
    type: 'technology',
    impact: 'neutral',
    effectDescription: 'New VR platform available for research'
  },
  {
    id: 'market_crash',
    title: 'Gaming Market Correction',
    description: 'Economic downturn affects gaming industry',
    week: 364,
    type: 'market_shift',
    impact: 'negative',
    effectDescription: '-25% game sales for 12 weeks'
  }
];

export function TimeTracker({ currentWeek, isGamePaused, onTogglePause }: TimeTrackerProps) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Calculate game date (starting from 1980)
  const startYear = 1980;
  const weeksPerYear = 52;
  const currentYear = startYear + Math.floor((currentWeek - 1) / weeksPerYear);
  const currentWeekOfYear = ((currentWeek - 1) % weeksPerYear) + 1;
  const currentMonth = Math.floor((currentWeekOfYear - 1) / 4.33) + 1;
  const currentQuarter = Math.floor((currentMonth - 1) / 3) + 1;

  // Get season
  const getSeason = (month: number) => {
    if (month >= 3 && month <= 5) return { name: 'Spring', color: 'text-green-400', emoji: '🌸' };
    if (month >= 6 && month <= 8) return { name: 'Summer', color: 'text-yellow-400', emoji: '☀️' };
    if (month >= 9 && month <= 11) return { name: 'Fall', color: 'text-orange-400', emoji: '🍂' };
    return { name: 'Winter', color: 'text-blue-400', emoji: '❄️' };
  };

  const season = getSeason(currentMonth);

  // Check for current industry events
  const activeEvents = INDUSTRY_EVENTS.filter(event =>
    event.week <= currentWeek && event.week > currentWeek - 8
  );

  const upcomingEvents = INDUSTRY_EVENTS.filter(event =>
    event.week > currentWeek && event.week <= currentWeek + 12
  ).slice(0, 3);

  // Calculate progress through current year
  const yearProgress = (currentWeekOfYear / weeksPerYear) * 100;

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const getEventTypeIcon = (type: string) => {
    switch (type) {
      case 'conference': return <CalendarIcon className="h-4 w-4" />;
      case 'trend': return <TrendingUpIcon className="h-4 w-4" />;
      case 'market_shift': return <AlertTriangleIcon className="h-4 w-4" />;
      case 'competition': return <StarIcon className="h-4 w-4" />;
      case 'technology': return <TrendingUpIcon className="h-4 w-4" />;
      default: return <CalendarIcon className="h-4 w-4" />;
    }
  };

  const getEventColor = (impact: string) => {
    switch (impact) {
      case 'positive': return 'border-green-500 bg-green-900/20';
      case 'negative': return 'border-red-500 bg-red-900/20';
      default: return 'border-blue-500 bg-blue-900/20';
    }
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <CalendarIcon className="h-5 w-5 text-blue-400" />
            Game Calendar
          </CardTitle>
          <Badge
            variant={isGamePaused ? "destructive" : "default"}
            className={isGamePaused ? "bg-red-600" : "bg-green-600"}
          >
            {isGamePaused ? "PAUSED" : "RUNNING"}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Main Date Display */}
        <motion.div
          className="text-center p-4 bg-zinc-800/50 rounded-lg"
          animate={{ scale: isGamePaused ? 0.95 : 1 }}
          transition={{ duration: 0.2 }}
        >
          <div className="text-3xl font-bold text-white mb-1">
            {monthNames[currentMonth - 1]} {currentYear}
          </div>
          <div className="text-lg text-zinc-400">
            Week {currentWeek} • Q{currentQuarter} • {season.emoji} {season.name}
          </div>
          <div className="mt-2 flex items-center justify-center gap-2">
            <span className="text-sm text-zinc-500">Week {currentWeekOfYear} of {weeksPerYear}</span>
          </div>
        </motion.div>

        {/* Year Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-zinc-400">
            <span>Year Progress</span>
            <span>{Math.round(yearProgress)}%</span>
          </div>
          <Progress value={yearProgress} className="h-2" />
        </div>

        {/* Game Speed Controls */}
        <div className="flex items-center justify-center gap-2 p-2 bg-zinc-800/30 rounded-lg">
          <button
            onClick={onTogglePause}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              isGamePaused
                ? 'bg-green-600 hover:bg-green-700 text-white'
                : 'bg-red-600 hover:bg-red-700 text-white'
            }`}
          >
            {isGamePaused ? '▶️ Resume' : '⏸️ Pause'}
          </button>
          <div className="text-xs text-zinc-400">
            Speed: {isGamePaused ? 'Paused' : '1 week/3s'}
          </div>
        </div>

        {/* Active Events */}
        {activeEvents.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-zinc-300 flex items-center gap-2">
              <StarIcon className="h-4 w-4 text-yellow-400" />
              Active Events
            </h4>
            {activeEvents.map((event) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className={`p-3 rounded-lg border ${getEventColor(event.impact)}`}
              >
                <div className="flex items-start gap-2">
                  {getEventTypeIcon(event.type)}
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-white truncate">
                      {event.title}
                    </div>
                    <div className="text-xs text-zinc-400 mt-1">
                      {event.effectDescription}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Upcoming Events */}
        {upcomingEvents.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-zinc-300">Upcoming Events</h4>
            {upcomingEvents.map((event) => (
              <div key={event.id} className="p-2 bg-zinc-800/30 rounded">
                <div className="flex items-center gap-2">
                  {getEventTypeIcon(event.type)}
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-zinc-300 truncate">
                      {event.title}
                    </div>
                    <div className="text-xs text-zinc-500">
                      Week {event.week} ({event.week - currentWeek} weeks away)
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Industry Era Indicator */}
        <div className="text-center p-2 bg-gradient-to-r from-purple-900/30 to-blue-900/30 rounded-lg">
          <div className="text-xs text-purple-300 font-medium">
            {currentYear < 1985 && "🕹️ Arcade Era"}
            {currentYear >= 1985 && currentYear < 1990 && "🎮 Console Wars Begin"}
            {currentYear >= 1990 && currentYear < 1995 && "💽 CD-ROM Revolution"}
            {currentYear >= 1995 && currentYear < 2000 && "🌐 Internet Gaming"}
            {currentYear >= 2000 && currentYear < 2005 && "📱 Mobile Emergence"}
            {currentYear >= 2005 && currentYear < 2010 && "🎯 Casual Gaming Boom"}
            {currentYear >= 2010 && currentYear < 2015 && "☁️ Cloud & Social Gaming"}
            {currentYear >= 2015 && "🥽 VR & Next-Gen Era"}
          </div>
        </div>

        {/* Real Time Display */}
        <div className="text-center text-xs text-zinc-500 border-t border-zinc-800 pt-2">
          Real Time: {currentTime.toLocaleTimeString()}
        </div>
      </CardContent>
    </Card>
  );
}
