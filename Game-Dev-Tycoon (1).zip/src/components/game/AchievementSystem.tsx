'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  TrophyIcon,
  StarIcon,
  AwardIcon,
  MedalIcon,
  CrownIcon,
  ZapIcon,
  TargetIcon,
  TrendingUpIcon,
  DollarSignIcon,
  GamepadIcon,
  UsersIcon,
  BeakerIcon,
  ClockIcon,
  LockIcon,
  CheckCircleIcon,
  GiftIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '@/store/gameStore';

interface Achievement {
  id: string;
  title: string;
  description: string;
  category: AchievementCategory;
  rarity: 'common' | 'rare' | 'epic' | 'legendary' | 'mythical';
  icon: any;
  requirement: {
    type: string;
    target: number;
    current?: number;
  };
  reward: {
    type: 'money' | 'reputation' | 'research_points' | 'unlock' | 'bonus';
    value: number;
    description: string;
  };
  isUnlocked: boolean;
  isCompleted: boolean;
  unlockedDate?: Date;
  points: number; // Achievement points for leaderboard
}

type AchievementCategory =
  | 'development'
  | 'sales'
  | 'company'
  | 'research'
  | 'marketing'
  | 'special'
  | 'milestone';

const ACHIEVEMENTS: Achievement[] = [
  // Development Achievements
  {
    id: 'first_game',
    title: 'First Steps',
    description: 'Develop your very first game',
    category: 'development',
    rarity: 'common',
    icon: GamepadIcon,
    requirement: { type: 'games_developed', target: 1 },
    reward: { type: 'money', value: 5000, description: '+$5,000 bonus' },
    isUnlocked: true,
    isCompleted: false,
    points: 10
  },
  {
    id: 'perfectionist',
    title: 'Perfectionist',
    description: 'Create a game with 95+ quality score',
    category: 'development',
    rarity: 'epic',
    icon: StarIcon,
    requirement: { type: 'perfect_game', target: 95 },
    reward: { type: 'reputation', value: 25, description: '+25 Reputation' },
    isUnlocked: true,
    isCompleted: false,
    points: 50
  },
  {
    id: 'triple_a_developer',
    title: 'AAA Developer',
    description: 'Successfully release 5 AAA games',
    category: 'development',
    rarity: 'legendary',
    icon: CrownIcon,
    requirement: { type: 'aaa_games', target: 5 },
    reward: { type: 'unlock', value: 0, description: 'Unlock "Master Developer" title' },
    isUnlocked: false,
    isCompleted: false,
    points: 100
  },
  {
    id: 'speed_developer',
    title: 'Lightning Fast',
    description: 'Complete a game development in under 3 weeks',
    category: 'development',
    rarity: 'rare',
    icon: ZapIcon,
    requirement: { type: 'fast_development', target: 3 },
    reward: { type: 'bonus', value: 15, description: '+15% development speed for next game' },
    isUnlocked: true,
    isCompleted: false,
    points: 30
  },

  // Sales Achievements
  {
    id: 'first_million',
    title: 'Millionaire',
    description: 'Earn your first million dollars',
    category: 'sales',
    rarity: 'rare',
    icon: DollarSignIcon,
    requirement: { type: 'total_revenue', target: 1000000 },
    reward: { type: 'money', value: 100000, description: '+$100,000 bonus' },
    isUnlocked: true,
    isCompleted: false,
    points: 40
  },
  {
    id: 'viral_hit',
    title: 'Viral Sensation',
    description: 'Have a game sell 1 million copies',
    category: 'sales',
    rarity: 'epic',
    icon: TrendingUpIcon,
    requirement: { type: 'game_sales', target: 1000000 },
    reward: { type: 'reputation', value: 50, description: '+50 Reputation' },
    isUnlocked: true,
    isCompleted: false,
    points: 75
  },
  {
    id: 'consistent_success',
    title: 'Consistent Success',
    description: 'Release 10 consecutive profitable games',
    category: 'sales',
    rarity: 'legendary',
    icon: TargetIcon,
    requirement: { type: 'consecutive_hits', target: 10 },
    reward: { type: 'bonus', value: 25, description: '+25% marketing effectiveness permanently' },
    isUnlocked: false,
    isCompleted: false,
    points: 120
  },

  // Company Achievements
  {
    id: 'first_employee',
    title: 'Team Builder',
    description: 'Hire your first employee',
    category: 'company',
    rarity: 'common',
    icon: UsersIcon,
    requirement: { type: 'employees_hired', target: 1 },
    reward: { type: 'money', value: 2500, description: '+$2,500 hiring bonus' },
    isUnlocked: true,
    isCompleted: false,
    points: 15
  },
  {
    id: 'legend_collector',
    title: 'Legend Collector',
    description: 'Hire all legendary developers',
    category: 'company',
    rarity: 'mythical',
    icon: AwardIcon,
    requirement: { type: 'legendary_employees', target: 4 },
    reward: { type: 'bonus', value: 50, description: '+50% to all employee skills permanently' },
    isUnlocked: false,
    isCompleted: false,
    points: 200
  },
  {
    id: 'office_upgrade',
    title: 'Corporate Success',
    description: 'Move to the Corporate Headquarters',
    category: 'company',
    rarity: 'epic',
    icon: CrownIcon,
    requirement: { type: 'office_tier', target: 4 },
    reward: { type: 'reputation', value: 30, description: '+30 Reputation' },
    isUnlocked: false,
    isCompleted: false,
    points: 60
  },

  // Research Achievements
  {
    id: 'tech_pioneer',
    title: 'Technology Pioneer',
    description: 'Research all available technologies',
    category: 'research',
    rarity: 'legendary',
    icon: BeakerIcon,
    requirement: { type: 'all_research', target: 100 },
    reward: { type: 'research_points', value: 1000, description: '+1,000 Research Points' },
    isUnlocked: false,
    isCompleted: false,
    points: 150
  },
  {
    id: 'early_adopter',
    title: 'Early Adopter',
    description: 'Research a technology in the same year it becomes available',
    category: 'research',
    rarity: 'rare',
    icon: ZapIcon,
    requirement: { type: 'early_research', target: 1 },
    reward: { type: 'bonus', value: 20, description: '+20% research speed for 1 year' },
    isUnlocked: true,
    isCompleted: false,
    points: 35
  },

  // Special Achievements
  {
    id: 'time_traveler',
    title: 'Time Traveler',
    description: 'Survive 50 years in the gaming industry',
    category: 'special',
    rarity: 'mythical',
    icon: ClockIcon,
    requirement: { type: 'years_survived', target: 50 },
    reward: { type: 'unlock', value: 0, description: 'Unlock "Industry Veteran" title and special bonuses' },
    isUnlocked: false,
    isCompleted: false,
    points: 500
  },
  {
    id: 'easter_egg',
    title: 'Konami Code',
    description: 'Find the hidden easter egg in the game',
    category: 'special',
    rarity: 'epic',
    icon: GiftIcon,
    requirement: { type: 'easter_egg', target: 1 },
    reward: { type: 'bonus', value: 0, description: 'Unlock secret game features' },
    isUnlocked: true,
    isCompleted: false,
    points: 25
  }
];

interface AchievementSystemProps {
  currentWeek: number;
  company: any;
  games: any[];
  employees: any[];
}

export function AchievementSystem({
  currentWeek,
  company,
  games,
  employees
}: AchievementSystemProps) {
  const [achievements, setAchievements] = useState<Achievement[]>(ACHIEVEMENTS);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showCompleted, setShowCompleted] = useState(false);
  const [recentlyUnlocked, setRecentlyUnlocked] = useState<Achievement[]>([]);

  const { addNotification, addMoney } = useGameStore();

  // Check for achievement progress
  useEffect(() => {
    checkAchievementProgress();
  }, [currentWeek, company, games, employees]);

  const checkAchievementProgress = () => {
    const updatedAchievements = achievements.map(achievement => {
      if (achievement.isCompleted) return achievement;

      let currentProgress = 0;
      let shouldComplete = false;

      switch (achievement.requirement.type) {
        case 'games_developed':
          currentProgress = games.length;
          break;
        case 'perfect_game':
          currentProgress = Math.max(...games.map(g => g.qualityScore || 0));
          shouldComplete = currentProgress >= achievement.requirement.target;
          break;
        case 'aaa_games':
          currentProgress = games.filter(g => g.size === 'aaa' && g.isReleased).length;
          break;
        case 'total_revenue':
          currentProgress = games.reduce((sum, g) => sum + g.salesData.revenue, 0);
          break;
        case 'game_sales':
          currentProgress = Math.max(...games.map(g => g.salesData.totalSales || 0));
          break;
        case 'employees_hired':
          currentProgress = employees.length;
          break;
        case 'legendary_employees':
          currentProgress = employees.filter(e => e.isLegendary).length;
          break;
        case 'office_tier':
          currentProgress = company.office?.tier === 'luxury' ? 4 :
                           company.office?.tier === 'corporate' ? 3 :
                           company.office?.tier === 'professional' ? 2 : 1;
          break;
        case 'years_survived':
          currentProgress = Math.floor(currentWeek / 52);
          break;
      }

      if (!shouldComplete) {
        shouldComplete = currentProgress >= achievement.requirement.target;
      }

      const updatedAchievement = {
        ...achievement,
        requirement: { ...achievement.requirement, current: currentProgress }
      };

      // Complete achievement if criteria met
      if (shouldComplete && !achievement.isCompleted && achievement.isUnlocked) {
        updatedAchievement.isCompleted = true;
        updatedAchievement.unlockedDate = new Date();

        // Grant reward
        grantAchievementReward(achievement);

        // Add to recently unlocked
        setRecentlyUnlocked(prev => [...prev, updatedAchievement]);

        // Remove from recently unlocked after 5 seconds
        setTimeout(() => {
          setRecentlyUnlocked(prev => prev.filter(a => a.id !== achievement.id));
        }, 5000);
      }

      return updatedAchievement;
    });

    setAchievements(updatedAchievements);
  };

  const grantAchievementReward = (achievement: Achievement) => {
    const { reward } = achievement;

    switch (reward.type) {
      case 'money':
        if (addMoney) addMoney(reward.value);
        break;
      case 'reputation':
        // Would need to implement reputation in store
        break;
      case 'research_points':
        // Would need to implement research points in store
        break;
    }

    addNotification({
      type: 'success',
      title: '🏆 Achievement Unlocked!',
      message: `${achievement.title}: ${reward.description}`
    });
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'text-zinc-400 border-zinc-400';
      case 'rare': return 'text-blue-400 border-blue-400';
      case 'epic': return 'text-purple-400 border-purple-400';
      case 'legendary': return 'text-yellow-400 border-yellow-400';
      case 'mythical': return 'text-red-400 border-red-400';
      default: return 'text-zinc-400 border-zinc-400';
    }
  };

  const getRarityGradient = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'from-zinc-800 to-zinc-900';
      case 'rare': return 'from-blue-800 to-blue-900';
      case 'epic': return 'from-purple-800 to-purple-900';
      case 'legendary': return 'from-yellow-800 to-yellow-900';
      case 'mythical': return 'from-red-800 to-red-900';
      default: return 'from-zinc-800 to-zinc-900';
    }
  };

  const getCategoryIcon = (category: AchievementCategory) => {
    switch (category) {
      case 'development': return GamepadIcon;
      case 'sales': return DollarSignIcon;
      case 'company': return UsersIcon;
      case 'research': return BeakerIcon;
      case 'marketing': return TrendingUpIcon;
      case 'special': return GiftIcon;
      case 'milestone': return MedalIcon;
      default: return TrophyIcon;
    }
  };

  const categories = [
    { id: 'all', name: 'All', count: achievements.length },
    { id: 'development', name: 'Development', count: achievements.filter(a => a.category === 'development').length },
    { id: 'sales', name: 'Sales', count: achievements.filter(a => a.category === 'sales').length },
    { id: 'company', name: 'Company', count: achievements.filter(a => a.category === 'company').length },
    { id: 'research', name: 'Research', count: achievements.filter(a => a.category === 'research').length },
    { id: 'special', name: 'Special', count: achievements.filter(a => a.category === 'special').length }
  ];

  const filteredAchievements = achievements.filter(achievement => {
    if (selectedCategory !== 'all' && achievement.category !== selectedCategory) return false;
    if (showCompleted && !achievement.isCompleted) return false;
    if (!showCompleted && achievement.isCompleted) return false;
    return achievement.isUnlocked;
  });

  const totalPoints = achievements.filter(a => a.isCompleted).reduce((sum, a) => sum + a.points, 0);
  const totalPossiblePoints = achievements.filter(a => a.isUnlocked).reduce((sum, a) => sum + a.points, 0);
  const completionPercentage = totalPossiblePoints > 0 ? (totalPoints / totalPossiblePoints) * 100 : 0;

  return (
    <div className="p-6 space-y-6">
      {/* Recently Unlocked Achievements */}
      <AnimatePresence>
        {recentlyUnlocked.map((achievement) => (
          <motion.div
            key={achievement.id}
            initial={{ opacity: 0, y: -100, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -100, scale: 0.8 }}
            className="fixed top-4 right-4 z-50 bg-gradient-to-r from-yellow-600 to-yellow-700 text-white p-4 rounded-lg shadow-lg border border-yellow-500"
          >
            <div className="flex items-center gap-3">
              <TrophyIcon className="h-8 w-8 text-yellow-200" />
              <div>
                <h3 className="font-bold">Achievement Unlocked!</h3>
                <p className="text-sm">{achievement.title}</p>
                <p className="text-xs text-yellow-200">{achievement.reward.description}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <TrophyIcon className="h-6 w-6 text-yellow-400" />
            Achievements
          </h2>
          <p className="text-zinc-400 mt-1">Track your progress and unlock rewards</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-zinc-400">Achievement Points</div>
          <div className="text-xl font-bold text-yellow-400">{totalPoints.toLocaleString()}</div>
        </div>
      </div>

      {/* Progress Overview */}
      <Card className="bg-gradient-to-r from-zinc-800 to-zinc-900">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">
                {achievements.filter(a => a.isCompleted).length}
              </div>
              <div className="text-sm text-zinc-400">Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">
                {achievements.filter(a => a.isUnlocked && !a.isCompleted).length}
              </div>
              <div className="text-sm text-zinc-400">Available</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-zinc-400">
                {achievements.filter(a => !a.isUnlocked).length}
              </div>
              <div className="text-sm text-zinc-400">Locked</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-400">
                {completionPercentage.toFixed(1)}%
              </div>
              <div className="text-sm text-zinc-400">Progress</div>
            </div>
          </div>
          <div className="mt-4">
            <Progress value={completionPercentage} className="h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Category Filters */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => {
          const Icon = getCategoryIcon(category.id as AchievementCategory);
          const isActive = selectedCategory === category.id;

          return (
            <Button
              key={category.id}
              variant={isActive ? "default" : "outline"}
              onClick={() => setSelectedCategory(category.id)}
              className="flex items-center gap-2"
            >
              <Icon className="h-4 w-4" />
              {category.name}
              <Badge variant="secondary" className="ml-1">
                {category.count}
              </Badge>
            </Button>
          );
        })}
      </div>

      {/* Show Completed Toggle */}
      <div className="flex justify-end">
        <Button
          variant="outline"
          onClick={() => setShowCompleted(!showCompleted)}
        >
          {showCompleted ? 'Show Available' : 'Show Completed'}
        </Button>
      </div>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <AnimatePresence>
          {filteredAchievements.map((achievement, index) => {
            const Icon = achievement.icon;
            const progress = achievement.requirement.current || 0;
            const target = achievement.requirement.target;
            const progressPercentage = (progress / target) * 100;

            return (
              <motion.div
                key={achievement.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className={`
                  relative overflow-hidden border transition-all hover:scale-105
                  ${achievement.isCompleted
                    ? `bg-gradient-to-br ${getRarityGradient(achievement.rarity)} border-2 ${getRarityColor(achievement.rarity).split(' ')[1]}`
                    : 'border-zinc-700 hover:border-zinc-600'
                  }
                `}>
                  {achievement.isCompleted && (
                    <div className="absolute top-2 right-2">
                      <CheckCircleIcon className="h-6 w-6 text-green-400" />
                    </div>
                  )}

                  <CardHeader className="pb-3">
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg ${
                        achievement.isCompleted
                          ? 'bg-yellow-600/20 border border-yellow-500/50'
                          : 'bg-zinc-800 border border-zinc-700'
                      }`}>
                        <Icon className={`h-6 w-6 ${
                          achievement.isCompleted ? 'text-yellow-400' : 'text-zinc-400'
                        }`} />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-lg">{achievement.title}</CardTitle>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge className={`text-xs ${getRarityColor(achievement.rarity)}`}>
                            {achievement.rarity}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {achievement.points} pts
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-3">
                    <p className="text-sm text-zinc-300">{achievement.description}</p>

                    {/* Progress Bar */}
                    {!achievement.isCompleted && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span>Progress</span>
                          <span>{progress.toLocaleString()} / {target.toLocaleString()}</span>
                        </div>
                        <Progress value={progressPercentage} className="h-2" />
                      </div>
                    )}

                    {/* Reward */}
                    <div className="p-2 bg-zinc-800/50 rounded border border-zinc-700">
                      <div className="text-xs text-zinc-400 mb-1">Reward:</div>
                      <div className="text-sm text-green-400">{achievement.reward.description}</div>
                    </div>

                    {/* Completion Date */}
                    {achievement.isCompleted && achievement.unlockedDate && (
                      <div className="text-xs text-zinc-500 flex items-center gap-1">
                        <CalendarIcon className="h-3 w-3" />
                        Completed {achievement.unlockedDate.toLocaleDateString()}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {filteredAchievements.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <TrophyIcon className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-zinc-400 mb-2">
              {showCompleted ? 'No Completed Achievements' : 'No Available Achievements'}
            </h3>
            <p className="text-zinc-500">
              {showCompleted
                ? 'Complete some achievements to see them here'
                : 'Keep playing to unlock more achievements'}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
